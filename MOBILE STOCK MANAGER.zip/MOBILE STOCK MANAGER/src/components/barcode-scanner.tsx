'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { X, CheckCircle, ScanLine, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

interface BarcodeScannerProps {
  onScan: (barcodes: string[]) => void;
  onClose: () => void;
  scanLimit: number;
  validationType?: 'json' | 'default';
}

const BarcodeScanner: React.FC<BarcodeScannerProps> = ({
  onScan,
  onClose,
  scanLimit,
  validationType = 'default',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const animationFrameId = useRef<number>();
  const [scannedCodes, setScannedCodes] = useState<string[]>([]);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

  const stopScanner = useCallback(() => {
    if (animationFrameId.current) {
      cancelAnimationFrame(animationFrameId.current);
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);

  useEffect(() => {
    const getCameraPermission = async () => {
      if (typeof (window as any).BarcodeDetector === 'undefined') {
        toast.error('Unsupported Browser', {
          description: "Your browser doesn't support the Barcode Detector API.",
        });
        setHasCameraPermission(false);
        onClose();
        return;
      }
      
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
        });
        setHasCameraPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          startScanLoop();
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
        setHasCameraPermission(false);
        toast.error('Camera Access Denied', {
          description: 'Please enable camera permissions in your browser settings to use this feature.',
        });
      }
    };

    const barcodeDetector = new (window as any).BarcodeDetector({
      formats: ['ean_13', 'code_128', 'qr_code'],
    });

    const detectBarcode = async () => {
      const video = videoRef.current;
      if (video && video.readyState > 1) {
        try {
          if (video.srcObject && scannedCodes.length < scanLimit) { 
            const barcodes = await barcodeDetector.detect(video);
            if (barcodes.length > 0) {
              setScannedCodes((prev) => {
                const newCodes = [...prev];
                for (const barcode of barcodes) {
                  if (newCodes.length >= scanLimit) break;
                  
                  let isValid = false;
                  if (validationType === 'json') {
                      try {
                          JSON.parse(barcode.rawValue);
                          isValid = true;
                      } catch (e) {
                          isValid = false;
                      }
                  } else {
                      isValid = /^\d{15}$/.test(barcode.rawValue);
                  }
                  
                  if (isValid && !newCodes.includes(barcode.rawValue)) {
                    newCodes.push(barcode.rawValue);
                    toast.success('Barcode Scanned!', {
                      description: validationType === 'json' ? 'Signal captured' : barcode.rawValue,
                    });
                  }
                }
                return newCodes;
              });
            }
          }
        } catch (err) {
            if (!(err instanceof DOMException && err.name === 'InvalidStateError')) {
                console.error('Barcode detection failed:', err);
            }
        }
      }
      animationFrameId.current = requestAnimationFrame(detectBarcode);
    };
    
    const startScanLoop = () => {
        if (!animationFrameId.current) {
            animationFrameId.current = requestAnimationFrame(detectBarcode);
        }
    };

    getCameraPermission();

    return () => {
      stopScanner();
    };
  }, [onClose, scanLimit, validationType, stopScanner, scannedCodes.length]);

  const handleDone = () => {
    let finalCodes = [...scannedCodes];
    if (finalCodes.length === 1 && scanLimit === 2 && /^\d{15}$/.test(finalCodes[0])) {
      finalCodes.push(finalCodes[0].substring(0, 10));
    }
    onScan(finalCodes);
    onClose();
  };

  const handleScanAgain = () => {
    setScannedCodes([]);
  };

  const isScanningComplete = scannedCodes.length >= scanLimit;

  const scanPrompt = `Scan ${validationType === 'json' ? 'QR Code' : '15-Digit Barcode(s)'}`;

  return (
    <div className="fixed inset-0 bg-black/90 z-[100] flex flex-col font-sans">
      <header className="flex justify-between items-center p-4 z-20 flex-shrink-0">
        <h2 className="text-white text-lg font-bold">{scanPrompt}</h2>
        <Button
          size="icon"
          variant="ghost"
          className="text-white hover:text-red-500 hover:bg-white/10"
          onClick={onClose}
        >
          <X className="h-6 w-6" />
        </Button>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center relative p-4 min-h-0">
        <div className="relative w-full max-w-sm aspect-square overflow-hidden rounded-2xl shadow-2xl bg-black">
          <video
            ref={videoRef}
            className="w-full h-full object-contain"
            playsInline
            muted
            autoPlay
          />
           {hasCameraPermission !== false && (
            <div className="absolute inset-0 z-10 flex items-center justify-center">
                <div className="relative w-10/12 h-1/2">
                <div className="absolute top-0 left-0 border-t-4 border-l-4 border-red-500 w-10 h-10 rounded-tl-lg"></div>
                <div className="absolute top-0 right-0 border-t-4 border-r-4 border-red-500 w-10 h-10 rounded-tr-lg"></div>
                <div className="absolute bottom-0 left-0 border-b-4 border-l-4 border-red-500 w-10 h-10 rounded-bl-lg"></div>
                <div className="absolute bottom-0 right-0 border-b-4 border-r-4 border-red-500 w-10 h-10 rounded-br-lg"></div>
                {!isScanningComplete && (
                    <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 scanning-line rounded-full"></div>
                )}
                </div>
            </div>
            )}
            {hasCameraPermission === false && (
                <div className="absolute inset-0 flex items-center justify-center p-8 bg-black/80">
                    <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Camera Access Denied</AlertTitle>
                        <AlertDescription>
                            Please enable camera permissions in your browser settings to use the scanner.
                        </AlertDescription>
                    </Alert>
                </div>
            )}
        </div>
        <p className="text-white/80 mt-4 text-center px-4">
          Place barcode inside the red box. {scannedCodes.length} of {scanLimit}{' '}
          scanned.
        </p>
      </main>

      <footer className="p-4 z-20 bg-black/50 flex-shrink-0">
        <div className="bg-white/10 rounded-lg p-2 mb-3">
          <h3 className="text-white font-semibold mb-2 px-2">Scanned Codes:</h3>
          {scannedCodes.length > 0 ? (
            <div className="space-y-1">
              {scannedCodes.map((code, index) => (
                <p
                  key={index}
                  className="text-green-400 font-mono text-center bg-black/30 rounded-md py-1 text-sm truncate"
                >
                  {code}
                </p>
              ))}
            </div>
          ) : (
            <p className="text-white/50 text-center py-2 text-sm">
              No codes scanned yet.
            </p>
          )}
        </div>
        <div className="flex gap-4">
          <Button
            onClick={handleScanAgain}
            variant="outline"
            className="w-full h-12 text-md"
            disabled={isScanningComplete}
          >
            Scan Again
          </Button>
          <Button
            onClick={handleDone}
            className="w-full h-12 text-md bg-green-600 hover:bg-green-700"
            disabled={scannedCodes.length === 0 && scanLimit > 0}
          >
            <CheckCircle className="mr-2 h-5 w-5" />
            Done
          </Button>
        </div>
      </footer>
    </div>
  );
};

export default BarcodeScanner;
