
'use client';
import React, { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

/**
 * UnifiedSheetUI
 * - Single-file React component that renders spreadsheet-like HTML
 * - Features: editable cells, search & highlight, export CSV, print preview.
 *
 * Props:
 *  - initialHtml (string) optional: if provided, component will render that table HTML.
 */

export default function UnifiedSheetUI({ initialHtml = null }) {
  const sampleTable = `
    <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: fixed; width: 100%; white-space: nowrap;">
      <thead>
        <tr>
          <th style="padding: 4px 8px; background-color: #f3f4f6; border: 1px solid #ccc;"></th>
          <th style="padding: 4px 8px; background-color: #f3f4f6; border: 1px solid #ccc;">A</th>
          <th style="padding: 4px 8px; background-color: #f3f4f6; border: 1px solid #ccc;">B</th>
          <th style="padding: 4px 8px; background-color: #f3f4f6; border: 1px solid #ccc;">C</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th style="padding: 4px 8px; background-color: #f9fafb; border: 1px solid #ccc;">1</th>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">Hello</td>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">World</td>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">Example</td>
        </tr>
        <tr>
          <th style="padding: 4px 8px; background-color: #f9fafb; border: 1px solid #ccc;">2</th>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">Editable</td>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">Cells</td>
          <td style="padding: 4px 8px; border: 1px solid #ccc;" contenteditable="true">Here</td>
        </tr>
      </tbody>
    </table>
  `;

  const [html, setHtml] = useState(initialHtml || sampleTable);
  const [query, setQuery] = useState("");

  const wrapperRef = useRef<HTMLDivElement>(null);

  // Sync search highlight whenever query or HTML changes
  useEffect(() => {
    highlightSearch(query);
  }, [query, html]);


  function showToast(msg: string) {
    toast.success(msg);
  }

  // Apply/clear highlight class to matching cells
  function highlightSearch(q: string) {
    if (!wrapperRef.current) return;
    const cells = wrapperRef.current.querySelectorAll("td, th");
    cells.forEach((c) => {
      c.classList.remove("ring-2", "ring-yellow-400");
      if (q && (c.textContent || "").toLowerCase().includes(q.toLowerCase())) {
        c.classList.add("ring-2", "ring-yellow-400");
      }
    });
  }

  // Keep state in sync with edits inside contenteditable cells
  function handleInputChange() {
    if (!wrapperRef.current) return;
    // Save only the table innerHTML (so we can re-render easily)
    const tbl = wrapperRef.current.querySelector("table");
    setHtml(tbl ? tbl.outerHTML : wrapperRef.current.innerHTML);
  }

  function exportCSV() {
    const tbl = wrapperRef.current?.querySelector("table");
    if (!tbl) {
      toast.error("No table to export");
      return;
    }

    // Build a 2D array of cell texts, preserving column order from each row
    const rows = Array.from(tbl.querySelectorAll("tr")).map((tr) => {
      const cells = Array.from(tr.querySelectorAll("th,td"));
      return cells.map((c) => (c.textContent || "").replace(/"/g, '""'));
    });

    // Convert rows to CSV string
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sheet.csv";
    a.click();
    URL.revokeObjectURL(url);
    showToast("CSV exported");
  }

  function printPreview() {
    const tbl = wrapperRef.current?.querySelector("table");
    if (!tbl) {
      toast.error("No table to print");
      return;
    }
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
        toast.error("Could not open print window. Please disable your pop-up blocker.");
        return;
    }
    const htmlDoc = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title>Print Preview</title>
    <style>
      @page { size: auto; margin: 0.5in; }
      body { font-family: Arial, sans-serif; }
      table { border-collapse: collapse; width: 100%; white-space: nowrap; }
      th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
      thead { display: table-header-group; }
      th { background-color: #f3f4f6; }
    </style>
  </head>
  <body>${tbl.outerHTML}</body>
</html>`;
    printWindow.document.open();
    printWindow.document.write(htmlDoc);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  }

  return (
    <div className="p-2 sm:p-4 bg-gray-100 flex flex-col flex-1 overflow-auto">
      <div className="flex flex-col sm:flex-row items-center gap-2 mb-3 flex-shrink-0">
        <div className="flex items-center gap-2 flex-wrap justify-start w-full">
           <button
            onClick={exportCSV}
            className="px-3 py-1.5 rounded-md bg-white border text-sm shadow-sm hover:shadow"
            title="Export table to CSV"
          >
            Export CSV
          </button>

          <button
            onClick={printPreview}
            className="px-3 py-1.5 rounded-md bg-white border text-sm shadow-sm hover:shadow"
            title="Open print preview"
          >
            Print
          </button>
        </div>

        <div className="w-full sm:w-auto sm:ml-auto flex items-center gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search..."
            className="px-3 py-1.5 rounded-md border text-sm w-full"
            title="Type to highlight matching cells"
          />
        </div>
      </div>

      <div
        ref={wrapperRef}
        onInput={handleInputChange}
        className="sheet-wrapper bg-white border rounded-lg p-1 sm:p-3 overflow-auto flex-1"
        style={{ minHeight: 160, WebkitOverflowScrolling: 'touch' }}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    </div>
  );
}
