
"use client"

import { Toaster as Sonner } from "sonner"
import { CheckCircle, AlertTriangle, Info, XCircle } from 'lucide-react';

type ToasterProps = React.ComponentProps<typeof Sonner>

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="light"
      className="toaster group"
      position="top-center"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton:
            "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton:
            "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
          success: 'group-[.toast]:!bg-green-50/90 group-[.toast]:!text-green-800 group-[.toast]:!border-green-200',
          info: 'group-[.toast]:!bg-blue-50/90 group-[.toast]:!text-blue-800 group-[.toast]:!border-blue-200',
          warning: 'group-[.toast]:!bg-yellow-50/90 group-[.toast]:!text-yellow-800 group-[.toast]:!border-yellow-200',
          error: 'group-[.toast]:!bg-red-50/90 group-[.toast]:!text-red-800 group-[.toast]:!border-red-200',
        },
      }}
      icons={{
        success: <CheckCircle className="h-5 w-5" />,
        info: <Info className="h-5 w-5" />,
        warning: <AlertTriangle className="h-5 w-5" />,
        error: <XCircle className="h-5 w-5" />,
      }}
      {...props}
    />
  )
}

export { Toaster }
