
'use client';

import { useEffect } from 'react';

export default function OSDetector() {
  useEffect(() => {
    const userAgent = window.navigator.userAgent;
    const htmlElement = document.documentElement;

    if (/android/i.test(userAgent)) {
      htmlElement.classList.add('os-android');
    } else if (/iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream) {
      htmlElement.classList.add('os-ios');
    }
  }, []);

  return null;
}
