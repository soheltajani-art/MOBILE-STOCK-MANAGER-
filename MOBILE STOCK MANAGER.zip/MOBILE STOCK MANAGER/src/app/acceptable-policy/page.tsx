'use client';
import { ArrowLeft, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function AcceptableUsePolicyPage() {
  const router = useRouter();

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center p-4 border-b bg-card">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold mx-auto">Acceptable Use Policy</h1>
        <div className="w-10" />
      </header>

      <ScrollArea className="flex-1">
        <main className="p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>MOBILE STOCK MANAGER - Acceptable Use Policy</CardTitle>
              <CardDescription>
                By using the App, you agree to use it responsibly and ethically.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6 text-sm text-muted-foreground">
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Important Notice</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </AlertDescription>
              </Alert>

              <Separator />

              {/* Section 1 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">1. Access and Permissions</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Admins and employees can both add and manage stock items.</li>
                  <li>Employees have the same permissions and access level as the admin user.</li>
                  <li>Stock history cannot be deleted by any user.</li>
                </ul>
              </div>

              {/* Section 2 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">2. Permitted Use</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app may be used to record and manage stock details and employee numbers.</li>
                  <li>Users may access and correct their own locally stored data.</li>
                </ul>
              </div>

              {/* Section 3 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">3. Prohibited Use</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Do not use the app for any illegal, fraudulent, or harmful activity.</li>
                  <li>Do not attempt to hack, reverse engineer, or modify the app.</li>
                  <li>Do not share or distribute stock data to third parties without proper authorization.</li>
                </ul>
              </div>

              {/* Section 4 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">4. Compliance</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Users must follow all local laws and regulations while using the app.</li>
                  <li>Admin users are responsible for ensuring the accuracy of employee numbers and stock details.</li>
                </ul>
              </div>

              {/* Section 5 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">5. Limitations and Responsibility</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app is provided “as is,” without any guarantees or warranties.</li>
                  <li>There is no guarantee that the app is free from bugs or errors.</li>
                  <li>Users are responsible for using the app at their own risk.</li>
                  <li>The app currently offers its services for free, but future versions may include paid features.</li>
                  <li>There is no testing feature in the app — users must verify all data manually.</li>
                </ul>
              </div>

              {/* Section 6 */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">6. App Updates and Changes</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app may be updated, changed, or discontinued at any time without prior notice.</li>
                </ul>
              </div>

              <Separator />

              <p className="font-semibold text-foreground text-center">
                By using MOBILE STOCK MANAGER, you agree to comply with this Acceptable Use Policy.
              </p>
            </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
