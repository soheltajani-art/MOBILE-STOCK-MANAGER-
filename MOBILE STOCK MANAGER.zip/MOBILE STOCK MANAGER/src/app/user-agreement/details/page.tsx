'use client';
import { ArrowLeft, Info } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function UserAgreementDetailsPage() {
  const router = useRouter();
  const effectiveDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center p-4 border-b bg-card">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold mx-auto">User Agreement</h1>
        <div className="w-10" />
      </header>
      <ScrollArea className="flex-1">
        <main className="p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>MOBILE STOCK MANAGER - User Agreement</CardTitle>
              <CardDescription>
                <strong>Effective Date:</strong> {effectiveDate}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 text-sm text-muted-foreground">
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Important Notice</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </AlertDescription>
              </Alert>

              <p>
                By using <strong>MOBILE STOCK MANAGER</strong> (“the App”), you agree to the following terms and conditions. If you do not agree, do not use the App.
              </p>

              <Separator />

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">1. User Responsibilities</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Admin and employee users can both change data within the app.</li>
                  <li>Users must provide accurate employee numbers and stock details.</li>
                  <li>Users must comply with local laws when using the App.</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">2. Data Privacy and Storage</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Employee numbers and stock data are stored locally on your device (SharedPreferences or SQLite).</li>
                  <li>No cloud or external servers are used for data storage.</li>
                  <li>No personal data is intentionally collected or shared by the application.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">3. Limitation of Liability</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app is provided <strong>“as is”</strong>, without any guarantees.</li>
                  <li>There is no guarantee that this app is free from bugs or errors. Users should use the app at their own risk.</li>
                  <li>Developers are <strong>not liable</strong> for data loss, business loss, or damages arising from use of the app.</li>
                  <li>Users use the app entirely <strong>at their own risk</strong>.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">4. Acceptable Use Policy</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Do not misuse the App for illegal, fraudulent, or harmful activities.</li>
                  <li>Do not attempt to unlawfully modify the App, or distribute stock data without consent.</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">5. Service Availability</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app’s current services are free. In the future, the developer or owner may introduce paid services and make this app paid.</li>
                  <li>The app may be updated, changed, or discontinued at any time without prior notice.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">6. User Data Rights</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Users can access, correct, and delete local stock data and employee numbers.</li>
                  <li>Employees can delete received data from their devices.</li>
                  <li>Admin controls the data on their device.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">7. Contact Information for Legal Matters</h3>
                <p>For any legal inquiries, disputes, or questions:</p>
                <ul className="list-disc pl-5 mt-1 space-y-1">
                  <li><strong>Email (legal inquiries):</strong> soheltajani@gmail.com</li>
                  <li><strong>Email (suggestions/general):</strong> soheltajani@gmail.com</li>
                </ul>
              </div>

              <Separator />

              <p className="font-semibold text-foreground text-center">
                By using MOBILE STOCK MANAGER, you acknowledge and agree to this User Agreement.
              </p>
            </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
