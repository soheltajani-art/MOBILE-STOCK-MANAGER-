
'use client';
import { ArrowLeft, CheckCircle, FileText } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

const policies = [
    { id: 'terms', label: 'TERMS AND CONDITIONS', href: '/terms' },
    { id: 'privacy', label: 'PRIVACY AND POLICY', href: '/privacy' },
    { id: 'agreement', label: 'USER AGREEMENT', href: '/user-agreement/details' }, // Renamed original to avoid conflict
    { id: 'policy', label: 'ACCEPTABLE USE POLICY', href: '/acceptable-policy' },
    { id: 'disclaimer', label: 'DISCLAIMER', href: '/disclaimer' },
];

export default function UserAgreementConfirmationPage() {
    const router = useRouter();

    return (
        <div className="flex flex-col h-screen bg-background">
            <header className="flex items-center p-4 border-b bg-card shadow-sm sticky top-0 z-10">
                <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                    <ArrowLeft className="h-6 w-6 text-foreground" />
                </Button>
                <h1 className="text-xl font-bold mx-auto text-foreground">My Agreements</h1>
                <div className="w-10" />
            </header>

            <ScrollArea className="flex-1">
                <main className="p-4 md:p-6">
                    <Card className="w-full max-w-md mx-auto shadow-lg rounded-2xl bg-card">
                        <CardHeader className="text-center">
                             <div className="mx-auto bg-green-100 p-3 rounded-full mb-3 inline-block">
                                <FileText className="h-8 w-8 text-green-600" />
                            </div>
                            <CardTitle>Agreements Confirmation</CardTitle>
                            <CardDescription>
                                This page confirms the terms and policies you agreed to upon setting up the app.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <Alert className="bg-blue-50 border-blue-200">
                                <CheckCircle className="h-4 w-4 text-blue-600" />
                                <AlertTitle className="text-blue-800">Notice of Agreement</AlertTitle>
                                <AlertDescription className="text-blue-700">
                                    You have accepted the following terms and policies. This confirmation is for your reference.
                                </AlertDescription>
                            </Alert>

                            <div className="space-y-4 rounded-lg border p-4">
                                {policies.map((policy) => (
                                    <div key={policy.id} className="flex items-center justify-between">
                                        <div className="flex items-center space-x-3">
                                            <Checkbox id={policy.id} checked={true} disabled className="opacity-100" />
                                            <Label htmlFor={policy.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                                {policy.label}
                                            </Label>
                                        </div>
                                        <Link href={policy.href} passHref>
                                            <Button variant="link" className="p-0 h-auto text-xs">
                                                View
                                            </Button>
                                        </Link>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </main>
            </ScrollArea>
        </div>
    );
}
