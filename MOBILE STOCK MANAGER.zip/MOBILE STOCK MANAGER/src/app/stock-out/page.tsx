
'use client';

import { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ScanLine, Loader2, AlertTriangle, CheckCircle, Search, X, Cpu, Smartphone, Paintbrush } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { Product } from '../features/where-is-my-product/page';
import type { HistoryItem } from '../features/transfer-records/page';
import type { ReversedTransferItem } from '../features/reverse-transfers/page';
import BarcodeScanner from '@/components/barcode-scanner';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

const formSchema = z.object({
  name: z.string().min(1, 'Model number is required.'),
  id: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.'),
  id2: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.')
    .optional()
    .or(z.literal('')),
  ram: z.string().min(1, 'RAM is required.'),
  storage: z.string().min(1, 'Storage is required.'),
  color: z.string().min(1, 'Color is required.'),
  salePrice: z.coerce.number().min(1, 'Sale price must be greater than 0.'),
  billNo: z.string().optional().or(z.literal('')),
  paymentMethod: z.enum(['cash', 'finance']),
  financeName: z.string().optional(),
}).refine((data) => {
    if (data.paymentMethod === 'finance') {
        return !!data.financeName && data.financeName.length > 0;
    }
    return true;
}, {
    message: 'Finance name is required when payment method is Finance.',
    path: ['financeName'],
});


type StockOutFormValues = z.infer<typeof formSchema>;

type LookupStatus = {
    message: string;
    type: 'success' | 'error' | 'idle' | 'warning';
}

const ramToStorageMap: Record<string, string[]> = {
  '2GB': ['32GB'],
  '3GB': ['32GB', '64GB'],
  '4GB': ['64GB', '128GB'],
  '6GB': ['128GB', '256GB'],
  '8GB': ['128GB', '256GB', '512GB'],
  '12GB': ['256GB', '512GB', '1TB'],
  '16GB': ['512GB', '1TB'],
};
const allRamOptions = Object.keys(ramToStorageMap);
const allStorageOptions = [...new Set(Object.values(ramToStorageMap).flat())];

const SuccessScreen = ({ data, onDone }: { data: HistoryItem, onDone: () => void }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 slide-in-from-right">
      <Card className="w-full max-w-sm shadow-2xl rounded-3xl">
        <CardContent className="p-8">
            <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Stock Sold!</h2>
            <p className="text-gray-600 mb-8">
                The sale of {data.productName} has been successfully recorded.
            </p>
            <div className="space-y-3">
                <Button onClick={onDone} className="w-full h-12 text-lg">
                    Done
                </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default function StockOutPage() {
  const router = useRouter();
  const [showScanner, setShowScanner] = useState(false);
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  const [isCheckingId, setIsCheckingId] = useState(false);
  const [lookupStatus, setLookupStatus] = useState<LookupStatus>({ message: '', type: 'idle' });
  const [showAlreadySoldDialog, setShowAlreadySoldDialog] = useState(false);
  const [submittedSale, setSubmittedSale] = useState<HistoryItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const form = useForm<StockOutFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      id: '',
      id2: '',
      ram: '',
      storage: '',
      color: '',
      salePrice: '' as any,
      billNo: '',
      paymentMethod: 'cash',
      financeName: '',
    },
  });
  
  const searchResults = useMemo(() => {
    if (!searchQuery) return [];
    const lowercasedQuery = searchQuery.toLowerCase();
    return products.filter(
      (item) =>
        item.stock > 0 && (
            item.name.toLowerCase().includes(lowercasedQuery) ||
            item.id.includes(lowercasedQuery) ||
            (item.id2 && item.id2.includes(lowercasedQuery))
        )
    );
  }, [searchQuery, products]);

  const watchedRam = form.watch('ram');
  const paymentMethod = form.watch('paymentMethod');


  useEffect(() => {
    if (watchedRam) {
      const storageOptions = ramToStorageMap[watchedRam] || [];
      const currentStorage = form.getValues('storage');
      if (!storageOptions.includes(currentStorage)) {
        form.setValue('storage', storageOptions[0] || '');
      }
    }
  }, [watchedRam, form]);

  const findAndFillProduct = (productId: string) => {
    if (!productId) return;
    setIsCheckingId(true);
    form.clearErrors('id');
    setLookupStatus({ message: '', type: 'idle' });
    setSearchQuery('');
    
    setTimeout(() => {
        const product = products.find(
          (p) => (p.id === productId || (p.id2 && p.id2 === productId))
        );

        if (product) {
            // Always fill form first
            form.setValue('name', product.name);
            form.setValue('id', product.id);
            if (product.id2) {
              form.setValue('id2', product.id2);
            }
            form.setValue('ram', product.ram);
            form.setValue('storage', product.storage);
            form.setValue('color', product.color);
            form.clearErrors('id');
            
            // Now, check for business logic errors
            const pendingTransferOut = history.find(item => 
              (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
              item.type === 'Transfer Out' &&
              item.status === 'Pending'
            );

            const pendingTransferIn = history.find(item =>
                (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
                item.type === 'Transfer In' &&
                item.status === 'Pending'
            );
            
            const isReversedOut = pendingTransferOut ? reversedTransfers.some(rt => rt.originalTransferId === pendingTransferOut.id) : false;

            if (product.stock <= 0) {
                setShowAlreadySoldDialog(true);
                setLookupStatus({ message: 'Product is already sold out.', type: 'error' });
            } else if (pendingTransferOut && !isReversedOut) {
                form.setError('id', { type: 'manual', message: 'Product is pending transfer out.' });
                setLookupStatus({ message: 'Product is pending transfer out and cannot be sold.', type: 'error' });
            } else if (pendingTransferIn) {
                setLookupStatus({ message: 'Warning: Product is from an unsettled transfer.', type: 'warning' });
            } else {
                setLookupStatus({ message: 'Product found and auto-filled.', type: 'success' });
            }
        } else {
           form.setError('id', { type: 'manual', message: 'Product not found in inventory.' });
           setLookupStatus({ message: 'Product not found in inventory.', type: 'error' });
        }
        setIsCheckingId(false);
    }, 500);
  };

  const handleScan = (barcodes: string[]) => {
    setShowScanner(false);
    if (barcodes.length > 0) {
      findAndFillProduct(barcodes[0]);
    }
  };

  const onSubmit = (data: StockOutFormValues) => {
    // Check for duplicate bill number
    if (data.billNo) {
        const isDuplicateBillNo = history.some(item => 
            item.type === 'Sale' && item.details && item.details.includes(`Bill: ${data.billNo}`)
        );
        if (isDuplicateBillNo) {
            form.setError('billNo', { type: 'manual', message: 'This bill number is already in use.' });
            return;
        }
    }
    
    const productIndex = products.findIndex(
      (p) => (p.id === data.id || (p.id2 && p.id2 === data.id))
    );

    if (productIndex === -1) {
      form.setError('id', { type: 'manual', message: 'Product not found in inventory.' });
      return;
    }
    
    const product = products[productIndex];
    
    if (product.stock <= 0) {
        setShowAlreadySoldDialog(true);
        return;
    }

    const pendingTransferOut = history.find(item => 
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      item.type === 'Transfer Out' &&
      item.status === 'Pending'
    );
    const isReversedOut = pendingTransferOut ? reversedTransfers.some(rt => rt.originalTransferId === pendingTransferOut.id) : false;

    if (pendingTransferOut && !isReversedOut) {
      form.setError('id', { type: 'manual', message: 'This product is pending transfer out and cannot be sold.' });
      setLookupStatus({ message: 'This product is pending transfer out and cannot be sold.', type: 'error' });
      return;
    }
    
    const pendingTransferIn = history.find(item => 
      item.type === 'Transfer In' &&
      item.status === 'Pending' &&
      (item.details.includes(data.id) || (data.id2 && item.details.includes(data.id2)))
    );

    const updatedProducts = [...products];
    updatedProducts[productIndex] = { ...product, stock: 0 };
    setProducts(updatedProducts);
    
    const detailsParts = [
      `${data.ram}/${data.storage}`,
      data.color,
      `ID1: ${data.id}`,
    ];
    if (data.id2) {
      detailsParts.push(`ID2: ${data.id2}`);
    }
    if (data.billNo) {
      detailsParts.push(`Bill: ${data.billNo}`);
    }
    detailsParts.push(`Sold via ${data.paymentMethod === 'cash' ? 'Cash' : `Finance: ${data.financeName}`}`);

    const details = detailsParts.join(', ');

    const historyEntry: HistoryItem = {
      id: Date.now(),
      date: new Date(),
      type: 'Sale',
      productName: data.name,
      quantity: 1,
      totalAmount: data.salePrice,
      salePrice: data.salePrice,
      purchasePrice: product.purchasePrice,
      details: details,
      saleStatus: pendingTransferIn ? 'unsettled_transfer' : null,
    };
    setHistory((prev) => [historyEntry, ...prev]);

    setSubmittedSale(historyEntry);
  };
  
  if (submittedSale) {
      return (
         <div className="flex flex-col h-screen bg-gray-50 font-sans">
            <header className="bg-white shadow-sm sticky top-0 z-20">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                  <div className="w-10"></div>
                  <h1 className="text-xl font-bold text-gray-900">Sale Successful</h1>
                  <div className="w-10"></div>
                </div>
              </div>
            </header>
            <main className="flex-1">
                <SuccessScreen data={submittedSale} onDone={() => router.push('/dashboard')} />
            </main>
        </div>
      );
  }

  return (
    <>
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
          scanLimit={1}
        />
      )}
       <AlertDialog open={showAlreadySoldDialog} onOpenChange={setShowAlreadySoldDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center text-center">
            <div className="bg-red-100 p-3 rounded-full mb-3">
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
            <AlertDialogTitle className="text-2xl font-bold">Product Already Sold</AlertDialogTitle>
            <AlertDialogDescription>
              This product has already been sold and cannot be sold again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowAlreadySoldDialog(false)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right">
        <header className="bg-white shadow-sm sticky top-0 z-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
                <ArrowLeft className="h-6 w-6 text-gray-700" />
              </Button>
              <h1 className="text-xl font-bold text-gray-900">Sold Out</h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col flex-1"
          >
            <ScrollArea className="flex-1">
              <main className="p-4 md:p-6">
                <Card className="bg-white shadow-lg rounded-2xl">
                  <CardContent className="p-6 space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input
                          placeholder="Search by Model or ID to autofill..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                      />
                      {searchQuery && (
                          <Button
                          variant="ghost"
                          size="icon"
                          className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6"
                          onClick={() => setSearchQuery('')}
                          >
                          <X className="h-4 w-4" />
                          </Button>
                      )}
                      {searchResults.length > 0 && (
                          <Card className="absolute z-10 w-full mt-1 max-h-60 overflow-y-auto">
                          <CardContent className="p-2">
                              {searchResults.map((product) => (
                              <div
                                  key={product.id}
                                  onClick={() => findAndFillProduct(product.id)}
                                  className="p-3 hover:bg-gray-100 rounded-lg cursor-pointer"
                              >
                                  <p className="font-semibold">{product.name}</p>
                                  <p className="text-sm text-gray-500 font-mono">
                                  {product.id}
                                  </p>
                                  <div className="flex items-center gap-4 text-xs text-gray-500 mt-2 pt-2 border-t border-gray-100">
                                    {product.ram && <span className="flex items-center gap-1"><Cpu className="h-3 w-3" />{product.ram}</span>}
                                    {product.storage && <span className="flex items-center gap-1"><Smartphone className="h-3 w-3" />{product.storage}</span>}
                                    {product.color && <span className="flex items-center gap-1"><Paintbrush className="h-3 w-3" />{product.color}</span>}
                                  </div>
                              </div>
                              ))}
                          </CardContent>
                          </Card>
                      )}
                    </div>
                    <div className="relative flex items-center justify-center my-4">
                        <div className="flex-grow border-t border-gray-200"></div>
                        <span className="flex-shrink mx-4 text-xs font-semibold text-gray-400 uppercase">OR</span>
                        <div className="flex-grow border-t border-gray-200"></div>
                    </div>
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Model No. of Mobile</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter model number" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="space-y-1">
                      <FormField
                        control={form.control}
                        name="id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 1 (IMEI)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                  <Input
                                  type="text"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  placeholder="Enter 15-digit PRODUCT ID"
                                  {...field}
                                  maxLength={15}
                                  onBlur={(e) => findAndFillProduct(e.target.value)}
                                  />
                                  {isCheckingId && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 animate-spin" />}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="id2"
                        render={({ field }) => (
                          <FormItem className="mt-2">
                            <FormLabel>PRODUCT ID 2 (IMEI, Optional)</FormLabel>
                             <FormControl>
                               <div className="relative">
                                  <Input
                                  type="text"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  placeholder="Enter 15-digit PRODUCT ID"
                                  {...field}
                                  maxLength={15}
                                  onBlur={(e) => findAndFillProduct(e.target.value)}
                                  />
                                  {isCheckingId && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 animate-spin" />}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       {lookupStatus.type !== 'idle' && (
                          <div className={cn("mt-2 text-sm text-center font-medium", {
                              'text-green-600': lookupStatus.type === 'success',
                              'text-red-600': lookupStatus.type === 'error',
                              'text-yellow-600': lookupStatus.type === 'warning',
                          })}>
                              {lookupStatus.message}
                          </div>
                      )}
                      <Button
                        id="scan-barcodes-button"
                        type="button"
                        variant="outline"
                        className="w-full mt-2"
                        onClick={() => setShowScanner(true)}
                      >
                        <ScanLine className="mr-2 h-4 w-4" />
                        Scan Barcode
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="ram"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>RAM</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger onFocus={() => setLookupStatus({ message: '', type: 'idle' })}>
                                  <SelectValue placeholder="Select RAM" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {allRamOptions.map((ramOption) => (
                                  <SelectItem key={ramOption} value={ramOption}>
                                    {ramOption}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="storage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>STORAGE</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger onFocus={() => setLookupStatus({ message: '', type: 'idle' })}>
                                  <SelectValue placeholder="Select Storage" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {(
                                  ramToStorageMap[watchedRam] || allStorageOptions
                                ).map((storageOption) => (
                                  <SelectItem
                                    key={storageOption}
                                    value={storageOption}
                                  >
                                    {storageOption}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>COLOUR</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter colour" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="salePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retailer's Selling Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              placeholder="Enter price"
                              {...field}
                              onFocus={() => setLookupStatus({ message: '', type: 'idle' })}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="billNo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bill No.</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter bill number (optional)" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger onFocus={() => setLookupStatus({ message: '', type: 'idle' })}>
                                <SelectValue placeholder="Select a payment method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="cash">Cash</SelectItem>
                              <SelectItem value="finance">Finance</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {paymentMethod === 'finance' && (
                      <FormField
                        control={form.control}
                        name="financeName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Finance Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter name of financier" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </CardContent>
                </Card>
              </main>
            </ScrollArea>
            <div className="sticky bottom-0 p-4 bg-white border-t">
              <Button
                type="submit"
                className="w-full h-12 bg-red-600 hover:bg-red-700 text-white rounded-xl text-lg"
              >
                SOLD STOCK
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </>
  );
}
