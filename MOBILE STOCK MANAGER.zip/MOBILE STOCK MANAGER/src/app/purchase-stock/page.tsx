'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ScanLine, AlertTriangle, Share2, CheckCircle, Tv } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { Product } from '../features/where-is-my-product/page';
import type { HistoryItem } from '../features/transfer-records/page';
import BarcodeScanner from '@/components/barcode-scanner';
import { ScrollArea } from '@/components/ui/scroll-area';
import Link from 'next/link';

const formSchema = z.object({
  brand: z.string().min(1, 'Brand is required.'),
  name: z.string().min(1, 'Model number is required.'),
  id: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.'),
  id2: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.')
    .optional().or(z.literal('')),
  ram: z.string().min(1, 'RAM is required.'),
  storage: z.string().min(1, 'Storage is required.'),
  color: z.string().min(1, 'Color is required.'),
  purchasePrice: z.coerce
    .number()
    .min(1, 'Purchase price must be greater than 0.'),
  mop: z.coerce.number().optional(),
});

type PurchaseFormValues = z.infer<typeof formSchema>;

const ramToStorageMap: Record<string, string[]> = {
  '2GB': ['32GB'],
  '3GB': ['32GB', '64GB'],
  '4GB': ['64GB', '128GB'],
  '6GB': ['128GB', '256GB'],
  '8GB': ['128GB', '256GB', '512GB'],
  '12GB': ['256GB', '512GB', '1TB'],
  '16GB': ['512GB', '1TB'],
};
const allRamOptions = Object.keys(ramToStorageMap);
const allStorageOptions = [...new Set(Object.values(ramToStorageMap).flat())];

const brandOptions = [
    'SAMSUNG',
    'VIVO',
    'OPPO',
    'REDMI',
    'REALME',
    'POCO',
    'ONEPLUS',
    'NOTHING',
    'IPHONE',
    'MOTOROLLA',
    'INFINIX',
    'ITEL',
    'LAVA',
    'TECNO',
    'OTHER',
];

const SuccessScreen = ({ data, onDone }: { data: HistoryItem, onDone: () => void }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 slide-in-from-right">
      <Card className="w-full max-w-sm shadow-2xl rounded-3xl">
        <CardContent className="p-8">
            <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Purchase Done!</h2>
            <p className="text-gray-600 mb-8">
                The purchase for {data.productName} has been successfully recorded.
            </p>
            <div className="space-y-3">
                <Button onClick={onDone} className="w-full h-12 text-lg">
                    Done
                </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default function PurchaseStockPage() {
  const router = useRouter();
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [showScanner, setShowScanner] = useState(false);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [submittedPurchase, setSubmittedPurchase] = useState<HistoryItem | null>(null);

  const form = useForm<PurchaseFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      brand: '',
      name: '',
      id: '',
      id2: '',
      ram: '',
      storage: '',
      color: '',
      purchasePrice: '' as any,
      mop: '' as any,
    },
  });

  const watchedRam = form.watch('ram');

  useEffect(() => {
    if (watchedRam) {
      const storageOptions = ramToStorageMap[watchedRam] || [];
      const currentStorage = form.getValues('storage');
      if (!storageOptions.includes(currentStorage)) {
        form.setValue('storage', storageOptions[0] || '');
      }
    }
  }, [watchedRam, form]);

  const checkForDuplicate = (id: string) => {
    if (!id || id.length !== 15) return;

    const isDuplicate = products.some(p => p.id === id || (p.id2 && p.id2 === id));

    if (isDuplicate) {
      setShowDuplicateDialog(true);
    }
  };

  const handleScan = (barcodes: string[]) => {
    setShowScanner(false);
    const [firstId, secondId] = barcodes;

    if (firstId) {
      form.setValue('id', firstId);
      checkForDuplicate(firstId);
    } else {
      form.setValue('id', '');
    }

    if (secondId) {
      form.setValue('id2', secondId);
      checkForDuplicate(secondId);
    } else {
      form.setValue('id2', '');
    }
  };

  const onSubmit = (data: PurchaseFormValues) => {
    const isDuplicateProduct = products.some(p => {
      if (data.id && (p.id === data.id || (p.id2 && p.id2 === data.id))) {
        return true;
      }
      if (data.id2 && (p.id === data.id2 || (p.id2 && p.id2 === data.id2))) {
        return true;
      }
      return false;
    });

    if (isDuplicateProduct) {
      setShowDuplicateDialog(true);
      return;
    }

    const newProduct: Product = { ...data, stock: 1 };
    setProducts((prev) => [...prev, newProduct]);

    let details = `${data.ram}/${data.storage}, ${data.color} - ID1: ${data.id}`;
    if (data.id2) {
      details += `, ID2: ${data.id2}`;
    }
    
    const historyEntry: HistoryItem = {
      id: Date.now(),
      date: new Date(),
      type: 'Purchase',
      productName: data.name,
      quantity: 1,
      totalAmount: data.purchasePrice,
      purchasePrice: data.purchasePrice,
      details: details,
    };
    setHistory((prev) => [historyEntry, ...prev]);
    
    setSubmittedPurchase(historyEntry);
  }

  if (submittedPurchase) {
      return (
        <div className="flex flex-col h-screen bg-gray-50 font-sans">
            <header className="bg-white shadow-sm sticky top-0 z-10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                  <div className="w-10"></div>
                  <h1 className="text-xl font-bold text-gray-900">
                    Purchase Successful
                  </h1>
                  <div className="w-10"></div>
                </div>
              </div>
            </header>
            <main className="flex-1">
                <SuccessScreen data={submittedPurchase} onDone={() => router.push('/dashboard')} />
            </main>
        </div>
      )
  }

  return (
    <>
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
          scanLimit={2}
        />
      )}
      
      <AlertDialog open={showDuplicateDialog} onOpenChange={setShowDuplicateDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center text-center">
            <div className="bg-yellow-100 p-3 rounded-full mb-3">
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
            <AlertDialogTitle className="text-2xl font-bold">Duplicate Product</AlertDialogTitle>
            <AlertDialogDescription>
              A product with this ID is already in your inventory.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowDuplicateDialog(false)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
                <ArrowLeft className="h-6 w-6 text-gray-700" />
              </Button>
              <h1 className="text-xl font-bold text-gray-900">
                Purchase Stock
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col flex-1"
          >
            <ScrollArea className="flex-1">
              <main className="p-4 md:p-6">
                <Card className="bg-white shadow-lg rounded-2xl">
                  <CardContent className="p-6 space-y-4">
                    <FormField
                      control={form.control}
                      name="brand"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Brand</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a brand" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {brandOptions.map(brand => (
                                <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Model No. of Mobile</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter model number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="space-y-1">
                      <FormField
                        control={form.control}
                        name="id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 1 (IMEI)</FormLabel>
                            <FormControl>
                              <Input
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                placeholder="Enter 15-digit PRODUCT ID"
                                {...field}
                                maxLength={15}
                                onBlur={(e) => checkForDuplicate(e.target.value)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="id2"
                        render={({ field }) => (
                          <FormItem className="mt-2">
                            <FormLabel>PRODUCT ID 2 (IMEI, Optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                placeholder="Enter 15-digit PRODUCT ID"
                                {...field}
                                maxLength={15}
                                onBlur={(e) => checkForDuplicate(e.target.value)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <Button id="scan-barcodes-button" type="button" variant="outline" className="w-full mt-2" onClick={() => setShowScanner(true)}>
                          <ScanLine className="mr-2 h-4 w-4" />
                          Scan Barcodes
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="ram"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>RAM</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select RAM" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {allRamOptions.map((ramOption) => (
                                  <SelectItem key={ramOption} value={ramOption}>
                                    {ramOption}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="storage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>STORAGE</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Storage" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {(ramToStorageMap[watchedRam] || allStorageOptions).map(
                                  (storageOption) => (
                                    <SelectItem
                                      key={storageOption}
                                      value={storageOption}
                                    >
                                      {storageOption}
                                    </SelectItem>
                                  )
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>COLOUR</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter colour" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="purchasePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retailer's Buying Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              placeholder="Enter price"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                     <FormField
                      control={form.control}
                      name="mop"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>MOP (Maximum Offer Price)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              placeholder="Enter display price (optional)"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </main>
            </ScrollArea>
            <div className="sticky bottom-0 p-4 bg-white border-t">
              <Button type="submit" className="w-full h-12 rounded-xl text-lg">
                 + PURCHASE STOCK
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </>
  );
}
