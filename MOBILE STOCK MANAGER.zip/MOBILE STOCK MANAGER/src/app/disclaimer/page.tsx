'use client';
import { ArrowLeft, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function DisclaimerPage() {
  const router = useRouter();

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center p-4 border-b bg-card">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold mx-auto">Disclaimer</h1>
        <div className="w-10" />
      </header>
      <ScrollArea className="flex-1">
        <main className="p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>MOBILE STOCK MANAGER Disclaimer</CardTitle>
              <CardDescription>
                The <strong>MOBILE STOCK MANAGER</strong> app is currently provided <strong>free of charge</strong> and <strong>"as is"</strong>, without any warranties, expressed or implied. Future updates may introduce paid features or subscription services.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 text-sm text-muted-foreground">
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Important Notice</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </AlertDescription>
              </Alert>

              <Separator />

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">1. No Warranty</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app is provided <strong>“as is”</strong> without any guarantees.</li>
                  <li>The app may contain errors or bugs and might not be available at all times.</li>
                  <li>It may not meet your specific business or operational needs.</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">2. Limitation of Liability</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Developers are <strong>not responsible</strong> for any loss of profits, data, or business opportunities resulting from using the app.</li>
                  <li>You use the app entirely <strong>at your own risk</strong>.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">3. User Responsibility</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>You are responsible for how you use the app and for maintaining backups of your important data.</li>
                  <li>Admin users must enter correct employee numbers and product details (like IMEIs).</li>
                  <li>Developers are <strong>not responsible</strong> for misuse or accidental data disclosure.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">4. Privacy</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Employee phone numbers and product details are stored <strong>locally on your device</strong> (using SharedPreferences or SQLite).</li>
                  <li>No data is uploaded to external servers, cloud services, or third-party APIs.</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">5. Service Changes</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Features, pricing, or availability may change at any time <strong>without prior notice</strong>.</li>
                  <li>Developers reserve the right to introduce, modify, or discontinue free or paid services.</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">6. Contact Information</h3>
                <p><span className="font-medium">For bug reports:</span> soheltajani@gmail.com</p>
                <p><span className="font-medium">For suggestions:</span> soheltajani@gmail.com</p>
              </div>

              <Separator />

              <p className="font-semibold text-foreground text-center">
                By using MOBILE STOCK MANAGER, you agree to this disclaimer.<br />
                If you do not agree, please discontinue use of the app.
              </p>
            </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
