'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Package, TrendingUp, Zap, Upload } from 'lucide-react';
import { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import Link from 'next/link';

export default function WelcomePage() {
  const router = useRouter();
  const [isTermsAccepted, setIsTermsAccepted] = useState(false);
  const [isPrivacyAccepted, setIsPrivacyAccepted] = useState(false);
  const [isAgreementAccepted, setIsAgreementAccepted] = useState(false);
  const [isPolicyAccepted, setIsPolicyAccepted] = useState(false);
  const [isDisclaimerAccepted, setIsDisclaimerAccepted] = useState(false);
  const [isAllConfirmed, setIsAllConfirmed] = useState(false);

  const handleContinue = () => {
    localStorage.setItem('hasSeenWelcome', 'true');
    const shopInfo = localStorage.getItem('shopInfo');
    if (shopInfo) {
      router.replace('/dashboard');
    } else {
      router.replace('/shop-information');
    }
  };

  const canContinue = isTermsAccepted && isPrivacyAccepted && isAgreementAccepted && isPolicyAccepted && isDisclaimerAccepted && isAllConfirmed;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-muted p-4">
      <Card className="w-full max-w-md shadow-2xl rounded-3xl animate-fade-in-scale bg-card">
        <CardHeader className="text-center p-8">
            <div className="mx-auto bg-primary/10 p-4 rounded-full mb-4 inline-block">
                <Zap className="h-10 w-10 text-primary" />
            </div>
            <CardTitle className="text-3xl font-bold text-foreground">Welcome to MOBILE STOCK MANAGER</CardTitle>
            <CardDescription className="text-base text-muted-foreground mt-2">
                Your all-in-one inventory management solution.
            </CardDescription>
        </CardHeader>
        <CardContent className="p-8 pt-0 space-y-6">
            <div className="space-y-4 text-left">
                <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 bg-green-100 p-2 rounded-full">
                        <Package className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-foreground">Track Everything</h3>
                        <p className="text-sm text-muted-foreground">Manage sales, purchases, and transfers with ease.</p>
                    </div>
                </div>
                <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 bg-purple-100 p-2 rounded-full">
                        <TrendingUp className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-foreground">Gain Insights</h3>
                        <p className="text-sm text-muted-foreground">View detailed history and profit analysis.</p>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        <Checkbox id="terms" checked={isTermsAccepted} onCheckedChange={(checked) => setIsTermsAccepted(checked as boolean)} />
                        <Label htmlFor="terms" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            TERMS AND CONDITIONS
                        </Label>
                    </div>
                    <Link href="/terms" passHref>
                      <Button variant="link" className="p-0 h-auto text-xs">
                          View
                      </Button>
                    </Link>
                </div>
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-2">
                        <Checkbox id="privacy" checked={isPrivacyAccepted} onCheckedChange={(checked) => setIsPrivacyAccepted(checked as boolean)} />
                        <Label htmlFor="privacy" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            PRIVACY AND POLICY
                        </Label>
                    </div>
                    <Link href="/privacy" passHref>
                         <Button variant="link" className="p-0 h-auto text-xs">
                            View
                        </Button>
                    </Link>
                </div>
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-2">
                        <Checkbox id="agreement" checked={isAgreementAccepted} onCheckedChange={(checked) => setIsAgreementAccepted(checked as boolean)} />
                        <Label htmlFor="agreement" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            USER AGREEMENT
                        </Label>
                    </div>
                    <Link href="/user-agreement/details" passHref>
                         <Button variant="link" className="p-0 h-auto text-xs">
                            View
                        </Button>
                    </Link>
                </div>
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-2">
                        <Checkbox id="policy" checked={isPolicyAccepted} onCheckedChange={(checked) => setIsPolicyAccepted(checked as boolean)} />
                        <Label htmlFor="policy" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            ACCEPTABLE USE POLICY
                        </Label>
                    </div>
                    <Link href="/acceptable-policy" passHref>
                         <Button variant="link" className="p-0 h-auto text-xs">
                            View
                        </Button>
                    </Link>
                </div>
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-2">
                        <Checkbox id="disclaimer" checked={isDisclaimerAccepted} onCheckedChange={(checked) => setIsDisclaimerAccepted(checked as boolean)} />
                        <Label htmlFor="disclaimer" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            DISCLAIMER
                        </Label>
                    </div>
                    <Link href="/disclaimer" passHref>
                         <Button variant="link" className="p-0 h-auto text-xs">
                            View
                        </Button>
                    </Link>
                </div>
                <div className="!mt-6 flex items-center space-x-2 p-3 bg-muted rounded-lg">
                    <Checkbox id="all-confirmed" checked={isAllConfirmed} onCheckedChange={(checked) => setIsAllConfirmed(checked as boolean)} />
                    <Label htmlFor="all-confirmed" className="text-xs text-muted-foreground leading-snug">
                        I acknowledge that by completing these checks and clicking 'Continue,' I accept all the terms and policies listed above.
                    </Label>
                </div>
            </div>

            <div className="space-y-3 pt-4 border-t">
                {canContinue && (
                    <Link href="/features/backup-restore?mode=restore_only" passHref>
                         <Button variant="outline" className="w-full h-12 text-md">
                            <Upload className="mr-2 h-5 w-5" />
                            Restore from Backup
                        </Button>
                    </Link>
                )}
                <Button onClick={handleContinue} className="w-full h-12 text-lg rounded-xl" disabled={!canContinue}>
                    Continue as Admin
                </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
