
'use client';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Package,
  Cpu,
  Smartphone,
  Paintbrush,
  IndianRupee,
  Fingerprint,
  Building,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { HistoryItemCard } from './features/history-item-card';
import { type Product } from './features/where-is-my-product/page';
import { type HistoryItem } from './features/transfer-records/page';


interface ProductDetailsModalProps {
  product: Product;
  history: HistoryItem[];
  isOpen: boolean;
  onClose: () => void;
}

const DetailRow = ({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
}) => (
  <div className="flex items-center text-sm text-gray-700">
    <Icon className="h-4 w-4 mr-3 text-gray-500" />
    <span className="font-semibold w-28">{label}:</span>
    <span className="flex-1 text-right font-medium">{value}</span>
  </div>
);

export default function ProductDetailsModal({
  product,
  history,
  isOpen,
  onClose,
}: ProductDetailsModalProps) {
  if (!product) return null;

  const isSold = product.stock === 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] p-0">
        <DialogHeader className='p-6 pb-0'>
          <div className="flex items-center space-x-4">
            <div className="p-3 rounded-xl bg-gray-100">
              <Package className="h-6 w-6 text-gray-600" />
            </div>
            <div>
              <DialogTitle className='text-left'>{product.name}</DialogTitle>
              <DialogDescription className='text-left'>{product.id}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <ScrollArea className="max-h-[70vh]">
          <div className="p-6 space-y-4">
            <Card className="bg-gray-50/80">
              <CardContent className="p-4 space-y-2">
                <div className='flex justify-between items-center mb-3'>
                    <h4 className="font-semibold text-gray-800">
                    Product Details
                    </h4>
                    <Badge
                        className={
                            isSold
                            ? 'bg-red-100 text-red-800 border-red-200'
                            : 'bg-green-100 text-green-800 border-green-200'
                        }
                    >
                        {isSold ? 'Sold Out' : `In Stock: ${product.stock}`}
                    </Badge>
                </div>
                {product.brand && <DetailRow icon={Building} label="Brand" value={product.brand} />}
                {product.ram && <DetailRow icon={Cpu} label="RAM" value={product.ram} />}
                {product.storage && <DetailRow
                  icon={Smartphone}
                  label="Storage"
                  value={product.storage}
                />}
                <DetailRow
                  icon={Paintbrush}
                  label="Color"
                  value={product.color}
                />
                <DetailRow icon={Fingerprint} label="ID 1" value={product.id} />
                {product.id2 && (
                  <DetailRow
                    icon={Fingerprint}
                    label="ID 2"
                    value={product.id2}
                  />
                )}
                <DetailRow
                  icon={IndianRupee}
                  label="Purchase Price"
                  value={product.purchasePrice.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR',
                  })}
                />
                {product.mop && <DetailRow icon={IndianRupee} label="MOP" value={product.mop.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })} />}
              </CardContent>
            </Card>

            {history.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-800 my-4">
                  Product History
                </h4>
                <div className="space-y-0">
                  {history.map((item) => (
                    <HistoryItemCard key={item.id} item={item} />
                  ))}
                </div>
              </div>
            )}

            {history.length === 0 && (
              <div className="text-center text-gray-500 py-10">
                <Package className="mx-auto h-10 w-10 text-gray-400" />
                <h3 className="mt-2 text-md font-medium text-gray-900">
                  No History
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  No history found for this product.
                </p>
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
