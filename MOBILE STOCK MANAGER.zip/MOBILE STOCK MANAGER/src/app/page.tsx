
'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function LoadingPage() {
  const router = useRouter();

  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem('hasSeenWelcome');
    if (!hasSeenWelcome) {
      router.replace('/welcome');
      return;
    }

    const shopInfo = localStorage.getItem('shopInfo');
    if (!shopInfo) {
      router.replace('/shop-information');
      return;
    }

    // If all checks pass, proceed to the dashboard after a shorter delay.
    const timer = setTimeout(() => {
      router.push('/dashboard');
    }, 500); // 0.5-second delay

    return () => clearTimeout(timer);
  }, [router]);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 text-foreground overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-[#F5F5F5] dark:bg-[#1C1C1C]" />
      
      <div className="relative w-full max-w-sm aspect-[3/4] p-8 md:p-10 text-white dark:text-white animate-fade-in-scale">
          
          <div 
              className="relative h-full w-full"
          >
              {/* Top Left "PRESENTS" */}
              <div className="absolute top-0 left-0">
                  <div className="px-4 py-1.5 bg-[#4A90E2] rounded-full text-xs font-bold tracking-widest text-white">
                      PRESENTS
                  </div>
              </div>

              {/* Top Right Lines */}
              <div className="absolute top-4 right-0 space-y-2">
                  <div className="h-1 w-16 bg-[#4A90E2] animate-draw-line" style={{ animationDelay: '0.2s' }}></div>
                  <div className="h-1 w-16 bg-[#4A90E2] animate-draw-line" style={{ animationDelay: '0.4s' }}></div>
                  <div className="h-1 w-16 bg-[#4A90E2] animate-draw-line" style={{ animationDelay: '0.6s' }}></div>
              </div>

              {/* Main Text */}
              <div className="absolute top-1/4 left-0 w-full">
                  <h1 className="text-7xl md:text-8xl font-black text-[#1A1A1A] dark:text-[#F2EBE3] leading-none">
                      MST
                  </h1>
                  <h1 className="text-7xl md:text-8xl font-black text-[#1A1A1A] dark:text-[#F2EBE3] leading-none mt-1">
                      STUDIO
                  </h1>
              </div>
              
              {/* Center "PRESENTS" */}
               <p className="absolute top-1/2 left-0 mt-8 text-2xl font-bold tracking-[0.2em] text-[#1A1A1A] dark:text-[#F2EBE3] z-10">
                  PRESENTS
               </p>

              {/* Bottom Left Circle */}
              <div 
                  className="absolute -bottom-24 -left-24 w-64 h-64 border-[32px] border-[#4A90E2] rounded-full animate-scale-in"
              ></div>

              {/* Bottom Right Elements */}
               <div className="absolute bottom-0 right-0 flex flex-col items-end gap-6">
                  <div className="grid grid-cols-7 gap-2">
                      {Array.from({length: 49}).map((_, i) => (
                          <div key={i} className="w-1.5 h-1.5 bg-[#4A90E2] rounded-full"></div>
                      ))}
                  </div>
                  <div className="space-y-2 transform -rotate-45 -translate-y-8 -translate-x-4">
                      <div className="h-1 w-32 bg-[#4A90E2] rounded-full animate-draw-line" style={{ animationDelay: '0.8s' }}></div>
                      <div className="h-1 w-32 bg-[#4A90E2] rounded-full animate-draw-line" style={{ animationDelay: '1s' }}></div>
                      <div className="h-1 w-32 bg-[#4A90E2] rounded-full animate-draw-line" style={{ animationDelay: '1.2s' }}></div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}
