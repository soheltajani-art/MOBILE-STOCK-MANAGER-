'use client';
import { ArrowLeft, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function TermsPage() {
  const router = useRouter();

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center p-4 border-b bg-card">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold mx-auto">Terms and Conditions</h1>
        <div className="w-10" />
      </header>
      <ScrollArea className="flex-1">
        <main className="p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>Terms and Conditions</CardTitle>
              <CardDescription>
                Owner & Copyright Holder: MOHAMMED SOHEL TAJANI <br />
                Contact Email: soheltajani@gmail.com
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm text-muted-foreground">
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Important Notice</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </AlertDescription>
              </Alert>

              <p>
                By logging in or using this application, you agree to the following Terms and Conditions. If you do not agree, please do not use the app.
              </p>
              
              <Separator />

              <h3 className="font-semibold text-foreground text-base pt-2">1. Acceptance of Terms</h3>
              <p>
                By selecting and logging into the app, the user confirms that they have read, understood, and accepted these Terms and Conditions.
              </p>

              <h3 className="font-semibold text-foreground text-base pt-2">2. User Responsibility</h3>
              <p>
                The use of this app is entirely the responsibility of the user. The app owner is not responsible for any misuse of the application. If the app is misused in any way, the user alone is responsible for the consequences.
              </p>

              <h3 className="font-semibold text-foreground text-base pt-2">3. Intellectual Property and Restrictions</h3>
              <p>
                This application, including its code, design, branding, and user interface, is the exclusive intellectual property of the owner, MOHAMMED SOHEL TAJANI. Copying this app or any part of it is not allowed. Reverse engineering, decompiling, modifying, or creating another app using this app’s code, design, or format is strictly prohibited. The app and its associated intellectual property may not be sold, shared, or distributed without express written permission from the owner.
              </p>

              <h3 className="font-semibold text-foreground text-base pt-2">4. Data Storage and Privacy</h3>
              <p>
                The app owner does not collect any personal data. All data is stored locally on the user’s device.
              </p>

              <h3 className="font-semibold text-foreground text-base pt-2">5. Disclaimer of Liability</h3>
              <p>
                If the app contains errors, bugs, or does not work properly, the owner is not responsible. Users must test the app before using it for important purposes. If the app’s failure causes any kind of loss, damage, or problem, the app owner will not be responsible under any circumstances.
              </p>

              <Separator />
              <p className="font-semibold text-foreground text-center">
                Copyright (c) 2024 MOHAMMED SOHEL TAJANI. All Rights Reserved.
              </p>

            </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
