'use client';
import { ArrowLeft, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function PrivacyPolicyPage() {
  const router = useRouter();

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center p-4 border-b bg-card">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold mx-auto">Privacy Policy</h1>
        <div className="w-10" />
      </header>
      <ScrollArea className="flex-1">
        <main className="p-4 md:p-6">
          <Card>
            <CardHeader>
              <CardTitle>MOBILE STOCK MANAGER - Privacy Policy</CardTitle>
              <CardDescription>
                This app is designed with privacy and data safety in mind. This Privacy Policy explains how your data is collected, stored, and used.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 text-sm text-muted-foreground">
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Important Notice</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </AlertDescription>
              </Alert>

              <Separator />

              {/* 1. Data Collection */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">1. Data Collection</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The app does not collect personal information from users.</li>
                  <li>Only stock information entered by the user is stored.</li>
                </ul>
              </div>

              {/* 2. Data Storage */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">2. Data Storage</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>All stock data is stored locally on your device using the browser's local storage.</li>
                  <li>The app does not upload your data to any server.</li>
                  <li>Users are responsible for managing their own device storage and data security.</li>
                </ul>
              </div>

              {/* 3. User Rights */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">3. User Rights</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Users can view and edit their stock data stored locally.</li>
                  <li>Users are responsible for securing their device to protect stored data.</li>
                </ul>
              </div>

              {/* 4. Security */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">4. Security</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Users must protect their device (lock screen, PIN, etc.) to prevent unauthorized access.</li>
                  <li>The app does not include built-in encryption or remote lock features.</li>
                </ul>
              </div>

              {/* 5. Third-Party Services and Ads */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">5. Third-Party Services and Ads</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>This app may use third-party advertising services, such as Google AdSense, to display advertisements.</li>
                  <li>These services may use cookies or other tracking technologies to collect anonymous usage data to serve relevant ads. This data does not include personally identifiable information like your name, address, or email.</li>
                   <li>For more information on how Google uses data, please see Google's Privacy & Terms.</li>
                </ul>
              </div>

              {/* 6. Changes to Privacy Policy */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">6. Changes to Privacy Policy</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>This Privacy Policy may be updated from time to time.</li>
                  <li>By continuing to use the app, you agree to any changes made.</li>
                </ul>
              </div>

              {/* 7. Contact */}
              <div>
                <h3 className="font-semibold text-foreground text-base mb-2">7. Contact</h3>
                <p>If you have questions about privacy or data handling, contact us:</p>
                <ul className="list-disc pl-5 mt-1 space-y-1">
                  <li><strong>Email (technical/privacy):</strong> soheltajani@gmail.com</li>
                  <li><strong>Email (suggestions/general):</strong> soheltajani@gmail.com</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
