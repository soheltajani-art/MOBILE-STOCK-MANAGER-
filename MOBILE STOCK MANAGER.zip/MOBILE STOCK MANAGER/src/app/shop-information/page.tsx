
'use client';

import { useEffect, useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

export type ShopInfo = {
  shopName: string;
  ownerName: string;
  mobileNumber: string;
  email: string;
  address: string;
};

const formSchema = z.object({
  shopName: z.string().min(1, 'Shop name is required.'),
  ownerName: z.string().min(1, 'Owner name is required.'),
  mobileNumber: z.string().regex(/^\d{10}$/, 'Mobile number must be 10 digits.'),
  email: z.string().email('Invalid email address.'),
  address: z.string().min(1, 'Address is required.'),
});

export default function ShopInfoSetupPage() {
  const router = useRouter();
  const [shopInfo, setShopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const [isMounted, setIsMounted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      shopName: '',
      ownerName: '',
      mobileNumber: '',
      email: '',
      address: '',
    },
  });

  useEffect(() => {
    setIsMounted(true);
    // If shopInfo already exists, this page is not needed, go to dashboard.
    // This handles the case where a user tries to navigate here manually.
    if (shopInfo) {
      router.replace('/dashboard');
    }
  }, [shopInfo, router]);

  const handleSave = (data: z.infer<typeof formSchema>) => {
    setShopInfo(data);
    toast.success("Shop Details Saved", {
      description: "Your shop details have been successfully saved."
    });
    router.replace('/dashboard');
  };

  if (!isMounted) {
    return null; // Or a loading spinner
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-16">
            <h1 className="text-xl font-bold text-foreground">
              Shop Information Setup
            </h1>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-start p-4 py-8">
        <Card className="w-full max-w-md shadow-2xl rounded-3xl bg-card">
          <CardHeader className="text-center p-6">
            <CardTitle className="text-2xl font-bold">
              Set Up Your Shop Details
            </CardTitle>
            <CardDescription>
              Please fill in your shop details to continue.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6 pt-0 space-y-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSave)} className="space-y-4">
                <FormField control={form.control} name="shopName" render={({ field }) => (
                  <FormItem><FormLabel>Shop Name</FormLabel><FormControl><Input placeholder="Enter shop name" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="ownerName" render={({ field }) => (
                  <FormItem><FormLabel>Owner Name</FormLabel><FormControl><Input placeholder="Enter owner's name" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="mobileNumber" render={({ field }) => (
                  <FormItem><FormLabel>Mobile Number</FormLabel><FormControl><Input type="tel" placeholder="Enter 10-digit mobile number" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="Enter email address" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem><FormLabel>Address</FormLabel><FormControl><Input placeholder="Enter shop address" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <Button type="submit" className="w-full h-12 text-lg">
                  <Save className="mr-2 h-5 w-5" />
                  Save and Go to Dashboard
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
