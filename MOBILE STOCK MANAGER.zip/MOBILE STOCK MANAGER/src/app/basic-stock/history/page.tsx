
'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Search,
  IndianRupee,
  History,
  LineChart,
  Package,
  Calendar as CalendarIcon,
  Loader2,
  PackagePlus,
} from 'lucide-react';
import { format, isSameDay, isSameMonth, isSameYear } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../../features/transfer-records/page';
import { Skeleton } from '@/components/ui/skeleton';
import { HistoryItemCard } from '../../features/history-item-card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';

interface BasicStockHistoryPageProps {
  onBack: () => void;
}

type FilterMode = 'day' | 'month' | 'year';

export default function BasicStockHistoryPage({ onBack }: BasicStockHistoryPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [filterMode, setFilterMode] = useState<FilterMode>('day');
  const [historyData] = useLocalStorage<HistoryItem[]>('basic-history', []);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const { filteredHistorySource, totalSales, totalProfit, totalSalesQuantity, totalPurchasesQuantity } =
    useMemo(() => {
      if (!isMounted) {
        return {
          filteredHistorySource: [],
          totalSales: 0,
          totalProfit: 0,
          totalSalesQuantity: 0,
          totalPurchasesQuantity: 0,
        };
      }

      let relevantHistoryForTotals = historyData;
      if (date) {
        relevantHistoryForTotals = historyData.filter((item) => {
          const itemDate = new Date(item.date);
          if (filterMode === 'day') return isSameDay(itemDate, date);
          if (filterMode === 'month') return isSameMonth(itemDate, date);
          if (filterMode === 'year') return isSameYear(itemDate, date);
          return true;
        });
      }
      
      const salesEvents = relevantHistoryForTotals.filter(item => item.type === 'Sale');
      const purchaseEvents = relevantHistoryForTotals.filter(item => item.type === 'Purchase');

      const totalSales = salesEvents.reduce((sum, item) => sum + (item.salePrice || 0), 0);
      const totalProfit = salesEvents.reduce((sum, item) => sum + ((item.salePrice || 0) - (item.purchasePrice || 0)), 0);
      const totalSalesQuantity = salesEvents.length;
      const totalPurchasesQuantity = purchaseEvents.length;


      // MERGE LOGIC
      const mergedActivity: HistoryItem[] = [];
      const processedIds = new Set<number>();
      
      const purchasesForMerge = relevantHistoryForTotals.filter(h => h.type === 'Purchase');
      const salesForMerge = relevantHistoryForTotals.filter(h => h.type === 'Sale');

      salesForMerge.forEach(sale => {
          if (processedIds.has(sale.id)) return;

          const saleIdMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
          if (!saleIdMatch) return;
          const productId = saleIdMatch[1];
          
          const correspondingPurchase = purchasesForMerge.find(purchase =>
              !processedIds.has(purchase.id) && purchase.details.includes(productId)
          );

          if (correspondingPurchase) {
              const mergedItem: HistoryItem = {
                  id: sale.id,
                  type: 'Purchase & Sale',
                  productName: sale.productName,
                  date: sale.date,
                  quantity: sale.quantity,
                  totalAmount: sale.totalAmount, // Sale price
                  purchasePrice: correspondingPurchase.purchasePrice,
                  salePrice: sale.salePrice,
                  details: `Profit: ${(sale.salePrice || 0) - (correspondingPurchase.purchasePrice || 0)}`,
                  purchaseDetails: correspondingPurchase.details,
                  saleDetails: sale.details,
              };
              mergedActivity.push(mergedItem);
              processedIds.add(sale.id);
              processedIds.add(correspondingPurchase.id);
          }
      });
      
      const otherActivities = relevantHistoryForTotals.filter(activity => !processedIds.has(activity.id));
      let history = [...mergedActivity, ...otherActivities];

      if (searchTerm) {
        history = history.filter(
          (item) =>
            item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (item.purchaseDetails && item.purchaseDetails.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (item.saleDetails && item.saleDetails.toLowerCase().includes(searchTerm.toLowerCase()))
        );
      }

      const sortedHistory = history
        .sort(
          (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
        );

      return { filteredHistorySource: sortedHistory, totalSales, totalProfit, totalSalesQuantity, totalPurchasesQuantity };
    }, [searchTerm, date, filterMode, historyData, isMounted]);

  const {
    items: filteredHistory,
    isLoadingMore,
    isReachingEnd,
    sentryRef,
  } = useInfiniteScroll({
    items: filteredHistorySource,
    itemsPerPage: 10,
  });

  const stats = [
    {
      title: 'Total Sales (Rupees)',
      value: totalSales.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: LineChart,
      color: 'text-white bg-gradient-to-br from-green-500 to-teal-500',
    },
    {
      title: 'Total Sales (Quantity)',
      value: totalSalesQuantity,
      icon: Package,
      color: 'text-white bg-gradient-to-br from-purple-500 to-indigo-600',
    },
     {
      title: 'Total Purchased',
      value: totalPurchasesQuantity,
      icon: PackagePlus,
      color: 'text-white bg-gradient-to-br from-blue-500 to-sky-600',
    },
    {
      title: 'Total Profit',
      value: totalProfit.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: IndianRupee,
      color: 'text-white bg-gradient-to-br from-cyan-500 to-blue-600',
    },
  ];

  return (
    <div className="flex flex-col h-full bg-background font-sans slide-in-from-right overflow-hidden">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Basic Stock History
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <ScrollArea className="flex-1">
        <main className="flex-1 flex flex-col p-4 md:p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
            {stats.map((stat) => (
              <Card
                key={stat.title}
                className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}
              >
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.title}
                  </CardTitle>
                  <stat.icon className="h-6 w-6" />
                </CardHeader>
                <CardContent>
                  {isMounted ? (
                    <div className="text-3xl font-bold">{typeof stat.value === 'number' && !stat.title.includes('Rupees') ? stat.value : stat.value}</div>
                  ) : (
                    <Skeleton className="h-10 w-3/4" />
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={'outline'}
                  className={cn(
                    'w-full md:w-[280px] justify-start text-left font-normal h-12 rounded-xl shadow-sm bg-card',
                    !date && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP') : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            <Select
              value={filterMode}
              onValueChange={(value: FilterMode) => setFilterMode(value)}
            >
              <SelectTrigger className="w-full md:w-[180px] h-12 rounded-xl shadow-sm bg-card">
                <SelectValue placeholder="Filter by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Day</SelectItem>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="year">Year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search by product name or details..."
              className="pl-10 bg-card rounded-xl shadow-sm h-12"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="bg-card shadow-lg rounded-2xl p-2 md:p-4">
              {!isMounted ? (
                <div className="space-y-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                </div>
              ) : filteredHistory.length > 0 ? (
                <div className="space-y-0">
                  {filteredHistory.map((item) => (
                    <HistoryItemCard key={item.id} item={item} />
                  ))}
                  <div ref={sentryRef} className="h-4">
                    {isLoadingMore && (
                      <div className="flex justify-center items-center">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-16">
                  <History className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-2 text-lg font-medium text-foreground">
                    No History Found
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    No records found for the selected period.
                  </p>
                </div>
              )}
            </div>
        </main>
      </ScrollArea>
    </div>
  );
}
