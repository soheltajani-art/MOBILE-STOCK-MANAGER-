
'use client';

import {
  ArrowLeft,
  Box,
  ChevronRight,
  Cog,
  History,
  MapPin,
  Repeat,
  ShoppingBag,
  Trash2,
  Tv,
  Users,
  Wrench,
  TrendingUp,
  Hourglass,
  DollarSign,
  Info,
  Save,
  FileText,
  Award,
  Globe,
  Palette,
  Shield,
  Package as InventoryIcon,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';


type Feature = {
  title: string;
  description: string;
  icon: LucideIcon;
  iconColor: string;
  iconBgColor: string;
  href?: string;
  onClick?: () => void;
};

type FeatureSection = {
  title: string;
  icon: LucideIcon;
  features: Feature[];
};

export default function FeaturesPage() {
  const router = useRouter();
  
  const featureSections: FeatureSection[] = [
    {
      title: 'Stock & Sales',
      icon: Box,
      features: [
        {
          title: 'WHERE IS MY PRODUCT',
          description:
            'Search for any product to see its complete history, from purchase to sale, including all transfers.',
          icon: MapPin,
          iconColor: 'text-green-500',
          iconBgColor: 'bg-green-100',
          href: '/features/where-is-my-product',
        },
      ],
    },
    {
      title: 'History & Analytics',
      icon: TrendingUp,
      features: [
        {
          title: 'MAIN HISTORY',
          description: 'View sales and direct purchase history, including profit calculations for direct sales.',
          icon: History,
          iconColor: 'text-purple-500',
          iconBgColor: 'bg-purple-100',
          href: '/features/main-history',
        },
         {
          title: 'TRANSFER SUMMARY',
          description: 'Analyze profit from settled transfers, including items transferred out and items sold after being transferred in.',
          icon: TrendingUp,
          iconColor: 'text-teal-500',
          iconBgColor: 'bg-teal-100',
          href: '/features/transfer-summary',
        },
        {
          title: 'TRANSFER RECORDS',
          description: 'See all product transfer records. Settle unpaid transfers or reverse pending ones.',
          icon: Repeat,
          iconColor: 'text-cyan-500',
          iconBgColor: 'bg-cyan-100',
          href: '/features/transfer-records',
        },
        {
          title: 'LIFETIME HISTORY',
          description: 'A complete archive of every product ever entered into the main inventory, including sold items.',
          icon: History,
          iconColor: 'text-orange-500',
          iconBgColor: 'bg-orange-100',
          href: '/features/lifetime-history',
        },
        {
          title: 'REVERSE TRANSFERS',
          description: 'A log of all transfers that have been reversed, including the reason for reversal.',
          icon: Repeat,
          iconColor: 'text-pink-500',
          iconBgColor: 'bg-pink-100',
          href: '/features/reverse-transfers',
        },
      ],
    },
    {
      title: 'Tools & Settings',
      icon: Cog,
      features: [
         {
          title: 'SHOP INFORMATION',
          description: 'View your saved shop details.',
          icon: ShoppingBag,
          iconColor: 'text-orange-500',
          iconBgColor: 'bg-orange-100',
          href: '/features/shop-info',
        },
        {
            title: 'MANAGE SHOP TEAM',
            description: 'This feature is currently under development.',
            icon: Users,
            iconColor: 'text-sky-500',
            iconBgColor: 'bg-sky-100',
            href: '/features/not-implemented',
        },
        {
          title: 'BACKUP & RESTORE',
          description: 'Save all your app data to a file or restore it from a backup.',
          icon: Save,
          iconColor: 'text-indigo-500',
          iconBgColor: 'bg-indigo-100',
          href: '/features/backup-restore',
        },
        {
          title: 'HELP & SUPPORT',
          description: 'Access the App Guide or contact us for bug reports and feature suggestions.',
          icon: Info,
          iconColor: 'text-blue-500',
          iconBgColor: 'bg-blue-100',
          href: '/features/help-support',
        },
         {
          title: 'MY AGREEMENTS',
          description: 'View the agreements, terms, and policies you accepted.',
          icon: FileText,
          iconColor: 'text-gray-500',
          iconBgColor: 'bg-gray-100',
          href: '/features/user-agreement',
        },
        {
          title: 'RESET ALL DATA',
          description: 'WARNING: Permanently deletes all app data. This action cannot be undone.',
          icon: Trash2,
          iconColor: 'text-red-500',
          iconBgColor: 'bg-red-100',
          href: '/features/reset-data',
        },
      ],
    },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background font-sans slide-in-from-right">
      <header className="bg-card shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
              <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">Features</h1>
            <Link href="/features/basic-stock">
                <Button variant="outline" size="sm">
                    Basic Stock
                </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 space-y-6 pb-20">
        {featureSections.map((section, sectionIndex) => (
          <div key={section.title}>
            <div className="flex items-center space-x-2 mb-4 px-2">
              <section.icon className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-lg font-semibold text-foreground">{section.title}</h2>
            </div>
             <div className="space-y-3">
              {section.features.map((feature, featureIndex) => {
                const featureContent = (
                   <Card
                    className="bg-card shadow-md rounded-2xl hover:bg-accent transition-colors"
                  >
                    <div className="p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-4 min-w-0">
                        <div className={`p-2.5 rounded-full ${feature.iconBgColor}`}>
                          <feature.icon className={`h-5 w-5 ${feature.iconColor}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-foreground truncate">{feature.title}</p>
                          {feature.description && (
                            <p className="text-sm text-muted-foreground">{feature.description}</p>
                          )}
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
                    </div>
                  </Card>
                );

                const commonProps = {
                   className: "block animate-fade-in-up",
                   style: { animationDelay: `${(sectionIndex * 3 + featureIndex) * 75}ms`, opacity: 0, animationFillMode: 'forwards' }
                };
                
                if(feature.href) {
                  return (
                    <Link key={feature.title} href={feature.href} replace {...commonProps}>
                      {featureContent}
                    </Link>
                  );
                }
                
                return (
                  <div key={feature.title} onClick={feature.onClick} {...commonProps}>
                    {featureContent}
                  </div>
                );

              })}
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}
