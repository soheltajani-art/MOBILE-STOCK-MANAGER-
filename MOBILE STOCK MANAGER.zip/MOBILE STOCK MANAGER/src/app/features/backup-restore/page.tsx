
'use client';

import { useState, useRef, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, Download, Upload, AlertTriangle, Loader2, Save, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

function BackupRestoreContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const mode = searchParams.get('mode');
  const isRestoreOnly = mode === 'restore_only';

  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [fileToRestore, setFileToRestore] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleBackup = () => {
    setIsBackingUp(true);
    toast.info('Creating backup...');

    setTimeout(() => {
      try {
        const backupData: { [key: string]: any } = {};
        // Get all keys from localStorage
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key) {
            // Read raw value instead of parsing, as not all values are JSON
            backupData[key] = localStorage.getItem(key);
          }
        }

        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
        a.href = url;
        a.download = `stock-manager-backup-${timestamp}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast.success('Backup Successful!', {
          description: 'Your data has been downloaded as a JSON file.',
        });
      } catch (error) {
        console.error('Failed to create backup:', error);
        toast.error('Backup Failed', {
          description: 'Could not create backup file. Please try again.',
        });
      } finally {
        setIsBackingUp(false);
      }
    }, 500);
  };
  
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/json') {
      setFileToRestore(file);
      setShowRestoreConfirm(true);
    } else {
        toast.error('Invalid File', {
            description: 'Please select a valid JSON backup file.',
        });
    }
    // Reset file input to allow selecting the same file again
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  const handleRestore = () => {
    if (!fileToRestore) return;
    setIsRestoring(true);
    toast.info('Restoring data...');

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const dataToRestore = JSON.parse(event.target?.result as string);
            
            // Preserve the lock status of shop info from the CURRENT device
            const shopInfoChangedOnce = localStorage.getItem('shopInfoChangedOnce');

            // Clear existing data first
            localStorage.clear();

            // Restore new data
            Object.keys(dataToRestore).forEach(key => {
                // The value is already a string from the backup, no need to stringify
                localStorage.setItem(key, dataToRestore[key]);
            });
            
            // Restore the preserved lock status
            if (shopInfoChangedOnce) {
                localStorage.setItem('shopInfoChangedOnce', shopInfoChangedOnce);
            }
             // Since this is a restore, mark welcome as seen.
            localStorage.setItem('hasSeenWelcome', 'true');

            toast.success('Restore Successful!', {
                description: 'Your data has been restored. The app will now reload.',
            });

            setTimeout(() => {
                window.location.href = '/';
            }, 1500);

        } catch (error) {
            console.error('Failed to restore data:', error);
            toast.error('Restore Failed', {
                description: 'The selected file is not a valid backup. Please check the file and try again.',
            });
            setIsRestoring(false);
        }
    };
    reader.onerror = () => {
        toast.error('File Read Error', {
            description: 'Could not read the selected file.',
        });
        setIsRestoring(false);
    };
    reader.readAsText(fileToRestore);
  };

  return (
    <>
      <div className="flex flex-col h-screen bg-background font-sans slide-in-from-right">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
              </Button>
              <h1 className="text-xl font-bold text-foreground">
                Backup &amp; Restore
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-4 space-y-6">
            <Card className="w-full max-w-md shadow-2xl rounded-3xl bg-card">
                <CardHeader className="text-center">
                    <div className="mx-auto bg-indigo-100 p-4 rounded-full mb-4 inline-block">
                        <Save className="h-10 w-10 text-indigo-500" />
                    </div>
                    <CardTitle className="text-2xl font-bold">Data Management</CardTitle>
                    <CardDescription>
                       {isRestoreOnly ? 'Restore your data from a backup file.' : 'Save your data to a file or restore it.'}
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                    {!isRestoreOnly && (
                        <Button 
                            onClick={handleBackup} 
                            disabled={isBackingUp}
                            className="w-full h-14 text-lg bg-blue-600 hover:bg-blue-700 rounded-xl"
                        >
                            {isBackingUp ? (
                                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                            ) : (
                                <Download className="mr-2 h-5 w-5" />
                            )}
                            {isBackingUp ? 'Backing Up...' : 'Backup All Data'}
                        </Button>
                    )}
                    
                    <Button 
                        onClick={() => fileInputRef.current?.click()} 
                        disabled={isRestoring}
                        variant="outline"
                        className="w-full h-14 text-lg border-blue-600 text-blue-600 hover:bg-blue-50 hover:text-blue-700 rounded-xl"
                    >
                         {isRestoring ? (
                            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        ) : (
                            <Upload className="mr-2 h-5 w-5" />
                        )}
                        {isRestoring ? 'Restoring...' : 'Restore From Backup'}
                    </Button>
                    <Input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileSelect}
                        className="hidden"
                        accept=".json"
                    />

                    <Alert className="bg-blue-50 border-blue-200 mt-6">
                      <Info className="h-4 w-4 text-blue-600" />
                      <AlertTitle className="text-blue-800">Sync Notice</AlertTitle>
                      <AlertDescription className="text-blue-700">
                        This app does not support accurate real-time sync. For a full and reliable data transfer, use the Backup & Restore feature.
                      </AlertDescription>
                    </Alert>

                </CardContent>
            </Card>
        </main>
      </div>
      <AlertDialog open={showRestoreConfirm} onOpenChange={setShowRestoreConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              Restoring from a backup will <span className="font-bold text-red-600">overwrite all current data</span> in the application. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsRestoring(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleRestore} className="bg-red-600 hover:bg-red-700" disabled={isRestoring}>
                {isRestoring && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isRestoring ? 'Restoring...' : 'Yes, Overwrite and Restore'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

export default function BackupRestorePage() {
    return (
        <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin"/></div>}>
            <BackupRestoreContent />
        </Suspense>
    )
}
