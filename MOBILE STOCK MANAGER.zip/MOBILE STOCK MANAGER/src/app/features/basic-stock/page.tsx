
'use client';

import {
  ArrowLeft,
  History,
  Loader2,
  LineChart,
  Package,
  PackageMinus,
  PackagePlus,
  Search,
  IndianRupee,
  CircleDollarSign,
} from 'lucide-react';
import { useState, useMemo, useEffect, useRef } from 'react';
import Link from 'next/link';
import type { LucideIcon } from 'lucide-react';
import { formatDistanceToNow, isToday } from 'date-fns';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';
import { type Product } from '../where-is-my-product/page';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';
import BasicStockHistoryPage from './history/page';
import ProductDetailsModal from '@/app/product-details-modal';
import { toast } from 'sonner';

type BasicProduct = Product;

const activityIconMap: Record<string, LucideIcon> = {
  Sale: PackageMinus,
  Purchase: PackagePlus,
  'Purchase & Sale': PackageMinus,
};

export default function BasicStockPage() {
  const router = useRouter();
  const [activeView, setActiveView] = useState('dashboard');

  const [products, setProducts] = useLocalStorage<BasicProduct[]>('basic-products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('basic-history', []);
  const [isMounted, setIsMounted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const {
    totalStock,
    todaysSaleQuantity,
    todaysPurchaseQuantity,
    todaysSalesRupees,
    todaysProfit,
    allRecentActivity,
  } = useMemo(() => {
    if (!isMounted) {
      return {
        totalStock: 0,
        todaysSaleQuantity: 0,
        todaysPurchaseQuantity: 0,
        todaysSalesRupees: 0,
        todaysProfit: 0,
        allRecentActivity: [],
      };
    }

    const todaysFullHistory = history.filter((item) => isToday(new Date(item.date)));
    const todaysSales = todaysFullHistory.filter((item) => item.type === 'Sale');
    const todaysPurchases = todaysFullHistory.filter((item) => item.type === 'Purchase');

    const todaysSaleQuantity = todaysSales.reduce(
      (sum, item) => sum + item.quantity,
      0
    );

    const todaysPurchaseQuantity = todaysPurchases.reduce(
      (sum, item) => sum + item.quantity,
      0
    );

    const todaysSalesRupees = todaysSales.reduce(
      (sum, item) => sum + (item.salePrice || 0),
      0
    );

    const todaysProfit = todaysSales.reduce(
      (sum, item) => sum + ((item.salePrice || 0) - (item.purchasePrice || 0)),
      0
    );

    const totalStock = products.reduce(
      (sum, product) => sum + (product.stock || 0),
      0
    );

    // --- MERGE LOGIC ---
    const mergedActivity: HistoryItem[] = [];
    const processedIds = new Set<number>();
    
    const purchasesForMerge = todaysFullHistory.filter(h => h.type === 'Purchase');
    const salesForMerge = todaysFullHistory.filter(h => h.type === 'Sale');

    salesForMerge.forEach(sale => {
        if (processedIds.has(sale.id)) return;

        const saleIdMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
        if (!saleIdMatch) return;
        const productId = saleIdMatch[1];
        
        const correspondingPurchase = purchasesForMerge.find(purchase =>
            !processedIds.has(purchase.id) && purchase.details.includes(productId)
        );

        if (correspondingPurchase) {
            const mergedItem: HistoryItem = {
                id: sale.id, // Use sale event's ID for uniqueness
                type: 'Purchase & Sale',
                productName: sale.productName,
                date: sale.date,
                quantity: sale.quantity,
                totalAmount: sale.totalAmount,
                purchasePrice: correspondingPurchase.purchasePrice,
                salePrice: sale.salePrice,
                details: `Profit: ${(sale.salePrice || 0) - (correspondingPurchase.purchasePrice || 0)}`,
                purchaseDetails: correspondingPurchase.details,
                saleDetails: sale.details,
            };
            mergedActivity.push(mergedItem);
            processedIds.add(sale.id);
            processedIds.add(correspondingPurchase.id);
        }
    });

    const otherActivities = todaysFullHistory.filter(activity => !processedIds.has(activity.id));
    const combined = [...mergedActivity, ...otherActivities];

    const sortedHistory = combined.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const allRecentActivity = sortedHistory.map((activity) => ({
      ...activity,
      icon: activityIconMap[activity.type] || Package,
      title: activity.type === 'Purchase & Sale' ? `Sale: ${activity.productName}` : `${activity.type}: ${activity.productName}`,
      description: activity.type === 'Purchase & Sale'
        ? `Profit: ${(activity.salePrice! - activity.purchasePrice!).toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}`
        : `Qty: ${activity.quantity} - ${activity.details}`,
      time: formatDistanceToNow(new Date(activity.date), { addSuffix: true }),
    }));

    return {
      totalStock,
      todaysSaleQuantity,
      todaysPurchaseQuantity,
      todaysSalesRupees,
      todaysProfit,
      allRecentActivity,
    };
  }, [products, history, isMounted]);

  const filteredProducts = useMemo(() => {
    if (!searchTerm) return products;
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.id.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [products, searchTerm]);


  const {
    items: recentActivity,
    isLoadingMore,
    sentryRef,
  } = useInfiniteScroll({
    items: allRecentActivity,
    itemsPerPage: 10,
  });
  
  const getProductHistory = (product: Product | null): HistoryItem[] => {
    if (!product) return [];

    const relatedEvents = history.filter((event) => {
        const details = event.details?.toLowerCase() || '';
        const id1Match = details.includes(product.id.toLowerCase());
        const id2Match = product.id2 ? details.includes(product.id2.toLowerCase()) : false;
        return id1Match || id2Match;
    });

    const saleEvent = relatedEvents.find(e => e.type === 'Sale');
    const purchaseEvent = relatedEvents.find(e => e.type === 'Purchase');

    if (saleEvent && purchaseEvent) {
      const mergedItem: HistoryItem = {
        id: saleEvent.id,
        type: 'Purchase & Sale',
        productName: product.name,
        date: saleEvent.date,
        quantity: saleEvent.quantity,
        totalAmount: saleEvent.totalAmount,
        purchasePrice: purchaseEvent.purchasePrice,
        salePrice: saleEvent.salePrice,
        details: '',
        purchaseDetails: purchaseEvent.details,
        saleDetails: saleEvent.details,
      };
      return [mergedItem];
    }
    
    return relatedEvents.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const handleActivityClick = (activity: HistoryItem) => {
    const idRegex = /ID1?:\s*([^\s,]+)/i;
    let detailsString = '';

    if (activity.type === 'Purchase & Sale' && activity.purchaseDetails) {
        detailsString = activity.purchaseDetails;
    } else {
        detailsString = activity.details || '';
    }
    
    const match = detailsString.match(idRegex);
    const lookupId = match ? match[1].toLowerCase() : null;


    if (!lookupId) {
      toast.error('Product ID not found in activity.');
      return;
    }

    let product = products.find(p => p.id.toLowerCase() === lookupId || (p.id2 && p.id2.toLowerCase() === lookupId));

    if (product) {
        setSelectedProduct(product);
    } else {
        // If not found in current products (it might be sold), find its purchase record to reconstruct it
        const purchaseRecord = history.find(h => 
            h.type === 'Purchase' && h.details.toLowerCase().includes(`id1: ${lookupId}`)
        );
        if (purchaseRecord) {
            const colorMatch = purchaseRecord.details.match(/^([^,]+),/);
            const id2Match = purchaseRecord.details.match(/ID2:\s*([^\s,]+)/i);

            const reconstructedProduct: Product = {
                id: lookupId.toUpperCase(),
                id2: id2Match ? id2Match[1] : undefined,
                name: purchaseRecord.productName,
                stock: 0, // It's sold
                ram: '', // Basic stock doesn't have this
                storage: '', // Basic stock doesn't have this
                color: colorMatch ? colorMatch[1] : 'N/A',
                purchasePrice: purchaseRecord.purchasePrice || 0,
            };
            setSelectedProduct(reconstructedProduct);
        } else {
            toast.error('Product not found in Basic Stock.');
        }
    }
  };


  const stats = [
    {
      title: 'Total Stock',
      value: totalStock,
      icon: Package,
      color: 'text-white bg-gradient-to-br from-purple-500 to-indigo-600',
    },
    {
      title: "Today's Purchases",
      value: todaysPurchaseQuantity,
      icon: PackagePlus,
      color: 'text-white bg-gradient-to-br from-blue-500 to-sky-600',
    },
    {
      title: "Today's Sold Out",
      value: todaysSaleQuantity,
      icon: PackageMinus,
      color: 'text-white bg-gradient-to-br from-green-500 to-teal-500',
    },
  ];

  const tertiaryStats = [
    {
      title: 'Today’s Sales (Rupees)',
      value: todaysSalesRupees.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: CircleDollarSign,
      color: 'text-white bg-gradient-to-br from-pink-500 to-red-600',
    },
    {
      title: "Today's Profit",
      value: todaysProfit.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: IndianRupee,
      color: 'text-white bg-gradient-to-br from-cyan-500 to-blue-600',
    },
  ];

  if (activeView === 'history') {
    return <BasicStockHistoryPage onBack={() => setActiveView('dashboard')} />;
  }

  return (
    <>
      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          history={getProductHistory(selectedProduct)}
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
      <div className="flex flex-col h-full bg-background font-sans slide-in-from-right">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
              </Button>
              <h1 className="text-xl font-bold text-foreground">
                Basic Stock
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>
        <main className="flex-1 flex flex-col p-4 md:p-6 space-y-6 pb-20 overflow-hidden">
          <ScrollArea className="flex-1 -mx-4" ref={scrollRef}>
            <div className="px-4 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {stats.map((stat) => (
                  <Card
                    key={stat.title}
                    className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}
                  >
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">
                        {stat.title}
                      </CardTitle>
                      <stat.icon className="h-6 w-6" />
                    </CardHeader>
                    <CardContent>
                      {isMounted ? (
                        <div className="text-4xl font-bold">{stat.value}</div>
                      ) : (
                        <Skeleton className="h-10 w-1/2" />
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tertiaryStats.map((stat) => (
                  <Card
                    key={stat.title}
                    className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}
                  >
                    <CardContent className="p-6">
                      <p className="text-sm">{stat.title}</p>
                      {isMounted ? (
                        <p className="text-3xl font-bold">{stat.value}</p>
                      ) : (
                        <Skeleton className="h-9 w-3/4 mt-1" />
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search products by Name or ID..."
                  className="pl-10 bg-card rounded-xl shadow-sm h-12"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4 text-foreground">
                  Recent Activity
                </h2>
                <Card className="bg-card shadow rounded-2xl">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      {isMounted && recentActivity.length > 0 ? (
                        <>
                          {recentActivity.map((activity) => (
                            <div
                              key={activity.id}
                              className="flex items-center space-x-4 p-2 rounded-lg cursor-pointer"
                              onClick={() => handleActivityClick(activity)}
                            >
                              <div className="bg-muted p-3 rounded-full">
                                <activity.icon className="h-5 w-5 text-muted-foreground" />
                              </div>
                              <div className="flex-1">
                                <p className="font-semibold text-foreground">
                                  {activity.title}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {activity.description}
                                </p>
                              </div>
                              <p className="text-sm text-muted-foreground">{activity.time}</p>
                            </div>
                          ))}
                          <div ref={sentryRef} className="h-4">
                            {isLoadingMore && (
                              <div className="flex justify-center items-center">
                                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                              </div>
                            )}
                          </div>
                        </>
                      ) : isMounted && allRecentActivity.length === 0 ? (
                        <div className="text-center text-muted-foreground py-10">
                          <p>No recent activity today.</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {[...Array(3)].map((_, i) => (
                            <div key={i} className="flex items-center space-x-4">
                              <Skeleton className="h-12 w-12 rounded-full" />
                              <div className="flex-1 space-y-2">
                                <Skeleton className="h-4 w-3/4" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-4 w-1/4" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </ScrollArea>
        </main>

        <footer className="fixed bottom-0 left-0 right-0 bg-card border-t border-border flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-around items-center h-16">
              <Link href="/basic-stock/purchase" className="flex flex-col items-center justify-center h-full text-xs space-y-1 text-muted-foreground">
                  <PackagePlus className="h-5 w-5" />
                  <span>Purchase</span>
              </Link>
              <Link href="/basic-stock/sell" className="flex flex-col items-center justify-center h-full text-xs space-y-1 text-muted-foreground">
                  <PackageMinus className="h-5 w-5" />
                  <span>Sold Out</span>
              </Link>
              <Button variant="ghost" onClick={() => setActiveView('history')} className="flex flex-col items-center justify-center h-full text-xs space-y-1 text-muted-foreground">
                  <History className="h-5 w-5" />
                  <span>History</span>
              </Button>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
