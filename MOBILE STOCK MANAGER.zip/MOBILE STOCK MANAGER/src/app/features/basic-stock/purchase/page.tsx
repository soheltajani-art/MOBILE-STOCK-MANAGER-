
'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ScanLine } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { Product } from '../../where-is-my-product/page';
import type { HistoryItem } from '../../transfer-records/page';
import BarcodeScanner from '@/components/barcode-scanner';
import { ScrollArea } from '@/components/ui/scroll-area';

const formSchema = z.object({
  name: z.string().min(1, 'Model number is required.'),
  id: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.'),
  id2: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.')
    .optional().or(z.literal('')),
  color: z.string().min(1, 'Color is required.'),
  purchasePrice: z.coerce
    .number()
    .min(1, 'Purchase price must be greater than 0.'),
});

type PurchaseFormValues = z.infer<typeof formSchema>;

export default function BasicStockPurchasePage() {
  const router = useRouter();
  const [products, setProducts] = useLocalStorage<Product[]>('basic-products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('basic-history', []);
  const [showScanner, setShowScanner] = useState(false);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);

  const form = useForm<PurchaseFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      id: '',
      id2: '',
      color: '',
      purchasePrice: '' as any,
    },
  });

  const handleScan = (barcodes: string[]) => {
    if (barcodes.length === 1) {
      form.setValue('id', barcodes[0]);
    } else if (barcodes.length > 1) {
      form.setValue('id', barcodes[0]);
      form.setValue('id2', barcodes[1]);
    }
    setShowScanner(false);
  };

  const onSubmit = (data: PurchaseFormValues) => {
    const isDuplicateProduct = products.some(p => {
      if (data.id && (p.id === data.id || (p.id2 && p.id2 === data.id))) {
        return true;
      }
      if (data.id2 && (p.id === data.id2 || (p.id2 && p.id2 === data.id2))) {
        return true;
      }
      return false;
    });

    if (isDuplicateProduct) {
      setShowDuplicateDialog(true);
      return;
    }

    const newProduct: Product = { ...data, stock: 1, ram: '', storage: '' }; // Add empty ram/storage for type consistency
    setProducts((prev) => [...prev, newProduct]);

    let details = `${data.color} - ID1: ${data.id}`;
    if (data.id2) {
      details += `, ID2: ${data.id2}`;
    }
    
    const historyEntry: HistoryItem = {
      id: Date.now(),
      date: new Date(),
      type: 'Purchase',
      productName: data.name,
      quantity: 1,
      totalAmount: data.purchasePrice,
      purchasePrice: data.purchasePrice,
      details: details,
    };
    setHistory((prev) => [historyEntry, ...prev]);

    toast.success('Stock Purchased!', {
        description: `${data.name} added to basic stock.`
    });
    router.push('/features/basic-stock');
  };

  return (
    <>
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
          scanLimit={2}
        />
      )}
      <AlertDialog open={showDuplicateDialog} onOpenChange={setShowDuplicateDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate Product</AlertDialogTitle>
            <AlertDialogDescription>
              A product with this ID is already in your basic stock.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowDuplicateDialog(false)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="flex flex-col h-screen bg-gray-50 font-sans">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.back()}>
                <ArrowLeft className="h-6 w-6 text-gray-700" />
              </Button>
              <h1 className="text-xl font-bold text-gray-900">
                Purchase Basic Stock
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col flex-1"
          >
            <ScrollArea className="flex-1">
              <main className="p-4 md:p-6">
                <Card className="bg-white shadow-lg rounded-2xl">
                  <CardContent className="p-6 space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Model No. of Mobile</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter model number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="space-y-1">
                      <FormField
                        control={form.control}
                        name="id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 1 (IMEI)</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter 15-digit PRODUCT ID"
                                {...field}
                                maxLength={15}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="id2"
                        render={({ field }) => (
                          <FormItem className="mt-2">
                            <FormLabel>PRODUCT ID 2 (IMEI, Optional)</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter 15-digit PRODUCT ID"
                                {...field}
                                maxLength={15}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <Button id="scan-barcodes-button" type="button" variant="outline" className="w-full mt-2" onClick={() => setShowScanner(true)}>
                          <ScanLine className="mr-2 h-4 w-4" />
                          Scan Barcodes
                      </Button>
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>COLOUR</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter colour" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="purchasePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retailer's Buying Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Enter price"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </main>
            </ScrollArea>
            <div className="sticky bottom-0 p-4 bg-white border-t">
              <Button
                type="submit"
                className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-lg"
              >
                + PURCHASE STOCK
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </>
  );
}
    
