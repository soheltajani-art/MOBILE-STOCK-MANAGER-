
'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ScanLine, Loader2 } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { Product } from '../../where-is-my-product/page';
import type { HistoryItem } from '../../transfer-records/page';
import BarcodeScanner from '@/components/barcode-scanner';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const formSchema = z.object({
  name: z.string().min(1, 'Model number is required.'),
  id: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.'),
  id2: z
    .string()
    .length(15, 'Product ID must be exactly 15 digits.')
    .optional()
    .or(z.literal('')),
  color: z.string().min(1, 'Color is required.'),
  salePrice: z.coerce.number().min(1, 'Sale price must be greater than 0.'),
  billNo: z.string().optional().or(z.literal('')),
  paymentMethod: z.enum(['cash', 'finance']),
  financeName: z.string().optional(),
}).refine((data) => {
    if (data.paymentMethod === 'finance') {
        return !!data.financeName && data.financeName.length > 0;
    }
    return true;
}, {
    message: 'Finance name is required when payment method is Finance.',
    path: ['financeName'],
});


type StockOutFormValues = z.infer<typeof formSchema>;

type LookupStatus = {
    message: string;
    type: 'success' | 'error' | 'idle';
}

export default function BasicStockSellPage() {
  const router = useRouter();
  const [showScanner, setShowScanner] = useState(false);
  const [products, setProducts] = useLocalStorage<Product[]>('basic-products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('basic-history', []);
  const [isCheckingId, setIsCheckingId] = useState(false);
  const [lookupStatus, setLookupStatus] = useState<LookupStatus>({ message: '', type: 'idle' });
  const [showAlreadySoldDialog, setShowAlreadySoldDialog] = useState(false);
  
  const form = useForm<StockOutFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      id: '',
      id2: '',
      color: '',
      salePrice: '' as any,
      billNo: '',
      paymentMethod: 'cash',
      financeName: '',
    },
  });

  const paymentMethod = form.watch('paymentMethod');

  const findAndFillProduct = (productId: string) => {
    if (!productId) return;
    setIsCheckingId(true);
    form.clearErrors('id');
    setLookupStatus({ message: '', type: 'idle' });
    
    setTimeout(() => {
        const product = products.find(
          (p) => (p.id === productId || (p.id2 && p.id2 === productId))
        );

        if (product) {
            form.setValue('name', product.name);
            form.setValue('id', product.id);
            if (product.id2) {
              form.setValue('id2', product.id2);
            }
            form.setValue('color', product.color);
            form.clearErrors('id');
            
            if (product.stock <= 0) {
                setShowAlreadySoldDialog(true);
                setLookupStatus({ message: 'Product is already sold out.', type: 'error' });
            } else {
                setLookupStatus({ message: 'Product found and auto-filled.', type: 'success' });
            }
        } else {
           form.setError('id', { type: 'manual', message: 'Product not found in basic stock.' });
           setLookupStatus({ message: 'Product not found in basic stock.', type: 'error' });
        }
        setIsCheckingId(false);
    }, 500);
  };

  const handleScan = (barcodes: string[]) => {
     if (barcodes.length > 0) {
      findAndFillProduct(barcodes[0]);
    }
    setShowScanner(false);
  };

  const onSubmit = (data: StockOutFormValues) => {
    // Check for duplicate bill number
    if (data.billNo) {
        const isDuplicateBillNo = history.some(item => 
            item.type === 'Sale' && item.details && item.details.includes(`Bill: ${data.billNo}`)
        );
        if (isDuplicateBillNo) {
            form.setError('billNo', { type: 'manual', message: 'This bill number is already in use.' });
            return;
        }
    }

    const productIndex = products.findIndex(
      (p) => (p.id === data.id || (p.id2 && p.id2 === data.id))
    );

    if (productIndex === -1) {
      form.setError('id', { type: 'manual', message: 'Product not found in basic stock.' });
      return;
    }
    
    const product = products[productIndex];
    
    if (product.stock <= 0) {
        setShowAlreadySoldDialog(true);
        return;
    }
    
    const updatedProducts = [...products];
    updatedProducts[productIndex] = { ...product, stock: 0 };
    setProducts(updatedProducts);
    
    const detailsParts = [
      data.color,
      `ID1: ${data.id}`,
    ];
    if (data.id2) {
      detailsParts.push(`ID2: ${data.id2}`);
    }
    if (data.billNo) {
      detailsParts.push(`Bill: ${data.billNo}`);
    }
    detailsParts.push(`Sold via ${data.paymentMethod === 'cash' ? 'Cash' : `Finance: ${data.financeName}`}`);

    const details = detailsParts.join(', ');

    const historyEntry: HistoryItem = {
      id: Date.now(),
      date: new Date(),
      type: 'Sale',
      productName: data.name,
      quantity: 1,
      totalAmount: data.salePrice,
      salePrice: data.salePrice,
      purchasePrice: product.purchasePrice,
      details: details,
    };
    setHistory((prev) => [historyEntry, ...prev]);
    
    toast.success('Stock Sold!', {
      description: `${data.name} has been marked as sold.`
    });
    router.push('/features/basic-stock');
  };

  return (
    <>
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
          scanLimit={1}
        />
      )}
       <AlertDialog open={showAlreadySoldDialog} onOpenChange={setShowAlreadySoldDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Product Already Sold</AlertDialogTitle>
            <AlertDialogDescription>
              This product has already been sold and cannot be sold again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowAlreadySoldDialog(false)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <div className="flex flex-col h-screen bg-gray-50 font-sans">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.back()}>
                <ArrowLeft className="h-6 w-6 text-gray-700" />
              </Button>
              <h1 className="text-xl font-bold text-gray-900">
                Sell Basic Stock
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col flex-1"
          >
            <ScrollArea className="flex-1">
              <main className="p-4 md:p-6">
                <Card className="bg-white shadow-lg rounded-2xl">
                  <CardContent className="p-6 space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Model No. of Mobile</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter model number" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="space-y-1">
                      <FormField
                        control={form.control}
                        name="id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 1 (IMEI)</FormLabel>
                            <FormControl>
                              <div className="relative">
                                  <Input
                                  placeholder="Enter 15-digit PRODUCT ID"
                                  {...field}
                                  maxLength={15}
                                  onBlur={(e) => findAndFillProduct(e.target.value)}
                                  />
                                  {isCheckingId && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 animate-spin" />}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="id2"
                        render={({ field }) => (
                          <FormItem className="mt-2">
                            <FormLabel>PRODUCT ID 2 (IMEI, Optional)</FormLabel>
                             <FormControl>
                               <div className="relative">
                                  <Input
                                  placeholder="Enter 15-digit PRODUCT ID"
                                  {...field}
                                  maxLength={15}
                                  onBlur={(e) => findAndFillProduct(e.target.value)}
                                  />
                                  {isCheckingId && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 animate-spin" />}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       {lookupStatus.type !== 'idle' && (
                          <div className={cn("mt-2 text-sm text-center font-medium", {
                              'text-green-600': lookupStatus.type === 'success',
                              'text-red-600': lookupStatus.type === 'error',
                          })}>
                              {lookupStatus.message}
                          </div>
                      )}
                      <Button
                        id="scan-barcodes-button"
                        type="button"
                        variant="outline"
                        className="w-full mt-2"
                        onClick={() => setShowScanner(true)}
                      >
                        <ScanLine className="mr-2 h-4 w-4" />
                        Scan Barcode
                      </Button>
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>COLOUR</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter colour" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="salePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retailer's Selling Price</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Enter price"
                              {...field}
                              onFocus={() => setLookupStatus({ message: '', type: 'idle' })}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="billNo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bill No.</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter bill number (optional)" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger onFocus={() => setLookupStatus({ message: '', type: 'idle' })}>
                                <SelectValue placeholder="Select a payment method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="cash">Cash</SelectItem>
                              <SelectItem value="finance">Finance</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {paymentMethod === 'finance' && (
                      <FormField
                        control={form.control}
                        name="financeName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Finance Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter name of financier" {...field} onFocus={() => setLookupStatus({ message: '', type: 'idle' })}/>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </CardContent>
                </Card>
              </main>
            </ScrollArea>
            <div className="sticky bottom-0 p-4 bg-white border-t">
              <Button
                type="submit"
                className="w-full h-12 bg-red-600 hover:bg-red-700 text-white rounded-xl text-lg"
              >
                SOLD STOCK
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </>
  );
}
