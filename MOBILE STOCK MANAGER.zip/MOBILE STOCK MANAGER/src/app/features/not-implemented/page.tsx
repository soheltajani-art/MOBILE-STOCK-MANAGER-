'use client';

import { Wrench, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function NotImplementedPage() {
  const router = useRouter();
  return (
    <div className="flex flex-col h-screen bg-background font-sans">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Under Development
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <div className="flex flex-col flex-1 items-center justify-center bg-background p-4 text-center">
        <div className="bg-muted p-4 rounded-full mb-4">
          <Wrench className="h-12 w-12 text-muted-foreground" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">
          This feature is not implemented yet.
        </h1>
        <p className="mt-2 text-muted-foreground">
          This page is under construction. Please check back later!
        </p>
      </div>
    </div>
  );
}
