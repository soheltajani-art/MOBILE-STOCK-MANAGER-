
'use client';

import * as React from 'react';
import {
  ArrowLeft,
  Package,
  Calendar as CalendarIcon,
  Tag,
  Info,
  CheckCircle,
  XCircle,
  RefreshCw,
  ArrowUp,
  ArrowDown,
  Hourglass,
  CheckCircle2,
  Share2,
  Cpu,
  Smartphone,
  Paintbrush,
  Fingerprint,
  Lock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { type HistoryItem } from '../page';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import jsPDF from 'jspdf';
import { type ShopInfo } from '@/app/shop-information/page';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { usePermissions } from '@/hooks/use-permissions';

interface TransferDetailsPageProps {
  transfer: HistoryItem;
  onBack: () => void;
  onSettle: (id: number, details: string) => void;
  onReverse: (item: HistoryItem, reason: string) => void;
}

const DetailParser = ({ details }: { details: string }) => {
    if (!details) return null;

    const ramStorageMatch = details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = details.match(/ID1:\s*([^\s,]+)/i);
    const id2Match = details.match(/ID2:\s*([^\s,]+)/i);
    const fromMatch = details.match(/From\s*([^-]+)/i);
    const toMatch = details.match(/To\s*([^-]+)/i);

    let colorPart = details;
    if(ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
    if(id1Match) colorPart = colorPart.replace(`- ID1: ${id1Match[1]}`, '');
    if(id2Match) colorPart = colorPart.replace(`ID2: ${id2Match[1]}`, '');
    if(fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if(toMatch) colorPart = colorPart.replace(toMatch[0], '');
    colorPart = colorPart.replace(/,/g, '').trim();

    return (
        <div className="space-y-2 text-right">
            {ramStorageMatch && <div className='flex justify-end items-center gap-2'><Cpu className="h-4 w-4 text-gray-400" /> <span>{ramStorageMatch[1]} / {ramStorageMatch[2]}</span></div>}
            {colorPart && <div className='flex justify-end items-center gap-2'><Paintbrush className="h-4 w-4 text-gray-400" /> <span>{colorPart}</span></div>}
            {fromMatch && <div className='flex justify-end items-center gap-2'><Share2 className="h-4 w-4 text-gray-400" /> <span>From: {fromMatch[1].trim()}</span></div>}
            {toMatch && <div className='flex justify-end items-center gap-2'><Share2 className="h-4 w-4 text-gray-400" /> <span>To: {toMatch[1].trim().replace('- ID1:', '').trim()}</span></div>}
            {id1Match && <div className='flex justify-end items-center gap-2'><Fingerprint className="h-4 w-4 text-gray-400" /> <span>ID1: {id1Match[1]}</span></div>}
            {id2Match && <div className='flex justify-end items-center gap-2'><Fingerprint className="h-4 w-4 text-gray-400" /> <span>ID2: {id2Match[1]}</span></div>}
        </div>
    );
};

const SettlementDetailsParser = ({ details, productName, transferType }: { details: string, productName: string, transferType: string }) => {
    if (!details) return null;

    const ramStorageMatch = details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = details.match(/ID1?:\s*([^\s,]+)/i);
    const id2Match = details.match(/ID2:\s*([^\s,]+)/i);
    const fromMatch = details.match(/From\s(.*?)\s-/);
    const toMatch = details.match(/To\s(.*?)\s-/);

    const partnerShop = transferType === 'Transfer In'
      ? (fromMatch ? fromMatch[1] : '')
      : (toMatch ? toMatch[1] : '');

    let colorPart = details;
    if (ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
    if (id1Match) colorPart = colorPart.replace(id1Match[0], '');
    if (id2Match) colorPart = colorPart.replace(id2Match[0], '');
    if (fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if (toMatch) colorPart = colorPart.replace(toMatch[0], '');
    colorPart = colorPart.replace(/- ID:/, '').replace(/ID2:/, '').replace(/,/g, '').trim();

    return (
        <div className="text-sm text-left text-muted-foreground mt-4 space-y-2 bg-gray-100 p-4 rounded-lg">
            <p className="font-bold text-lg text-foreground">{productName}</p>
            <div className="grid grid-cols-[auto,1fr] gap-x-2">
                {ramStorageMatch && <React.Fragment key="config"> <p className="font-semibold text-gray-500">Config:</p> <p>{ramStorageMatch[1]}/{ramStorageMatch[2]}</p> </React.Fragment>}
                {colorPart && <React.Fragment key="color"> <p className="font-semibold text-gray-500">Color:</p> <p>{colorPart}</p> </React.Fragment>}
                {id1Match && <React.Fragment key="id1"> <p className="font-semibold text-gray-500">ID1:</p> <p className="font-mono">{id1Match[1]}</p> </React.Fragment>}
                {id2Match && <React.Fragment key="id2"> <p className="font-semibold text-gray-500">ID2:</p> <p className="font-mono">{id2Match[1]}</p> </React.Fragment>}
            </div>
            <p className="pt-2 border-t">
              {transferType === 'Transfer In' ? 'Are you paid to' : 'Received payment from'} <strong>{partnerShop}</strong>?
            </p>
        </div>
    );
};


export default function TransferDetailsPage({
  transfer,
  onBack,
  onSettle,
  onReverse,
}: TransferDetailsPageProps) {
  const [reversalReason, setReversalReason] = useState('');
  const [shopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const { permissions } = usePermissions();

  const myShopName = shopInfo?.shopName || 'My Shop';

  if (!transfer) {
    return null;
  }

  const isPending = transfer.status === 'Pending';
  const isTransferIn = transfer.type === 'Transfer In';
  const isReversed = transfer.isReversed;

  const handleGenerateReversedInvoice = (reason: string) => {
    if (!permissions.canGenerateInvoice) {
        toast.error('Permission Denied', { description: 'You cannot generate invoices.' });
        return;
    }
    const doc = new jsPDF();
    const primaryColor = [220, 38, 38]; // Red
    const secondaryColor = [105, 105, 105];
    const lightGray = [254, 242, 242]; // Light Red
    
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(0, 0, 210, 45, 'F');
    doc.setFontSize(32);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text("REVERSED", 105, 25, { align: "center" });
    doc.setFontSize(12);
    doc.text("Transfer Reversal Document", 105, 35, { align: "center" });

    let yPos = 65;
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text("Original Transfer Details", 15, yPos);
    
    yPos += 10;
    const ramStorageMatch = transfer.details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = transfer.details.match(/ID1?:\s*([^\s,]+)/i);
    const id2Match = transfer.details.match(/ID2:\s*([^\s,]+)/i);
    const fromMatch = transfer.details.match(/From\s*([^-]+)/i);
    const toMatch = transfer.details.match(/To\s*([^-]+)/i);
    
    let colorPart = transfer.details;
    if(ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
    if(id1Match) colorPart = colorPart.replace(`- ID1: ${id1Match[1]}`, '');
    if(id2Match) colorPart = colorPart.replace(`ID2: ${id2Match[1]}`, '');
    if(fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if(toMatch) colorPart = colorPart.replace(toMatch[0], '');
    colorPart = colorPart.replace(/,/g, '').trim();

    const transferData = {
        name: transfer.productName,
        id: id1Match ? id1Match[1] : 'N/A',
        id2: id2Match ? id2Match[1] : '',
        ram: ramStorageMatch ? ramStorageMatch[1] : 'N/A',
        storage: ramStorageMatch ? ramStorageMatch[2] : 'N/A',
        color: colorPart,
        price: transfer.type === 'Transfer Out' ? transfer.salePrice || 0 : transfer.purchasePrice || 0,
        transferType: transfer.type,
        transferFrom: fromMatch ? fromMatch[1].trim() : myShopName,
        transferTo: toMatch ? toMatch[1].trim().replace('- ID1:', '').trim() : myShopName,
        paymentStatus: transfer.status
    };

    const details = [
        `Product: ${transferData.name}`,
        `Config: ${transferData.ram}/${transferData.storage}`,
        `Color: ${transferData.color}`,
        `ID1: ${transferData.id}`,
        transferData.id2 ? `ID2: ${transferData.id2}` : null,
        `From: ${transferData.transferFrom}`,
        `To: ${transferData.transferTo}`,
        `Original Status: ${transferData.paymentStatus}`,
        `Amount: ${transferData.price.toLocaleString()}`
    ].filter(Boolean) as string[];

    doc.setFontSize(10);
    doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
    doc.roundedRect(15, yPos -5, 180, details.length * 7 + 10, 3, 3, 'F');
    doc.text(details, 20, yPos);
    
    yPos += details.length * 7 + 20;
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Reversal Information", 15, yPos);

    yPos += 10;
    doc.setFontSize(10);
    doc.text(`Reversed On: ${format(new Date(), 'PPP p')}`, 20, yPos);
    yPos += 7;
    doc.text(`Reason: ${reason}`, 20, yPos);

    const pdfBlob = doc.output("blob");
    const pdfFile = new File([pdfBlob], "reversal_invoice.pdf", { type: "application/pdf" });
    
    if (navigator.share && navigator.canShare({ files: [pdfFile] })) {
        navigator.share({ files: [pdfFile], title: 'Reversal Invoice' })
          .then(() => toast.success('Reversal invoice shared!'))
          .catch((err) => toast.error('Error sharing: ' + err.message));
    } else {
        const pdfUrl = URL.createObjectURL(pdfBlob);
        const a = document.createElement('a');
        a.href = pdfUrl;
        a.download = 'reversal_invoice.pdf';
        a.click();
        URL.revokeObjectURL(pdfUrl);
        toast.info('Reversal invoice downloaded.');
    }
  };
  
  const handleSettle = () => {
    if (!permissions.canSettleTransfers) {
        toast.error('Permission Denied', { description: 'You cannot settle transfers.' });
        return;
    }
    onSettle(transfer.id, transfer.details);
    toast.success('Transfer Settled', {
      description: `${transfer.productName} has been marked as settled.`,
    });
    onBack();
  };

  const handleReverse = () => {
    if (!permissions.canReverse) {
        toast.error('Permission Denied', { description: 'You cannot reverse transfers.' });
        return;
    }
    if (!isPending) {
        toast.error('Action Not Allowed', {
            description: 'Only pending transfers can be reversed.',
        });
        return;
    }
    if (!reversalReason.trim()) {
      toast.error('Reason Required', {
        description: 'Please provide a reason for the reversal.',
      });
      return;
    }
    onReverse(transfer, reversalReason);
    toast.error('Transfer Reversed', {
      description: `${transfer.productName} has been reversed.`,
    });
    handleGenerateReversedInvoice(reversalReason);
    onBack();
  };
  
    const handleGenerateInvoice = () => {
        if (!permissions.canGenerateInvoice) {
            toast.error('Permission Denied', { description: 'You cannot generate invoices.' });
            return;
        }
        const doc = new jsPDF();
        
        const ramStorageMatch = transfer.details.match(/(\d+GB)\/(\d+GB|1TB)/);
        const id1Match = transfer.details.match(/ID1?:\s*([^\s,]+)/i);
        const id2Match = transfer.details.match(/ID2:\s*([^\s,]+)/i);
        const fromMatch = transfer.details.match(/From\s*([^-]+)/i);
        const toMatch = transfer.details.match(/To\s*([^-]+)/i);

        let colorPart = transfer.details;
        if(ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
        if(id1Match) colorPart = colorPart.replace(`- ID1: ${id1Match[1]}`, '');
        if(id2Match) colorPart = colorPart.replace(`ID2: ${id2Match[1]}`, '');
        if(fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
        if(toMatch) colorPart = colorPart.replace(toMatch[0], '');
        colorPart = colorPart.replace(/,/g, '').trim();

        const data = {
            name: transfer.productName,
            id: id1Match ? id1Match[1] : 'N/A',
            id2: id2Match ? id2Match[1] : '',
            ram: ramStorageMatch ? ramStorageMatch[1] : 'N/A',
            storage: ramStorageMatch ? ramStorageMatch[2] : 'N/A',
            color: colorPart,
            price: transfer.type === 'Transfer Out' ? transfer.salePrice || 0 : transfer.purchasePrice || 0,
            transferType: transfer.type,
            transferFrom: fromMatch ? fromMatch[1].trim() : myShopName,
            transferTo: toMatch ? toMatch[1].trim().replace('- ID1:', '').trim() : myShopName,
            paymentStatus: transfer.status === 'Settled' ? 'Paid' : 'Unpaid'
        };

        const primaryColor = [70, 130, 180]; 
        const secondaryColor = [105, 105, 105]; 
        const lightGray = [240, 248, 255]; 
        const accentColor = [255, 99, 71]; 
        const lightAccentColor = [173, 216, 230]; 
        const successColor = [60, 179, 113];

        doc.setFillColor(255, 255, 255);
        doc.rect(0, 0, 210, 297, 'F');
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.rect(0, 0, 210, 45, 'F');
        doc.setFontSize(32);
        doc.setTextColor(255, 255, 255);
        doc.setFont("helvetica", "bold");
        doc.text("TRANSFER", 105, 25, { align: "center" });
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text("Professional Stock Transfer Document", 105, 35, { align: "center" });
        doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
        doc.rect(15, 38, 180, 2, 'F');
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        doc.setFont("helvetica", "normal");

        let yPos = 65;
        doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
        doc.roundedRect(15, yPos - 5, 90, 90, 3, 3, 'F');
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(1);
        doc.roundedRect(15, yPos - 5, 90, 90, 3, 3);
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.text("TRANSFER FROM", 20, yPos);
        yPos += 12;
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        doc.text("SHOP NAME:", 20, yPos);
        doc.setFont("helvetica", "bold");
        doc.text(data.transferFrom || "N/A", 50, yPos);
        yPos += 12;
        doc.setFont("helvetica", "normal");
        doc.text("PAYMENT STATUS:", 20, yPos);
        doc.setFont("helvetica", "bold");
        if (data.paymentStatus === 'Paid') {
            doc.setTextColor(successColor[0], successColor[1], successColor[2]);
        } else {
            doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
        }
        doc.text(data.paymentStatus || "N/A", 65, yPos);
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        yPos += 12;
        doc.setFont("helvetica", "normal");
        doc.text("TRANSFER TYPE:", 20, yPos);
        doc.setFont("helvetica", "bold");
        doc.text(data.transferType || "N/A", 60, yPos);
        yPos += 12;
        doc.setFont("helvetica", "normal");
        doc.text("TRANSFER TIME:", 20, yPos);
        doc.setFont("helvetica", "bold");
        doc.text(format(new Date(transfer.date), 'p'), 60, yPos);
        yPos += 12;
        doc.setFont("helvetica", "normal");
        doc.text("TRANSFER STATUS:", 20, yPos);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(successColor[0], successColor[1], successColor[2]);
        doc.text("PERMANENT", 70, yPos);
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

        let rightYPos = 65;
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.roundedRect(115, rightYPos - 8, 80, 25, 3, 3, 'F');
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(255, 255, 255);
        doc.text("TRANSFER DATE", 155, rightYPos - 2, { align: "center" });
        rightYPos += 8;
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        const formattedDate = format(new Date(transfer.date), 'dd / MM / yyyy');
        doc.text(formattedDate, 155, rightYPos, { align: "center" });
        rightYPos += 25;
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.text("PRODUCT DETAILS", 155, rightYPos, { align: "center" });
        doc.setFillColor(255, 255, 255);
        doc.roundedRect(115, rightYPos + 2, 80, 75, 3, 3, 'F');
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(1);
        doc.roundedRect(115, rightYPos + 2, 80, 75, 3, 3);
        rightYPos += 15;
        doc.setFontSize(9);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

        const productDetails = [
            { label: "PRODUCT NAME:", value: data.name || "N/A" },
            { label: "IMEI 1:", value: data.id || "N/A" },
            { label: "IMEI 2:", value: data.id2 || "N/A" },
            { label: "RAM:", value: data.ram || "N/A" },
            { label: "STORAGE:", value: data.storage || "N/A" },
            { label: "COLOR:", value: data.color || "N/A" }
        ];

        productDetails.forEach((detail, index) => {
            if (index % 2 === 0) {
                doc.setFillColor(248, 249, 250);
                doc.rect(117, rightYPos - 3, 76, 9, 'F');
            }
            doc.text(detail.label, 120, rightYPos);
            doc.setFont("helvetica", "bold");
            const maxLength = 15;
            const displayValue = detail.value.length > maxLength ? detail.value.substring(0, maxLength) + "..." : detail.value;
            doc.text(displayValue, 165, rightYPos);
            doc.setFont("helvetica", "normal");
            rightYPos += 10;
        });

        yPos += 60;
        doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
        doc.roundedRect(15, yPos - 5, 90, 30, 3, 3, 'F');
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(1);
        doc.roundedRect(15, yPos - 5, 90, 30, 3, 3);
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.text("TRANSFER TO", 20, yPos);
        yPos += 15;
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        doc.text("SHOP NAME:", 20, yPos);
        doc.setFont("helvetica", "bold");
        doc.text(data.transferTo || "N/A", 50, yPos);

        yPos += 35;
        doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
        doc.roundedRect(15, yPos - 8, 180, 30, 3, 3, 'F');
        doc.setFillColor(0, 0, 0, 0.1);
        doc.roundedRect(17, yPos - 6, 180, 30, 3, 3, 'F');
        doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
        doc.roundedRect(15, yPos - 8, 180, 30, 3, 3, 'F');
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(255, 255, 255);
        doc.text("AMOUNT [RUPEES]:", 20, yPos + 5);
        doc.setFontSize(20);
        doc.setTextColor(255, 255, 255);
        doc.setFont("helvetica", "bold");
        doc.text(`${data.price}`, 185, yPos + 5, { align: "right" });

        yPos += 45;
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        doc.setFont("helvetica", "italic");
        doc.text("MOBILE STOCK MANAGER GENERATED INVOICE", 105, yPos, { align: "center" });
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(3);
        doc.roundedRect(10, 10, 190, 277, 5, 5);
        doc.setDrawColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
        doc.setLineWidth(1);
        doc.roundedRect(14, 14, 182, 269, 3, 3);
        doc.saveGraphicsState();
        const GState = (doc as any).GState;
        doc.setGState(new GState({ opacity: 0.08 }));
        doc.setFontSize(28);
        doc.setTextColor(150, 150, 150);
        doc.setFont("helvetica", "bold");
        const watermarkY = 148;
        const watermarkX = 105;
        doc.text("MOHAMMED SOHEL TAJANI", watermarkX, watermarkY, { angle: 45, align: "center" });
        doc.restoreGraphicsState();
        doc.setFontSize(8);
        doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        doc.setFont("helvetica", "normal");
        doc.text("MOHAMMED SOHEL TAJANI", 190, 280, { align: "right" });

        const pdfBlob = doc.output("blob");
        const pdfFile = new File([pdfBlob], "transfer_invoice.pdf", { type: "application/pdf" });

        if (navigator.share && navigator.canShare({ files: [pdfFile] })) {
            navigator.share({
                files: [pdfFile],
                title: 'Transfer Invoice',
                text: 'Here is your professional transfer invoice.',
            })
            .then(() => toast.success('Transfer invoice shared successfully!'))
            .catch((error) => toast.error('Error sharing invoice: ' + error.message));
        } else {
            const pdfUrl = URL.createObjectURL(pdfBlob);
            const a = document.createElement('a');
            a.href = pdfUrl;
            a.download = 'transfer_invoice.pdf';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(pdfUrl);
            toast.info('Invoice downloaded. Web Share API not supported or cannot share files.');
        }
    };


  const getIcon = () => {
    if (isReversed) return <RefreshCw className="h-6 w-6 text-gray-500" />;
    if (isTransferIn) return <ArrowDown className="h-6 w-6 text-blue-600" />;
    return <ArrowUp className="h-6 w-6 text-purple-600" />;
  };

  const getBgColor = () => {
    if (isReversed) return 'bg-gray-100';
    if (isTransferIn) return 'bg-blue-100';
    return 'bg-purple-100';
  };

  const getTextColor = () => {
     if (isReversed) return 'text-gray-500';
    if (isTransferIn) return 'text-blue-600';
    return 'text-purple-600';
  };

  const statusIcon = isPending ? (
    <Hourglass className="h-5 w-5 text-orange-500" />
  ) : (
    <CheckCircle2 className="h-5 w-5 text-green-500" />
  );

  const statusBadge = (
    <Badge
      variant={isPending ? 'destructive' : 'default'}
      className={
        isPending
          ? 'bg-orange-100 text-orange-800 border-orange-200'
          : 'bg-green-100 text-green-800 border-green-200'
      }
    >
      {isPending ? (
        <Hourglass className="h-3 w-3 mr-1" />
      ) : (
        <CheckCircle2 className="h-3 w-3 mr-1" />
      )}
      {transfer.status}
    </Badge>
  );

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 font-sans slide-in-from-right">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-6 w-6 text-gray-700" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900">
              Transfer Details
            </h1>
             <div className="w-10"></div>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 space-y-6">
        <Card className={`shadow-lg rounded-2xl ${isReversed ? 'opacity-70' : ''}`}>
          <CardHeader className="flex flex-row items-center space-x-4 p-6">
            <div className={`p-4 rounded-full ${getBgColor()}`}>
              {getIcon()}
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-gray-800">
                {transfer.productName}
              </CardTitle>
              <p className={`font-semibold text-lg ${getTextColor()}`}>
                {isReversed ? 'Reversed Transfer' : transfer.type}
              </p>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-0 space-y-4 text-gray-700">
             {isReversed && (
              <div className="flex justify-between items-center p-3 bg-gray-100 rounded-lg">
                <div className="flex items-center space-x-2">
                  <RefreshCw className="h-5 w-5 text-gray-500" />
                  <span className="font-semibold">Status</span>
                </div>
                <Badge variant="outline" className="bg-gray-200 text-gray-800 border-gray-300">
                  Reversed
                </Badge>
              </div>
            )}
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                {statusIcon}
                <span className="font-semibold">Original Status</span>
              </div>
              {statusBadge}
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <CalendarIcon className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Date & Time</span>
              </div>
              <span>{format(new Date(transfer.date), 'PPP p')}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Tag className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Quantity</span>
              </div>
              <span className="font-bold text-lg">{transfer.quantity}</span>
            </div>
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2">
                <Info className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Details</span>
              </div>
              <DetailParser details={transfer.details} />
            </div>
             {isReversed && transfer.reversalReason && (
              <div className="flex justify-between items-start pt-4 border-t">
                <div className="flex items-center space-x-2">
                  <Info className="h-5 w-5 text-gray-400" />
                  <span className="font-semibold">Reversal Reason</span>
                </div>
                <span className="text-right flex-1 pl-4">{transfer.reversalReason}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
            <Card className="shadow-lg rounded-2xl">
              <CardContent className="p-4 space-y-3">
                 <Button onClick={handleGenerateInvoice} variant="outline" className="w-full h-12 text-md" disabled={!permissions.canGenerateInvoice}>
                    {!permissions.canGenerateInvoice && <Lock className="mr-2 h-4 w-4"/>}
                    <Share2 className="mr-2 h-5 w-5" />
                    Generate Invoice
                </Button>
                {isPending && !isReversed && (
                    <React.Fragment>
                        <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button className="w-full h-12 bg-green-500 hover:bg-green-600 text-white rounded-xl" disabled={!permissions.canSettleTransfers}>
                              {!permissions.canSettleTransfers && <Lock className="mr-2 h-4 w-4"/>}
                              <CheckCircle className="mr-2 h-5 w-5" />
                              Settle Transfer
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                            <AlertDialogTitle>Confirm Settlement</AlertDialogTitle>
                            <AlertDialogDescription asChild>
                                <div>
                                    <SettlementDetailsParser 
                                    details={transfer.details}
                                    productName={transfer.productName}
                                    transferType={transfer.type}
                                    />
                                </div>
                            </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                            <AlertDialogCancel>No</AlertDialogCancel>
                            <AlertDialogAction onClick={handleSettle}>
                                Yes
                            </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                        </AlertDialog>
                        <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button
                            variant="destructive"
                            className="w-full h-12 bg-red-500 hover:bg-red-600 rounded-xl"
                            disabled={!permissions.canReverse}
                            >
                            {!permissions.canReverse && <Lock className="mr-2 h-4 w-4"/>}
                            <RefreshCw className="mr-2 h-5 w-5" />
                            Reverse Transfer
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This will reverse the transfer. Please provide a reason. This action cannot be undone.
                            </AlertDialogDescription>
                            <Input 
                                placeholder="Reason for reversal" 
                                value={reversalReason}
                                onChange={(e) => setReversalReason(e.target.value)}
                                className="mt-2"
                            />
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                                onClick={handleReverse}
                                className="bg-red-500 hover:bg-red-600"
                            >
                                Reverse
                            </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                        </AlertDialog>
                    </React.Fragment>
                )}
              </CardContent>
            </Card>
          </div>
      </main>
    </div>
  );
}
