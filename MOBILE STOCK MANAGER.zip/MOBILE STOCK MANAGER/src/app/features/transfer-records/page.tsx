
'use client';

import { Suspense, useState, useMemo, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Repeat,
  Search,
  Loader2,
  Building,
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import TransferDetailsPage from './transfer-details/page';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type ReversedTransferItem } from '../reverse-transfers/page';
import { Skeleton } from '@/components/ui/skeleton';
import { HistoryItemCard } from '../history-item-card';
import { type Product } from '../where-is-my-product/page';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

interface TransferRecordsPageProps {
  onBack: () => void;
}

export type HistoryItem = {
  id: number;
  date: Date;
  type: 'Sale' | 'Purchase' | 'Transfer In' | 'Transfer Out' | 'Purchase & Sale' | 'Transfer In & Sale' | 'Settlement';
  status?: 'Pending' | 'Settled';
  saleStatus?: 'unsettled_transfer' | null;
  productName: string;
  quantity: number;
  totalAmount: number;
  details: string;
  purchaseDetails?: string;
  saleDetails?: string;
  salePrice?: number;
  purchasePrice?: number;
  originalTransferId?: number;
  settledDate?: Date;
  isReversed?: boolean;
  reversalReason?: string;
};

type FilterType = 'all' | 'in' | 'out';
type StatusFilterType = 'all' | 'pending' | 'settled';

function TransferRecordsContent({ onBack }: TransferRecordsPageProps) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialTypeFilter = (searchParams.get('type') as FilterType) || 'all';
  
  const [transferHistory, setTransferHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers, setReversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<FilterType>(initialTypeFilter);
  const [statusFilter, setStatusFilter] = useState<StatusFilterType>('all');
  const [selectedTransfer, setSelectedTransfer] = useState<HistoryItem | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleSettleTransfer = (id: number, productDetails: string) => {
    const transferToSettle = transferHistory.find((item) => item.id === id);
    if (!transferToSettle) return;
  
    const settlementDate = new Date();
  
    setTransferHistory((prev) => {
      let updatedHistory = [...prev];
  
      const settlementItem: HistoryItem = {
        id: Date.now(),
        originalTransferId: transferToSettle.id,
        date: settlementDate,
        type: 'Settlement',
        status: 'Settled',
        productName: transferToSettle.productName,
        quantity: transferToSettle.quantity,
        totalAmount: transferToSettle.totalAmount,
        details: `Settlement for ${transferToSettle.type}: ${transferToSettle.details}`,
      };
      updatedHistory.push(settlementItem);
  
      const idMatch = productDetails.match(/ID1?:\s*([^\s,]+)/i);
      const productId = idMatch ? idMatch[1].toLowerCase() : null;
  
      updatedHistory = updatedHistory.map(item => {
        if (productId && item.type === 'Sale' && item.details.toLowerCase().includes(productId) && item.saleStatus === 'unsettled_transfer') {
          return { ...item, saleStatus: null };
        }
        if (item.id === id) {
          return { ...item, status: 'Settled' };
        }
        return item;
      });
  
      return updatedHistory;
    });

     if (transferToSettle.type === 'Transfer Out') {
        const productIndex = products.findIndex(p => {
            const idMatch = transferToSettle.details.match(/ID1?:\s*([^\s,]+)/i);
            const productId = idMatch ? idMatch[1] : null;
            return p.id === productId || (p.id2 && p.id2 === productId);
        });

        if (productIndex !== -1) {
            const updatedProducts = [...products];
            if (updatedProducts[productIndex].stock > 0) {
                updatedProducts[productIndex] = { ...updatedProducts[productIndex], stock: updatedProducts[productIndex].stock - 1 };
                setProducts(updatedProducts);
            }
        }
    }
  };

  const handleReverseTransfer = (itemToReverse: HistoryItem, reason: string) => {
    const newReversedItem: ReversedTransferItem = {
      id: Date.now(),
      originalTransferId: itemToReverse.id,
      date: new Date(),
      productName: itemToReverse.productName,
      quantity: itemToReverse.quantity,
      details: `Reversed: ${itemToReverse.details}`,
      reason: reason,
    };
    setReversedTransfers((prev) => [...prev, newReversedItem]);

    const idMatch = itemToReverse.details.match(/ID1?:\s*([^\s,]+)/i);
    const productId = idMatch ? idMatch[1] : null;

    if (itemToReverse.type === 'Transfer In') {
      setProducts(prev => prev.filter(p => p.id !== productId && (!p.id2 || p.id2 !== productId)));
    } else if (itemToReverse.type === 'Transfer Out') {
      if (itemToReverse.status === 'Settled') {
        setProducts(prev => prev.map(p => {
          if (p.id === productId || (p.id2 && p.id2 === productId)) {
            return { ...p, stock: p.stock + 1 };
          }
          return p;
        }));
      }
    }

    setTransferHistory((prev) =>
      prev.map((item) =>
        item.id === itemToReverse.id
          ? { ...item, isReversed: true, reversalReason: reason }
          : item
      )
    );
  };

  const groupedTransfers = useMemo(() => {
    if (!isMounted) return {};

    let history = transferHistory.filter(item => (item.type === 'Transfer In' || item.type === 'Transfer Out'));
    
    history = history.map(item => ({ 
      ...item, 
      status: transferHistory.some(h => h.type === 'Settlement' && h.originalTransferId === item.id) || item.status === 'Settled' ? 'Settled' : 'Pending',
    }));

    if (filterType !== 'all') history = history.filter(item => (filterType === 'in' ? item.type === 'Transfer In' : item.type === 'Transfer Out'));
    if (statusFilter !== 'all') history = history.filter(item => item.status?.toLowerCase() === statusFilter);
    if (searchTerm) history = history.filter(item => item.productName.toLowerCase().includes(searchTerm.toLowerCase()));

    const groups: { [brand: string]: { [type: string]: HistoryItem[] } } = {};
    history.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .forEach(item => {
        const idMatch = item.details.match(/ID1?:\s*([^\s,]+)/i);
        const productId = idMatch ? idMatch[1] : null;
        const product = products.find(p => p.id === productId);
        const brand = product?.brand || 'Unbranded';
        const typeKey = `${item.type} - ${item.status}`;

        if (!groups[brand]) groups[brand] = {};
        if (!groups[brand][typeKey]) groups[brand][typeKey] = [];
        groups[brand][typeKey].push(item);
    });
    return groups;
  }, [searchTerm, filterType, statusFilter, transferHistory, isMounted, products]);

  const handleTransferClick = (item: HistoryItem) => setSelectedTransfer(item);

  if (selectedTransfer) {
    return (
      <TransferDetailsPage
        transfer={selectedTransfer}
        onBack={() => setSelectedTransfer(null)}
        onSettle={handleSettleTransfer}
        onReverse={handleReverseTransfer}
      />
    );
  }
  
  const brandNames = Object.keys(groupedTransfers).sort();

  return (
    <div className="flex flex-col flex-1 bg-gray-50 font-sans slide-in-from-right overflow-hidden">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Transfer Records
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col p-4 md:p-6 space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative w-full md:flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input placeholder="Search by product name..." className="pl-10 bg-white rounded-xl shadow-sm h-12 w-full" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <Select value={filterType} onValueChange={(value: FilterType) => setFilterType(value)}>
            <SelectTrigger className="w-full md:w-[200px] bg-white rounded-xl shadow-sm h-12"><SelectValue placeholder="Filter transfers" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Transfers</SelectItem>
              <SelectItem value="in">Transfer In</SelectItem>
              <SelectItem value="out">Transfer Out</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-3 gap-2 p-1 bg-gray-200 rounded-xl">
          <Button variant="ghost" onClick={() => setStatusFilter('all')} className={cn('rounded-lg', statusFilter === 'all' && 'bg-white shadow text-gray-800')}>All</Button>
          <Button variant="ghost" onClick={() => setStatusFilter('pending')} className={cn('rounded-lg', statusFilter === 'pending' && 'bg-white shadow text-gray-800')}>Pending</Button>
          <Button variant="ghost" onClick={() => setStatusFilter('settled')} className={cn('rounded-lg', statusFilter === 'settled' && 'bg-white shadow text-gray-800')}>Settled</Button>
        </div>
        <ScrollArea className="flex-1 -mr-4 pr-4">
          <div className="space-y-6">
            {!isMounted ? (
              <div className="space-y-4"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>
            ) : brandNames.length > 0 ? (
              brandNames.map(brandName => (
                <Card key={brandName} className="bg-white shadow-lg rounded-2xl">
                    <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4 border-b">
                        <Building className="h-5 w-5 text-gray-500" /><CardTitle className="text-lg">{brandName}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-2 pt-2">
                       {Object.keys(groupedTransfers[brandName]).sort().map(typeKey => (
                         <div key={typeKey} className="mb-4 last:mb-0">
                           <h3 className="font-semibold text-md text-gray-600 px-2 py-1 bg-gray-100 rounded-md mb-2">{typeKey}</h3>
                           {groupedTransfers[brandName][typeKey].map(item => (
                             <div key={item.id} onClick={() => handleTransferClick(item)} className="cursor-pointer"><HistoryItemCard item={item} /></div>
                           ))}
                         </div>
                       ))}
                    </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center text-gray-500 py-16">
                <Repeat className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No Transfer Records Found</h3>
                <p className="mt-1 text-sm text-gray-500">No records match your search or filter criteria.</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}

export default function TransferRecordsPage(props: TransferRecordsPageProps) {
  return (
      <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
          <TransferRecordsContent {...props} />
      </Suspense>
  )
}
