
'use client';

import { useMemo } from 'react';
import UnifiedSheetUI from '@/components/ui/unified-sheet';
import { HistoryItem } from '../transfer-records/page';
import { format, eachDayOfInterval, startOfMonth, endOfMonth, startOfYear, endOfYear, getDaysInMonth, getMonth, getYear } from 'date-fns';

interface ReportSheetProps {
  salesData: HistoryItem[];
  filterMode: string;
  targetDate: Date;
}

interface DailySummary {
  date: string;
  totalSold: number;
  totalRupees: number;
  totalProfit: number;
}

interface MonthlySummary {
  month: string;
  totalSold: number;
  totalRupees: number;
  totalProfit: number;
}

export default function ReportSheet({ salesData, filterMode, targetDate }: ReportSheetProps) {
  const salesHtml = useMemo(() => {
    
    if (filterMode === 'day') {
      // --- DETAILED DAILY REPORT ---
      let totalProfit = 0;
      const tableRows = salesData.map((sale, index) => {
          const profit = (sale.salePrice || 0) - (sale.purchasePrice || 0);
          totalProfit += profit;
          
          const idMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
          const ramStorageMatch = sale.details.match(/(\d+GB)\/(\d+GB|1TB)/);

          return `
              <tr>
                  <th class="px-2 py-1 bg-gray-50" style="border: 1px solid #ccc; white-space: nowrap;">${index + 1}</th>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${sale.productName}</td>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${ramStorageMatch ? `${ramStorageMatch[1]}/${ramStorageMatch[2]}` : 'N/A'}</td>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${idMatch ? idMatch[1] : 'N/A'}</td>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${(sale.purchasePrice || 0).toLocaleString()}</td>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${(sale.salePrice || 0).toLocaleString()}</td>
                  <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${profit.toLocaleString()}</td>
              </tr>
          `;
      }).join('');

      return `
        <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%;">
          <thead>
            <tr>
              <th class="px-2 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">#</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Product Name</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Config</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">IMEI</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Purchase Price</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Sale Price</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Profit</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
          <tfoot>
              <tr>
                  <th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc; white-space: nowrap;">Total Profit</th>
                  <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${totalProfit.toLocaleString()}</th>
              </tr>
          </tfoot>
        </table>
      `;
    } else if (filterMode === 'month') {
      // --- DAILY SUMMARY FOR A MONTH ---
      const dailySummaries: Record<string, DailySummary> = {};

      salesData.forEach(sale => {
        const saleDateStr = format(new Date(sale.date), 'yyyy-MM-dd');
        if (!dailySummaries[saleDateStr]) {
          dailySummaries[saleDateStr] = {
            date: format(new Date(sale.date), 'dd/MM/yy'),
            totalSold: 0,
            totalRupees: 0,
            totalProfit: 0,
          };
        }
        dailySummaries[saleDateStr].totalSold += 1;
        dailySummaries[saleDateStr].totalRupees += sale.salePrice || 0;
        dailySummaries[saleDateStr].totalProfit += (sale.salePrice || 0) - (sale.purchasePrice || 0);
      });

      const sortedSummaries = Object.values(dailySummaries).sort((a, b) => {
        const dateA = a.date.split('/').reverse().join('');
        const dateB = b.date.split('/').reverse().join('');
        return dateA.localeCompare(dateB);
      });
      
      let grandTotalSold = 0;
      let grandTotalRupees = 0;
      let grandTotalProfit = 0;

      const tableRows = sortedSummaries.map(summary => {
        grandTotalSold += summary.totalSold;
        grandTotalRupees += summary.totalRupees;
        grandTotalProfit += summary.totalProfit;
        return `
          <tr>
            <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.date}</td>
            <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalSold}</td>
            <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalRupees.toLocaleString()}</td>
            <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalProfit.toLocaleString()}</td>
          </tr>
        `;
      }).join('');

      return `
        <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%;">
          <thead>
            <tr>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">DATE</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL SOLD</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL SOLD IN RUPEES</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL PROFIT</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
          <tfoot>
            <tr>
              <th class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc; white-space: nowrap;">Total</th>
              <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalSold}</th>
              <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalRupees.toLocaleString()}</th>
              <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalProfit.toLocaleString()}</th>
            </tr>
          </tfoot>
        </table>
      `;
    } else if (filterMode === 'year') {
        // --- MONTHLY SUMMARY FOR A YEAR ---
        const monthlySummaries: Record<string, MonthlySummary> = {};

        for(let i = 0; i < 12; i++) {
            const monthName = format(new Date(getYear(targetDate), i), 'MMMM');
            monthlySummaries[i] = {
                month: monthName,
                totalSold: 0,
                totalRupees: 0,
                totalProfit: 0,
            }
        }

        salesData.forEach(sale => {
            const saleMonth = getMonth(new Date(sale.date));
            if(monthlySummaries[saleMonth]) {
                monthlySummaries[saleMonth].totalSold += 1;
                monthlySummaries[saleMonth].totalRupees += sale.salePrice || 0;
                monthlySummaries[saleMonth].totalProfit += (sale.salePrice || 0) - (sale.purchasePrice || 0);
            }
        });

        let grandTotalSold = 0;
        let grandTotalRupees = 0;
        let grandTotalProfit = 0;

        const tableRows = Object.values(monthlySummaries).map(summary => {
            grandTotalSold += summary.totalSold;
            grandTotalRupees += summary.totalRupees;
            grandTotalProfit += summary.totalProfit;
            return `
              <tr>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.month}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalSold}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalRupees.toLocaleString()}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${summary.totalProfit.toLocaleString()}</td>
              </tr>
            `;
        }).join('');

        return `
            <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%;">
              <thead>
                <tr>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">MONTH</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL SOLD</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL SOLD IN RUPEES</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">TOTAL PROFIT</th>
                </tr>
              </thead>
              <tbody>
                ${tableRows}
              </tbody>
              <tfoot>
                <tr>
                  <th class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc; white-space: nowrap;">Total</th>
                  <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalSold}</th>
                  <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalRupees.toLocaleString()}</th>
                  <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${grandTotalProfit.toLocaleString()}</th>
                </tr>
              </tfoot>
            </table>
        `;
    }

    return '<div>No data available for this view.</div>';

  }, [salesData, filterMode, targetDate]);
  
  return <UnifiedSheetUI initialHtml={salesHtml} />;
}
