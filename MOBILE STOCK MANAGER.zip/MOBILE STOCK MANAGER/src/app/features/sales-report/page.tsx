
'use client';

import { useLocalStorage } from '@/hooks/use-local-storage';
import { HistoryItem } from '../transfer-records/page';
import UnifiedSheetUI from '@/components/ui/unified-sheet';
import { isToday } from 'date-fns';
import { useMemo } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function SalesReportPage() {
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const router = useRouter();

  const salesHtml = useMemo(() => {
    const todaysSales = history.filter(
      (item) => item.type === 'Sale' && isToday(new Date(item.date))
    );

    let totalProfit = 0;

    const tableRows = todaysSales.map((sale, index) => {
        const profit = (sale.salePrice || 0) - (sale.purchasePrice || 0);
        totalProfit += profit;
        
        const idMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
        const ramStorageMatch = sale.details.match(/(\d+GB)\/(\d+GB|1TB)/);

        return `
            <tr>
                <th class="px-2 py-1 bg-gray-50" style="border: 1px solid #ccc; white-space: nowrap;">${index + 1}</th>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${sale.productName}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${ramStorageMatch ? `${ramStorageMatch[1]}/${ramStorageMatch[2]}` : 'N/A'}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${idMatch ? idMatch[1] : 'N/A'}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${(sale.purchasePrice || 0).toLocaleString()}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${(sale.salePrice || 0).toLocaleString()}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;" contenteditable="true">${profit.toLocaleString()}</td>
            </tr>
        `;
    }).join('');

    return `
      <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%; white-space: nowrap;">
        <thead>
          <tr>
            <th class="px-2 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">#</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Product Name</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Config</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">IMEI</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Purchase Price</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Sale Price</th>
            <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Profit</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
        <tfoot>
            <tr>
                <th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc; white-space: nowrap;">Total Profit</th>
                <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc; white-space: nowrap;">${totalProfit.toLocaleString()}</th>
            </tr>
        </tfoot>
      </table>
    `;
  }, [history]);
  
  return (
      <div className="flex flex-col h-screen bg-gray-100">
        <header className="bg-white shadow-sm sticky top-0 z-20 flex-shrink-0">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <Button variant="ghost" size="icon" onClick={() => router.back()}>
                        <ArrowLeft className="h-6 w-6 text-gray-700" />
                    </Button>
                    <h1 className="text-xl font-bold text-gray-900">
                        Today's Sales Report
                    </h1>
                    <div className="w-10"></div>
                </div>
            </div>
        </header>
        <main className="flex-1 flex flex-col overflow-auto">
          <UnifiedSheetUI initialHtml={salesHtml} />
        </main>
    </div>
  );
}
