
'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { HistoryItem } from '../../transfer-records/page';
import ReportSheet from '../report-sheet';
import { isSameDay, isSameMonth, isSameYear, isValid } from 'date-fns';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

function MainSalesReportContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const dateParam = searchParams.get('date');
  const filterMode = searchParams.get('filterMode') || 'day';

  const [history] = useLocalStorage<HistoryItem[]>('history', []);

  const targetDate = dateParam && isValid(new Date(dateParam)) ? new Date(dateParam) : new Date();

  const salesData = history.filter((item) => {
    if (item.type !== 'Sale') return false;
    
    const itemDate = new Date(item.date);
    if (!isValid(itemDate)) return false;

    if (filterMode === 'day') return isSameDay(itemDate, targetDate);
    if (filterMode === 'month') return isSameMonth(itemDate, targetDate);
    if (filterMode === 'year') return isSameYear(itemDate, targetDate);
    
    return false;
  });

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-20 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-6 w-6 text-gray-700" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900 truncate">
              Sales Report
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col overflow-auto">
        <ReportSheet salesData={salesData} filterMode={filterMode} targetDate={targetDate}/>
      </main>
    </div>
  );
}

export default function MainSalesReportPage() {
    return (
        <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <MainSalesReportContent />
        </Suspense>
    )
}
