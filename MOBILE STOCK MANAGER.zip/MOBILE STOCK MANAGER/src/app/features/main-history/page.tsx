
'use client';

import { useState, useMemo, useEffect, Suspense } from 'react';
import {
  Search,
  IndianRupee,
  History,
  LineChart,
  Package,
  Calendar as CalendarIcon,
  Loader2,
  PackagePlus,
  PackageMinus,
  ArrowDown,
  ArrowUp,
  CircleDollarSign,
  TrendingUp,
  Sheet,
  Building,
  ArrowLeft,
} from 'lucide-react';
import { format, isSameDay, isSameMonth, isSameYear } from 'date-fns';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';
import { type Product } from '../where-is-my-product/page';
import { Skeleton } from '@/components/ui/skeleton';
import { HistoryItemCard } from '../history-item-card';
import { type ReversedTransferItem } from '../reverse-transfers/page';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MainHistoryPageProps {
  onBack: () => void;
}

type FilterMode = 'day' | 'month' | 'year';
type GroupedHistory = { [brand: string]: { [type: string]: HistoryItem[] } };


function MainHistoryContent({ onBack }: MainHistoryPageProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialFilter = searchParams.get('filter');

  const [searchTerm, setSearchTerm] = useState('');
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [filterMode, setFilterMode] = useState<FilterMode>('day');
  const [typeFilter, setTypeFilter] = useState<string>(initialFilter || 'all');
  const [historyData] = useLocalStorage<HistoryItem[]>('history', []);
  const [products] = useLocalStorage<Product[]>('products', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>(
    'reversedTransfers',
    []
  );
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const {
    groupedHistory,
    totalSalesRupees,
    totalProfit,
    saleQuantity,
    purchaseQuantity,
    transferInQuantity,
    transferOutQuantity,
  } = useMemo(() => {
    if (!isMounted) {
      return {
        groupedHistory: {},
        totalSalesRupees: 0,
        totalProfit: 0,
        saleQuantity: 0,
        purchaseQuantity: 0,
        transferInQuantity: 0,
        transferOutQuantity: 0,
      };
    }

    let relevantHistory = historyData;
    if (date) {
      relevantHistory = historyData.filter((item) => {
        const itemDate = new Date(item.date);
        if (filterMode === 'day') return isSameDay(itemDate, date);
        if (filterMode === 'month') return isSameMonth(itemDate, date);
        if (filterMode === 'year') return isSameYear(itemDate, date);
        return true;
      });
    }
    
    const mergedActivity: HistoryItem[] = [];
    const processedIds = new Set<number>();
    
    const costEventsForMerge = relevantHistory.filter(h => h.type === 'Purchase' || h.type === 'Transfer In');
    const salesForMerge = relevantHistory.filter(h => h.type === 'Sale');

    salesForMerge.forEach(sale => {
        if (processedIds.has(sale.id)) return;
        const saleIdMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
        if (!saleIdMatch) return;
        const productId = saleIdMatch[1];
        
        const correspondingCostEvent = costEventsForMerge.find(costEvent =>
            !processedIds.has(costEvent.id) && costEvent.details.includes(productId)
        );

        if (correspondingCostEvent) {
            const isTransfer = correspondingCostEvent.type === 'Transfer In';
            const cost = isTransfer ? correspondingCostEvent.totalAmount : correspondingCostEvent.purchasePrice;
            
            mergedActivity.push({
                id: sale.id,
                type: isTransfer ? 'Transfer In & Sale' : 'Purchase & Sale',
                productName: sale.productName, date: sale.date, quantity: sale.quantity,
                totalAmount: sale.totalAmount, purchasePrice: cost, salePrice: sale.salePrice,
                details: `Profit: ${(sale.salePrice || 0) - (cost || 0)}`,
                purchaseDetails: correspondingCostEvent.details, saleDetails: sale.details,
            });
            processedIds.add(sale.id);
            processedIds.add(correspondingCostEvent.id);
        }
    });

    const otherActivities = relevantHistory.filter(activity => !processedIds.has(activity.id) && activity.type !== 'Settlement');
    const combined = [...mergedActivity, ...otherActivities];

    const sales = relevantHistory.filter(item => item.type === 'Sale');
    const purchases = relevantHistory.filter(item => item.type === 'Purchase');
    const transfersIn = relevantHistory.filter(item => item.type === 'Transfer In');
    const transfersOut = relevantHistory.filter(item => item.type === 'Transfer Out');

    const totalSalesRupees = sales.reduce((sum, item) => sum + item.totalAmount, 0);
    const totalProfit = sales.reduce((profit, sale) => {
      const saleIdMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
      if (!saleIdMatch) return profit;
      const productId = saleIdMatch[1];

      const transferInEvent = historyData.find(h => h.type === 'Transfer In' && h.details.includes(productId));
      if (transferInEvent) return profit;

      const purchaseEvent = historyData.find(h => h.type === 'Purchase' && h.details.includes(productId));
      if (purchaseEvent && sale.salePrice && purchaseEvent.purchasePrice) {
        return profit + (sale.salePrice - purchaseEvent.purchasePrice) * sale.quantity;
      }
      return profit;
    }, 0);

    const saleQuantity = sales.reduce((sum, item) => sum + item.quantity, 0);
    const purchaseQuantity = purchases.reduce((sum, item) => sum + item.quantity, 0);
    const transferInQuantity = transfersIn.reduce((sum, item) => sum + item.quantity, 0);
    const transferOutQuantity = transfersOut.reduce((sum, item) => sum + item.quantity, 0);

    let historyWithReversals = combined.map((item) => {
      const originalItemId = item.originalTransferId || item.id;
      const reversal = reversedTransfers.find(rt => rt.originalTransferId === originalItemId);

      if (reversal && (item.type === 'Transfer In' || item.type === 'Transfer Out')) {
          return { ...item, isReversed: true, reversalReason: reversal.reason };
      }
      if ((item.type === 'Transfer In' || item.type === 'Transfer Out') && !item.isReversed) {
        const settlement = historyData.find(h => h.type === 'Settlement' && h.originalTransferId === item.id);
        if (settlement) {
          return { ...item, status: 'Settled', settledDate: settlement.date };
        }
      }
      return item;
    }).filter(item => !(item.isReversed && (item.type !== 'Transfer In' && item.type !== 'Transfer Out')));

    let searchFilteredHistory = historyWithReversals;
    if (typeFilter !== 'all') {
      searchFilteredHistory = searchFilteredHistory.filter(item => {
        if (typeFilter === 'purchase') return item.type === 'Purchase';
        if (typeFilter === 'sale') return item.type === 'Sale' || item.type === 'Purchase & Sale' || item.type === 'Transfer In & Sale';
        return true;
      });
    }
    if (searchTerm) {
      searchFilteredHistory = searchFilteredHistory.filter(item =>
        item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.details && item.details.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (item.purchaseDetails && item.purchaseDetails.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (item.saleDetails && item.saleDetails.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    const groupedHistory: GroupedHistory = {};
    searchFilteredHistory.forEach(item => {
      const idMatch = (item.purchaseDetails || item.details || '').match(/ID1?:\s*([^\s,]+)/i);
      const productId = idMatch ? idMatch[1] : null;
      let brand = 'Unbranded';
      if (productId) {
        const product = products.find(p => p.id === productId);
        if(product && product.brand) brand = product.brand;
      }

      if (!groupedHistory[brand]) groupedHistory[brand] = {};
      const typeKey = item.type === 'Purchase & Sale' || item.type === 'Transfer In & Sale' ? 'Sales & Profit' : item.type;
      if (!groupedHistory[brand][typeKey]) groupedHistory[brand][typeKey] = [];
      groupedHistory[brand][typeKey].push(item);
    });

    for (const brand in groupedHistory) {
      for (const type in groupedHistory[brand]) {
        groupedHistory[brand][type].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
    }

    return { groupedHistory, totalSalesRupees, totalProfit, saleQuantity, purchaseQuantity, transferInQuantity, transferOutQuantity };
  }, [searchTerm, date, filterMode, historyData, reversedTransfers, isMounted, typeFilter, products]);

  const saleStat = { title: 'Sale Quantity', value: saleQuantity, icon: LineChart, color: 'text-white bg-gradient-to-br from-green-500 to-teal-500' };
  const secondaryStats = [
    { title: 'Purchases', value: purchaseQuantity.toLocaleString(), icon: PackagePlus, tag: 'purchase', href: `/features/main-history?filter=purchase&date=${date?.toISOString() || ''}` },
    { title: 'Sold Out', value: saleQuantity.toLocaleString(), icon: PackageMinus, tag: 'sale' },
    { title: 'Transfer In', value: transferInQuantity.toLocaleString(), icon: ArrowDown, tag: 'transfer-in' },
    { title: 'Transfer Out', value: transferOutQuantity.toLocaleString(), icon: ArrowUp, tag: 'transfer-out' },
  ];
  const tertiaryStats = [
    { title: 'Sales (Rupees)', value: totalSalesRupees.toLocaleString('en-IN', { style: 'currency', currency: 'INR' }), icon: CircleDollarSign, color: 'text-white bg-gradient-to-br from-pink-500 to-red-600' },
    { title: 'Profit', value: totalProfit.toLocaleString('en-IN', { style: 'currency', currency: 'INR' }), icon: IndianRupee, color: 'text-white bg-gradient-to-br from-cyan-500 to-blue-600' },
  ];

  const handleViewReport = () => {
    const reportDate = date ? date.toISOString() : new Date().toISOString();
    router.push(`/features/sales-report/main?date=${reportDate}&filterMode=${filterMode}`);
  }
  
  const sortedBrands = Object.keys(groupedHistory).sort();

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right overflow-hidden">
      <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Main History
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <ScrollArea className="flex-1">
        <main className="flex-1 flex flex-col p-4 md:p-6 space-y-6">
          <Card key={saleStat.title} className={`overflow-hidden shadow-lg ${saleStat.color} rounded-2xl`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{saleStat.title}</CardTitle>
              <saleStat.icon className="h-6 w-6" />
            </CardHeader>
            <CardContent>{isMounted ? <div className="text-4xl font-bold">{saleStat.value}</div> : <Skeleton className="h-10 w-3/4" />}</CardContent>
          </Card>
          <div className="grid grid-cols-2 gap-4">
            {secondaryStats.map((stat) => (
              <Card key={stat.title} className="bg-white shadow rounded-2xl flex flex-col justify-between">
                <CardContent className="p-4 flex-grow">
                  <div className="flex items-center space-x-3">
                    <div className="bg-gray-100 p-2 rounded-lg"><stat.icon className="h-6 w-6 text-gray-600" /></div>
                    <div>
                      <p className="text-sm text-gray-500">{stat.title}</p>
                      {isMounted ? <p className="text-2xl font-bold text-gray-900">{stat.value}</p> : <Skeleton className="h-8 w-16 mt-1" />}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tertiaryStats.map((stat) => (
              <Card key={stat.title} className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}>
                <CardContent className="p-6">
                  <p className="text-sm">{stat.title}</p>
                  {isMounted ? <p className="text-3xl font-bold">{stat.value}</p> : <Skeleton className="h-9 w-3/4 mt-1" />}
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Link href={`/features/transfer-summary?date=${date?.toISOString() || ''}`} className="w-full">
                <Button className="w-full h-12" variant="outline"><TrendingUp className="mr-2 h-4 w-4" /> Transfer Calcs</Button>
            </Link>
             <Button className="w-full h-12" variant="outline" onClick={handleViewReport}><Sheet className="mr-2 h-4 w-4" /> View Sales Report</Button>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant={'outline'} className={cn('w-full md:w-[280px] justify-start text-left font-normal h-12 rounded-xl shadow-sm bg-white', !date && 'text-muted-foreground')}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP') : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={date} onSelect={setDate} initialFocus /></PopoverContent>
            </Popover>
            <Select value={filterMode} onValueChange={(value: FilterMode) => setFilterMode(value)}>
              <SelectTrigger className="w-full md:w-[180px] h-12 rounded-xl shadow-sm bg-white"><SelectValue placeholder="Filter by" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Day</SelectItem>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="year">Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input placeholder="Search by product name or details..." className="pl-10 bg-white rounded-xl shadow-sm h-12" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <div className="space-y-6">
            {!isMounted ? (
              <div className="space-y-4"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>
            ) : sortedBrands.length > 0 ? (
              sortedBrands.map(brand => (
                <Card key={brand} className="bg-white shadow-lg rounded-2xl">
                  <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4 border-b">
                    <Building className="h-5 w-5 text-gray-500" /><CardTitle className="text-lg">{brand}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-2 pt-2">
                    {Object.keys(groupedHistory[brand]).sort().map(type => (
                      <div key={type} className="mb-4 last:mb-0">
                         <h3 className="font-semibold text-md text-gray-600 px-2 py-1 bg-gray-100 rounded-md mb-2">{type}</h3>
                         {groupedHistory[brand][type].map(item => <HistoryItemCard key={item.id} item={item} />)}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center text-gray-500 py-16">
                <History className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No History Found</h3>
                <p className="mt-1 text-sm text-gray-500">No records found for the selected period.</p>
              </div>
            )}
          </div>
        </main>
      </ScrollArea>
    </div>
  );
}

export default function MainHistoryPage(props: MainHistoryPageProps) {
  return (
    <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
      <MainHistoryContent {...props} />
    </Suspense>
  );
}
