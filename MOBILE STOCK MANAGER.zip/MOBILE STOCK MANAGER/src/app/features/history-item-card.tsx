
'use client';

import {
  ArrowDown,
  ArrowUp,
  History,
  IndianRupee,
  PackageMinus,
  PackagePlus,
  ShoppingCart,
  Tag,
  Hourglass,
  CheckCircle2,
  BadgeCent,
  AlertTriangle,
  Info,
  RefreshCw,
  ShoppingBag,
  Cpu,
  Smartphone,
  Paintbrush,
  Fingerprint,
  Share2,
} from 'lucide-react';
import { format } from 'date-fns';
import { Card, CardContent } from '@/components/ui/card';
import { type HistoryItem } from './transfer-records/page';
import { Badge } from '@/components/ui/badge';

const DetailItem = ({ icon: Icon, children }: { icon: React.ElementType, children: React.ReactNode }) => (
    <div className="flex items-start text-xs text-gray-500">
        <Icon className="h-3.5 w-3.5 mr-2 mt-0.5 flex-shrink-0" />
        <span className="flex-1">{children}</span>
    </div>
);

const DetailParser = ({ details }: { details: string }) => {
    if (!details) return null;

    const ramStorageMatch = details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = details.match(/ID1?:\s*([^\s,]+)/i);
    const id2Match = details.match(/ID2:\s*([^\s,]+)/i);
    const billMatch = details.match(/Bill:\s*([^\s,]+)/);
    const paymentMatch = details.match(/Sold via\s*(.*)/);
    const fromMatch = details.match(/From\s(.*?)\s-/);
    const toMatch = details.match(/To\s(.*?)\s-/);

    const fromToParts: string[] = [];
    if (fromMatch) fromToParts.push(`From: ${fromMatch[1]}`);
    if (toMatch) fromToParts.push(`To: ${toMatch[1]}`);
    const fromTo = fromToParts.join(' ');

    let color: string | null = null;
    let colorPart = details;

    if (ramStorageMatch) colorPart = colorPart.substring(0, colorPart.indexOf(ramStorageMatch[0]));
    if (id1Match) colorPart = colorPart.substring(0, colorPart.indexOf(id1Match[0]));
    if (fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if (toMatch) colorPart = colorPart.replace(toMatch[0], '');

    colorPart = colorPart.replace(/,/g, '').replace(/-/g, '').trim();
    if (colorPart) {
      color = colorPart;
    }
    
    return (
        <div className="pl-6 text-xs text-gray-500 space-y-1 mt-2">
            {ramStorageMatch && <DetailItem icon={Cpu}>{ramStorageMatch[1]} / {ramStorageMatch[2]}</DetailItem>}
            {color && <DetailItem icon={Paintbrush}>{color}</DetailItem>}
            {fromTo && <DetailItem icon={Share2}>{fromTo}</DetailItem>}
            {id1Match && <DetailItem icon={Fingerprint}>ID1: {id1Match[1]}</DetailItem>}
            {id2Match && <DetailItem icon={Fingerprint}>ID2: {id2Match[1]}</DetailItem>}
            {billMatch && <DetailItem icon={Info}>Bill No: {billMatch[1]}</DetailItem>}
            {paymentMatch && <DetailItem icon={Info}>{paymentMatch[0]}</DetailItem>}
        </div>
    );
};


export const HistoryItemCard = ({ item }: { item: HistoryItem }) => {
  const {
    type,
    productName,
    totalAmount,
    date,
    quantity,
    salePrice,
    purchasePrice,
    details,
    status,
    saleStatus,
    settledDate,
    isReversed,
    reversalReason,
    purchaseDetails,
    saleDetails,
  } = item;
  const isSale = type === 'Sale';
  const isPurchase = type === 'Purchase';
  const isTransferIn = type === 'Transfer In';
  const isTransferOut = type === 'Transfer Out';
  const isSettlement = type === 'Settlement';
  const isPending = status === 'Pending';
  const isPurchaseAndSale = type === 'Purchase & Sale';
  const isTransferInAndSale = type === 'Transfer In & Sale';
  const isUnsettledSale = isSale && saleStatus === 'unsettled_transfer';

  const getIcon = () => {
    if (isReversed) return <RefreshCw className="h-5 w-5 text-pink-600" />;
    if (isUnsettledSale) return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
    if (isPurchaseAndSale || isTransferInAndSale) return <BadgeCent className="h-5 w-5 text-indigo-600" />;
    if (isSale) return <PackageMinus className="h-5 w-5 text-green-600" />;
    if (isPurchase) return <PackagePlus className="h-5 w-5 text-red-600" />;
    if (isTransferIn) return <ArrowDown className="h-5 w-5 text-blue-600" />;
    if (isTransferOut) return <ArrowUp className="h-5 w-5 text-purple-600" />;
    if (isSettlement) return <CheckCircle2 className="h-5 w-5 text-teal-600" />;
    return <History className="h-5 w-5 text-gray-600" />;
  };

  const getBgColor = () => {
    if (isReversed) return 'bg-pink-100';
    if (isUnsettledSale) return 'bg-yellow-100';
    if (isPurchaseAndSale || isTransferInAndSale) return 'bg-indigo-100';
    if (isSale) return 'bg-green-100';
    if (isPurchase) return 'bg-red-100';
    if (isTransferIn) return 'bg-blue-100';
    if (isTransferOut) return 'bg-purple-100';
    if (isSettlement) return 'bg-teal-100';
    return 'bg-gray-100';
  };

  const getTextColor = () => {
    if (isReversed) return 'text-pink-600';
    if (isUnsettledSale) return 'text-yellow-600';
    if (isPurchaseAndSale || isTransferInAndSale) return 'text-indigo-600';
    if (isSale) return 'text-green-600';
    if (isPurchase) return 'text-red-600';
    if (isTransferIn) return 'text-blue-600';
    if (isTransferOut) return 'text-purple-600';
    if (isSettlement) return 'text-teal-600';
    return 'text-gray-600';
  };
  
  const profit = (salePrice && purchasePrice) ? (salePrice - purchasePrice) * quantity : 0;
  
  const cardType = isReversed ? `Reversed (${type})` : type;

  return (
    <Card
      key={item.id}
      className={`bg-white shadow rounded-2xl overflow-hidden mb-3 ${isUnsettledSale ? 'border-yellow-300' : ''} ${isReversed ? 'opacity-80' : ''}`}
    >
      <CardContent className="p-4 flex items-start space-x-3 sm:space-x-4">
        <div className={`p-3 rounded-full mt-1 ${getBgColor()}`}>
          {getIcon()}
        </div>
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
            <div>
              <p className={`font-semibold ${getTextColor()}`}>{cardType}</p>
              <p className="font-bold text-gray-800 text-lg leading-tight">{productName}</p>
            </div>
            <div className="text-left sm:text-right mt-1 sm:mt-0">
              {isReversed && (
                 <Badge
                  variant='destructive'
                  className='bg-pink-100 text-pink-800 border-pink-200 mb-1'
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Reversed
                </Badge>
              )}
              {isUnsettledSale ? (
                 <Badge
                  variant='destructive'
                  className='bg-yellow-100 text-yellow-800 border-yellow-200 mb-1'
                >
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Unsettled Transfer
                </Badge>
              ) : status && !(isPurchaseAndSale || isTransferInAndSale) && !isReversed ? (
                <Badge
                  variant={isPending ? 'destructive' : 'default'}
                  className={
                    isPending
                      ? 'bg-orange-100 text-orange-800 border-orange-200 mb-1'
                      : 'bg-green-100 text-green-800 border-green-200 mb-1'
                  }
                >
                  {isPending ? (
                    <Hourglass className="h-3 w-3 mr-1" />
                  ) : (
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                  )}
                  {item.status}
                </Badge>
              ) : (isPurchaseAndSale || isTransferInAndSale) ? (
                <p className="font-semibold text-lg text-indigo-600">
                  Profit: {profit.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
                </p>
              ) : (isSale || isPurchase) && !(isPurchaseAndSale || isTransferInAndSale) ? (
                 <p className={`font-semibold text-lg ${getTextColor()}`}>
                  {isSale ? '+' : ''}
                  {totalAmount.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR',
                  })}
                </p>
              ) : null}
              <p className="text-xs sm:text-sm text-gray-400">
                {format(new Date(date), 'PP p')}
              </p>
            </div>
          </div>
          <div className="mt-2 space-y-1 text-sm text-gray-600">
            <div className="flex items-center">
              <Tag className="h-4 w-4 mr-2 text-gray-400" />
              <span>Quantity: {quantity}</span>
            </div>
            {(isPurchaseAndSale || isTransferInAndSale) && (
              <>
                <div className="flex items-center">
                  <IndianRupee className="h-4 w-4 mr-2 text-red-400" />
                  <span>
                    Cost Price: {purchasePrice?.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
                  </span>
                </div>
                <div className="flex items-center">
                  <IndianRupee className="h-4 w-4 mr-2 text-green-400" />
                  <span>
                    Sale Price: {salePrice?.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
                  </span>
                </div>
              </>
            )}
            {(isSale || isPurchase) && !(isPurchaseAndSale || isTransferInAndSale) && (
              <div className="flex items-center">
                <IndianRupee className="h-4 w-4 mr-2 text-gray-400" />
                <span>
                  {isSale ? 'Sale Price: ' : 'Purchase Price: '}
                  {(isSale ? salePrice : purchasePrice)?.toLocaleString(
                    'en-IN',
                    {
                      style: 'currency',
                      currency: 'INR',
                    }
                  )}
                </span>
              </div>
            )}
            {details && !(isPurchaseAndSale || isTransferInAndSale) && (
              <div className="flex items-start">
                 <div className="flex-1">
                    <DetailParser details={details} />
                </div>
              </div>
            )}
            {(isPurchaseAndSale || isTransferInAndSale) && purchaseDetails && (
                <div className="flex items-start">
                    <PackagePlus className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                        <span className="font-semibold">{isTransferInAndSale ? 'Transfer In:' : 'Purchase:'}</span>
                        <DetailParser details={purchaseDetails} />
                    </div>
                </div>
            )}
            {(isPurchaseAndSale || isTransferInAndSale) && saleDetails && (
                <div className="flex items-start">
                    <PackageMinus className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0 mt-0.5" />
                     <div className="flex-1">
                        <span className="font-semibold">Sale:</span>
                        <DetailParser details={saleDetails} />
                    </div>
                </div>
            )}
             {settledDate && !isReversed && (
                <div className="flex items-start text-xs text-gray-500 mt-2 pt-2 border-t">
                    <CheckCircle2 className="h-3 w-3 mr-2 mt-0.5" />
                    <span>Settled on: {format(new Date(settledDate), 'PP p')}</span>
                </div>
            )}
            {isReversed && reversalReason && (
                 <div className="flex items-start text-xs text-gray-500 mt-2 pt-2 border-t">
                    <Info className="h-3 w-3 mr-2 mt-0.5" />
                    <span>Reversal Reason: {reversalReason}</span>
                </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
