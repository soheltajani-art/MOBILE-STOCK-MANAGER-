
'use client';

import { Bug, Lightbulb, Bot, ArrowLeft, BookOpen, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function HelpSupportPage() {
    const router = useRouter();
  return (
    <div className="flex flex-col h-screen bg-background font-sans slide-in-from-right">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
                <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
                </Button>
                <h1 className="text-xl font-bold text-foreground">
                Help & Support
                </h1>
                <div className="w-10"></div>
            </div>
            </div>
        </header>
        <div className="flex-1 p-4 md:p-6 flex items-center justify-center">
            <Card className="w-full max-w-md shadow-lg rounded-2xl bg-card">
                <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold">Contact & Support</CardTitle>
                <CardDescription>
                    Have a problem or a great idea?
                </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Link href="/features/help-support/app-guide" className="w-full">
                        <Button variant="outline" className="w-full h-16 text-md justify-start p-4">
                            <div className="bg-blue-100 p-3 rounded-lg mr-4">
                                <BookOpen className="h-6 w-6 text-blue-600" />
                            </div>
                            <div>
                                <p className="font-semibold text-left">App Guide</p>
                                <p className="text-xs text-muted-foreground text-left">Learn how the app works.</p>
                            </div>
                        </Button>
                    </Link>
                    <a href="mailto:soheltajani@gmail.com?subject=Bug/Error%20Report%20for%20MOBILE%20STOCK%20MANAGER" className="w-full">
                        <Button variant="outline" className="w-full h-16 text-md justify-start p-4">
                            <div className="bg-red-100 p-3 rounded-lg mr-4">
                                <Bug className="h-6 w-6 text-red-600" />
                            </div>
                            <div>
                                <p className="font-semibold text-left">Error Report, Bug Report</p>
                                <p className="text-xs text-muted-foreground text-left">Click here to send an email.</p>
                            </div>
                        </Button>
                    </a>
                    <a href="mailto:soheltajani@gmail.com?subject=Feature%20Suggestion%20for%20MOBILE%20STOCK%20MANAGER" className="w-full">
                        <Button variant="outline" className="w-full h-16 text-md justify-start p-4">
                            <div className="bg-yellow-100 p-3 rounded-lg mr-4">
                                <Lightbulb className="h-6 w-6 text-yellow-600" />
                            </div>
                            <div>
                                <p className="font-semibold text-left">Help and Query, Suggest a Feature</p>
                                <p className="text-xs text-muted-foreground text-left">Click here to send an email.</p>
                            </div>
                        </Button>
                    </a>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
