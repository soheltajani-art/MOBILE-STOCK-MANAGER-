'use client';

import { ArrowLeft, BookOpen, CircleDollarSign, History, Info, LineChart, MapPin, Package, PackageMinus, PackagePlus, Repeat, Search, ShoppingBag, Sparkles, TrendingUp, Users } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';

type GuideSection = {
    id: string;
    title: string;
    description: string;
    icon: React.ElementType;
    steps: {
        title: string;
        description: string;
    }[];
}

const guideSections: GuideSection[] = [
    {
        id: 'dashboard',
        title: 'Dashboard Overview',
        description: 'Your main control center. Here’s what everything does.',
        icon: LineChart,
        steps: [
            {
                title: 'Total Stock',
                description: 'This shows the total number of products currently in your main inventory. This number reflects items physically in your store. It goes up when you perform a "Purchase" or "Transfer In". It only goes down when you complete a "Stock Out" (sale) or when a "Transfer Out" is settled (marked as "Paid"). An "Unpaid" Transfer Out does not reduce this number because the item is still considered yours until the transfer is financially settled.',
            },
            {
                title: 'Today\'s Sale Quantity',
                description: 'This is a simple count of how many items you have sold today from your main inventory.',
            },
            {
                title: 'Search All Products',
                description: 'Use this search bar to instantly find any product in your entire inventory (both main and basic stock) by its name or IMEI number. This takes you to the "Inventory Stock" page with the results.',
            },
            {
                title: 'Daily Stats (Purchases, Sold Out, Transfers)',
                description: 'These four cards give you a quick summary of today’s key activities: the number of new purchases, items sold, transfers in, and transfers out, regardless of their settlement status.',
            },
            {
                title: 'Today’s Sales (Rupees) & Today\'s Profit',
                description: 'These cards track your daily financial performance. "Sales" is the total revenue from all items sold today. "Profit" is the total (Sale Price - Purchase Price) ONLY for items that were directly purchased and then sold. Profit from items that were transferred in and then sold is tracked separately in "Transfer Calcs".',
            },
            {
                title: 'Recent Activity',
                description: 'This feed shows a live, scrollable list of all your most recent transactions that happened today, including merged "Purchase & Sale" events that show you the profit from a single transaction.',
            },
        ]
    },
    {
        id: 'features',
        title: 'Features Page',
        description: 'A breakdown of all the features available in the app.',
        icon: Package,
        steps: [
             {
                title: 'WHERE IS MY PRODUCT',
                description: 'A powerful search tool to find any product by its ID (IMEI) or name. It shows you the complete history of a product, including its purchase, sale, and all transfer events, in a single, clear timeline.',
            },
            {
                title: 'MAIN HISTORY',
                description: 'Your financial command center for direct sales. It provides a detailed history of all sales and direct purchases for a selected period (day, month, or year), along with profit calculations ONLY for items bought and sold directly from your store. It does not include profit from transferred items.',
            },
             {
                title: 'TRANSFER SUMMARY',
                description: 'Your financial command center for transfers. This page calculates the profit made specifically from items that were transferred (either in or out) and then settled. This is where you track the profitability of your inter-shop movements.',
            },
            {
                title: 'TRANSFER RECORDS',
                description: 'The central hub for managing all your product transfers. Here you can view the status of all incoming and outgoing transfers, and take action to "Settle" an unpaid transfer or "Reverse" a pending one.',
            },
             {
                title: 'LIFETIME HISTORY',
                description: 'An archive of every single product that has ever been entered into your main inventory, including items that are currently in stock and those that have been sold. This is useful for auditing and long-term tracking.',
            },
             {
                title: 'REVERSE TRANSFERS',
                description: 'A specific log that only shows transfers that have been reversed. It includes the date of the reversal and the reason provided, giving you a clear record of cancelled transactions.',
            },
            {
                title: 'BASIC STOCK',
                description: 'A separate, simplified inventory for items that don\'t need detailed tracking (like RAM/Storage). It has its own purchase, sell, and history functions, completely independent of the main inventory.',
            },
            {
                title: 'HELP & SUPPORT',
                description: 'Access this App Guide or find contact information for bug reports and feature suggestions.',
            },
            {
                title: 'RESET ALL DATA',
                description: 'WARNING: This permanently deletes all data from the application, including all inventories, histories, and settings. This action cannot be undone.',
            }
        ]
    },
     {
        id: 'manage-shop-team',
        title: 'How "Manage Shop Team" Works',
        description: 'Understand the two-step process for syncing devices.',
        icon: Users,
        steps: [
            {
                title: 'What it Does',
                description: 'This feature allows you to sync new stock updates (purchases, sales, transfers) in real-time between two connected devices. It uses a direct peer-to-peer connection.'
            },
            {
                title: 'Step 1: Initial Setup for a New Employee/Device',
                description: 'This feature does NOT transfer your entire existing inventory automatically. For the first-time setup of a new device, you must perform a manual backup and restore. 1) The admin creates a backup file from the "Backup & Restore" page. 2) The admin sends this file to the new device. 3) The employee uses the "Restore from Backup" option on their device. This ensures both devices start with identical data.'
            },
            {
                title: 'Step 2: Real-Time Syncing',
                description: 'After the initial setup is complete, you can use the "Manage Shop Team" feature to establish a real-time connection. Once connected, any new action (like a sale or purchase) on one device will be instantly reflected on the other.'
            },
            {
                title: 'Important Notice',
                description: 'This connection is for live updates only. Always perform the backup and restore process first when setting up a new device to avoid data inconsistencies.'
            },
        ]
    },
     {
        id: 'transfer-summary',
        title: 'How Transfer Summary Works',
        description: 'Understand the profit calculations for your transferred items.',
        icon: TrendingUp,
        steps: [
            {
                title: 'What is Transfer Summary?',
                description: 'This page is dedicated to calculating the financial performance of your transferred items. It only considers transfers that have been "Settled" (i.e., financially completed). It answers two key questions: How much profit did I make from items I transferred OUT? And how much profit did I make by selling items that were transferred IN?'
            },
            {
                title: 'Settled Transfer In Amount',
                description: 'This is the total cost price of all items that you transferred IN from another shop and were settled within the selected date range. This represents your expense for acquiring these items.'
            },
            {
                title: 'Settled Transfer Out Amount',
                description: 'This is the total price at which you transferred items OUT to another shop and were settled within the selected date range. This represents your revenue from these transfers.'
            },
            {
                title: 'Transfer Out Profit',
                description: 'This is a direct profit calculation: (Transfer Out Price - Your Original Purchase Price). It shows the immediate profit you made by transferring an item out to another shop. This is calculated for every settled "Transfer Out" event.'
            },
            {
                title: 'Transfer In, Sold Profit',
                description: 'This is a multi-step profit calculation: (Final Sale Price - Transfer In Price). It tracks an item that was transferred IN from another shop and was later sold to a customer within the selected date range. This shows the profit you made on that specific resale.'
            },
        ]
    },
    {
        id: 'purchase',
        title: 'How to Purchase Stock (Main)',
        description: 'A step-by-step guide to adding a new product to your main inventory.',
        icon: PackagePlus,
        steps: [
            {
                title: 'Model No. of Mobile',
                description: 'Enter the full model name of the product you are purchasing (e.g., "iPhone 15 Pro Max").',
            },
            {
                title: 'Product ID (IMEI) & Duplicate Prevention',
                description: 'Enter the unique 15-digit IMEI number for the product. The app will immediately check if this ID already exists in your main inventory. If a duplicate is found, it will show a warning dialog and prevent you from adding it again. This ensures every product in your stock is unique.',
            },
            {
                title: 'RAM/Storage Configuration',
                description: 'Select the RAM and Storage capacity for the device from the dropdown menus. Selecting a RAM value will filter the Storage options to show compatible configurations.',
            },
            {
                title: 'Colour',
                description: 'Enter the color of the product (e.g., "Deep Blue").',
            },
             {
                title: 'Retailer\'s Buying Price',
                description: 'Enter the price you paid to purchase this product. This is crucial for accurate profit tracking later on.',
            },
            {
                title: 'Purchase Stock Button',
                description: 'Once all fields are filled, tap this button. The product is added to your inventory with a stock count of 1, and a "Purchase" record is created in your Main History.',
            },
        ]
    },
     {
        id: 'sell',
        title: 'How to Sell Stock (Main)',
        description: 'A step-by-step guide to selling a product from your main inventory.',
        icon: PackageMinus,
        steps: [
            {
                title: 'Scan or Enter Product ID & Sale Prevention',
                description: 'The fastest way to sell a product is to scan its barcode or type its 15-digit IMEI number into the "PRODUCT ID 1" field. The app will automatically find the product and fill in its details. Crucially, the app performs checks: if the product is already sold (stock is 0) or is part of an active "Transfer Out" that has not been reversed, the app will show an error and prevent the sale. This stops you from selling the same item twice or selling an item promised to another shop.',
            },
             {
                title: 'Bill No. & Duplicate Prevention',
                description: 'You can optionally enter a bill number for the sale. The app checks if this bill number has been used before in any other sale. If it has, it will show an error message and prevent you from using the same bill number again, ensuring each sale has a unique identifier if provided.',
            },
            {
                title: 'Retailer\'s Selling Price',
                description: 'Enter the final price you are selling the product for.',
            },
            {
                title: 'Payment Method',
                description: 'Choose how the customer paid: "Cash" or "Finance". If you select "Finance", you must also enter the name of the financing company. This is recorded in the sale details.',
            },
            {
                title: 'Sold Stock Button',
                description: 'After verifying the details and entering the sale price, tap this button. The product\'s stock will be set to 0, and a "Sale" record will be created in your history.',
            },
        ]
    },
     {
        id: 'transfer',
        title: 'How to Transfer Stock',
        description: 'A guide to transferring products to or from another shop.',
        icon: Repeat,
        steps: [
            {
                title: 'Transfer Validation & Duplicate Prevention',
                description: 'To start a transfer, scan a barcode or search for a product. If the product is in your inventory, it auto-fills for a "Transfer Out." If not, it sets up a "Transfer In." The app then runs several critical checks: 1) A product that arrived via an "Unpaid" Transfer In cannot be transferred out. 2) A product that is already part of an active (un-reversed) Transfer Out (whether Paid or Unpaid) cannot be transferred again. You must reverse the original transfer to free up the item. If any of these checks fail, an error will be shown.',
            },
             {
                title: 'Transfer Type',
                description: 'Select "Transfer In" if you are receiving a product from another shop. This will add the item to your inventory. Select "Transfer Out" if you are sending a product to another shop.',
            },
            {
                title: 'From and To Fields',
                description: 'The app automatically sets one field to your shop name based on the transfer type. You must fill in the name of the *other* shop involved in the transfer.',
            },
             {
                title: 'Payment Status',
                description: 'Select "Paid" if the transfer has already been financially settled. This is a final state. For "Transfer Out", this will immediately deduct the item from your stock. For "Transfer In", it marks it as settled. Select "Unpaid" to mark it as pending. Unpaid transfers do not affect stock counts and must be settled later from the "Transfer Records" page.',
            },
        ]
    },
    {
        id: 'basic-stock',
        title: 'How Basic Stock Works',
        description: 'A guide to the simplified secondary inventory system.',
        icon: ShoppingBag,
        steps: [
            {
                title: 'What is Basic Stock?',
                description: 'Basic Stock is a separate, simple inventory for items that don\'t require detailed configuration tracking (like RAM/Storage). It has its own dashboard, purchase, and sell forms. It is completely independent from the main inventory.'
            },
             {
                title: 'Purchase',
                description: 'The "Purchase" form for Basic Stock is simplified. You only need to enter the Model No, IMEI(s), Color, and Buying Price. When you purchase, the item is added to the "basic-products" list in your local storage.'
            },
            {
                title: 'Sell',
                description: 'The "Sell" form allows you to search for a product in your Basic Stock by its IMEI. Once found, its details are auto-filled. You then enter the selling price and payment details to complete the sale, which marks its stock as 0.'
            },
             {
                title: 'History',
                description: 'The "History" page within Basic Stock shows a complete record of all purchases and sales made *only* in the Basic Stock inventory. It also calculates total sales, purchases, and profit for the selected period (day, month, or year) based on this separate history.'
            },
        ]
    }
];

export default function AppGuidePage() {
    const router = useRouter();

    return (
        <div className="flex flex-col h-screen bg-background font-sans">
            <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <Button variant="ghost" size="icon" onClick={() => router.back()}>
                            <ArrowLeft className="h-6 w-6 text-foreground" />
                        </Button>
                        <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
                            <BookOpen className="h-5 w-5 text-blue-500" />
                            App Guide
                        </h1>
                        <div className="w-10"></div>
                    </div>
                </div>
            </header>

            <ScrollArea className="flex-1">
                <main className="p-4 md:p-6">
                    <Card className="w-full max-w-3xl mx-auto shadow-lg rounded-2xl bg-card">
                        <CardHeader>
                            <CardTitle>How The App Works</CardTitle>
                            <CardDescription>Click on a topic to see a detailed guide to its features and workflow.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Accordion type="single" collapsible className="w-full">
                                {guideSections.map((section) => (
                                    <AccordionItem value={section.id} key={section.id}>
                                        <AccordionTrigger className="text-left hover:no-underline -mx-2 px-2">
                                            <div className="flex items-start gap-3 w-full">
                                                <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                                                    <section.icon className="h-5 w-5 text-blue-500" />
                                                </div>
                                                <div className="flex-1 text-left min-w-0">
                                                    <p className="font-semibold text-base truncate sm:text-base sm:whitespace-normal">{section.title}</p>
                                                    <p className="text-sm text-muted-foreground font-normal leading-snug">{section.description}</p>
                                                </div>
                                            </div>
                                        </AccordionTrigger>
                                        <AccordionContent className="pl-6 border-l-2 border-blue-200 ml-5 space-y-6">
                                            {section.steps.map((step, index) => (
                                                <div key={index} className="pt-4 first:pt-0">
                                                    <h4 className="font-semibold text-md text-foreground mb-2">{step.title}</h4>
                                                    <p className="text-sm text-muted-foreground mb-4">{step.description}</p>
                                                </div>
                                            ))}
                                        </AccordionContent>
                                    </AccordionItem>
                                ))}
                            </Accordion>
                        </CardContent>
                    </Card>
                </main>
            </ScrollArea>
        </div>
    );
}
