
'use client';

import { Suspense, useState, useMemo, useEffect } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ArrowDown,
  ArrowUp,
  IndianRupee,
  Info,
  Calendar as CalendarIcon,
  Search,
  Loader2,
  History as HistoryIcon,
  Sheet,
  Building,
  ArrowLeft,
} from 'lucide-react';
import { format, isSameDay, isSameMonth, isSameYear, isValid } from 'date-fns';
import { useSearchParams, useRouter } from 'next/navigation';

import { Skeleton } from '@/components/ui/skeleton';
import { type HistoryItem } from '../transfer-records/page';
import { type Product } from '../where-is-my-product/page';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { HistoryItemCard } from '../history-item-card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Calendar } from '@/components/ui/calendar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import ProductDetailsPage from '../where-is-my-product/product-details/page';
import { toast } from 'sonner';

interface TransferSummaryPageProps {
  onBack: () => void;
}

type FilterMode = 'day' | 'month' | 'year';
type HistoryFilterType = 'all' | 'in' | 'out';


function TransferSummaryContent({ onBack }: TransferSummaryPageProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialDateParam = searchParams.get('date');
  const initialDate = initialDateParam && isValid(new Date(initialDateParam)) ? new Date(initialDateParam) : new Date();

  const [historyData] = useLocalStorage<HistoryItem[]>('history', []);
  const [products] = useLocalStorage<Product[]>('products', []);
  const [isMounted, setIsMounted] = useState(false);
  const [date, setDate] = useState<Date | undefined>(initialDate);
  const [filterMode, setFilterMode] = useState<FilterMode>('day');
  const [historyFilter, setHistoryFilter] = useState<HistoryFilterType>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => { setIsMounted(true); }, []);

  const {
    settledTransferInAmount,
    settledTransferOutAmount,
    transferInSoldProfit,
    transferOutProfit,
    groupedHistory,
  } = useMemo(() => {
    if (!isMounted) return { settledTransferInAmount: 0, settledTransferOutAmount: 0, transferInSoldProfit: 0, transferOutProfit: 0, groupedHistory: {} };
    
    const isDateInRange = (itemDate: Date): boolean => {
      if (!date) return true;
      const validDate = new Date(itemDate);
      if (!isValid(validDate)) return false;
      if (filterMode === 'day') return isSameDay(validDate, date);
      if (filterMode === 'month') return isSameMonth(validDate, date);
      if (filterMode === 'year') return isSameYear(validDate, date);
      return true;
    };
    
    const settlementsInDateRange = historyData.filter(item => item.type === 'Settlement' && isDateInRange(new Date(item.date)));
    const settledViaEventIds = new Set(settlementsInDateRange.map(s => s.originalTransferId));

    const transfersSettledOnCreation = historyData.filter(item => 
      (item.type === 'Transfer In' || item.type === 'Transfer Out') && 
      item.status === 'Settled' && 
      isDateInRange(new Date(item.date)) &&
      !settledViaEventIds.has(item.id)
    );

    const allSettledTransfers = [...historyData.filter(item => settledViaEventIds.has(item.id)), ...transfersSettledOnCreation];

    const settledTransferInAmount = allSettledTransfers.filter(item => item.type === 'Transfer In').reduce((sum, item) => sum + (item.purchasePrice || 0), 0);
    const settledTransferOutAmount = allSettledTransfers.filter(item => item.type === 'Transfer Out').reduce((sum, item) => sum + (item.salePrice || 0), 0);
    
    const transferOutProfit = allSettledTransfers.filter(item => item.type === 'Transfer Out' && item.salePrice && item.purchasePrice)
      .reduce((sum, item) => sum + (item.salePrice! - item.purchasePrice!), 0);
      
    const salesInDateRange = historyData.filter(item => item.type === 'Sale' && isDateInRange(new Date(item.date)));
    const transferInSoldProfit = salesInDateRange.reduce((sum, sale) => {
      const idMatch = sale.details.match(/ID1?:\s*([^\s,]+)/i);
      if (!idMatch) return sum;
      const productId = idMatch[1].toLowerCase();
      const transferInRecord = historyData.find(h => h.type === 'Transfer In' && (h.details.toLowerCase().includes(`id1: ${productId}`) || h.details.toLowerCase().includes(`id: ${productId}`)));
      if (transferInRecord && transferInRecord.purchasePrice && sale.salePrice) {
         return sum + (sale.salePrice - transferInRecord.purchasePrice);
      }
      return sum;
    }, 0);

    let displayHistory = allSettledTransfers.map(item => ({
        ...item, status: 'Settled' as const,
        settledDate: item.settledDate || settlementsInDateRange.find(s => s.originalTransferId === item.id)?.date || item.date
    }));

    if (historyFilter !== 'all') {
        displayHistory = displayHistory.filter(item => (historyFilter === 'in' ? item.type === 'Transfer In' : item.type === 'Transfer Out'));
    }
    if (searchTerm) {
      displayHistory = displayHistory.filter(item => item.productName.toLowerCase().includes(searchTerm.toLowerCase()) || item.details?.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    
    const groupedHistory: { [brand: string]: { [type: string]: HistoryItem[] } } = {};
    displayHistory.sort((a, b) => new Date(b.settledDate!).getTime() - new Date(a.settledDate!).getTime())
      .forEach(item => {
        const idMatch = item.details.match(/ID1?:\s*([^\s,]+)/i);
        const productId = idMatch ? idMatch[1] : null;
        const product = products.find(p => p.id === productId);
        const brand = product?.brand || 'Unbranded';
        const typeKey = `${item.type} (Settled)`;

        if (!groupedHistory[brand]) groupedHistory[brand] = {};
        if (!groupedHistory[brand][typeKey]) groupedHistory[brand][typeKey] = [];
        groupedHistory[brand][typeKey].push(item);
      });

    return { settledTransferInAmount, settledTransferOutAmount, transferInSoldProfit, transferOutProfit, groupedHistory };
  }, [historyData, isMounted, date, filterMode, searchTerm, historyFilter, products]);

  const handleHistoryItemClick = (item: HistoryItem) => {
    const idRegex = /ID1?:\s*([^\s,]+)/i;
    const detailsString = item.details || item.purchaseDetails || '';
    const match = detailsString.match(idRegex);
    const lookupId = match ? match[1] : null;

    if (!lookupId) {
      toast.error('Product ID not found');
      return;
    }
    const product = products.find(p => p.id === lookupId || (p.id2 && p.id2 === lookupId));
    if (product) setSelectedProduct(product);
  };
  
  const handleViewReport = () => {
    const reportDate = date ? date.toISOString() : new Date().toISOString();
    router.push(`/features/transfer-summary/report?date=${reportDate}&filterMode=${filterMode}`);
  };

  const stats = [
    { title: 'Settled Transfer In Amount', value: settledTransferInAmount, icon: ArrowDown, color: 'text-white bg-gradient-to-br from-blue-500 to-sky-600' },
    { title: 'Settled Transfer Out Amount', value: settledTransferOutAmount, icon: ArrowUp, color: 'text-white bg-gradient-to-br from-purple-500 to-indigo-600' },
    { title: 'Transfer In, Sold Profit', value: transferInSoldProfit, icon: IndianRupee, color: 'text-white bg-gradient-to-br from-green-500 to-teal-500' },
    { title: 'Transfer Out Profit', value: transferOutProfit, icon: IndianRupee, color: 'text-white bg-gradient-to-br from-pink-500 to-red-600' },
  ];
  
  const sortedBrands = Object.keys(groupedHistory).sort();

  if (selectedProduct) {
    return <ProductDetailsPage product={selectedProduct} onBack={() => setSelectedProduct(null)} />;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right overflow-hidden">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                  <ArrowLeft className="h-6 w-6 text-foreground" />
              </Button>
              <h1 className="text-xl font-bold text-foreground">
                Transfer Summary
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>
        <ScrollArea className="flex-1">
        <div className="flex flex-col h-full bg-gray-50 font-sans p-4 md:p-6 space-y-6">
        {stats.map((stat) => (
            <Card key={stat.title} className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-medium">{stat.title}</CardTitle><stat.icon className="h-6 w-6" />
              </CardHeader>
              <CardContent>
                {isMounted ? <div className="text-4xl font-bold">{stat.value.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}</div> : <Skeleton className="h-10 w-3/4" />}
              </CardContent>
            </Card>
        ))}
        <Alert className="bg-blue-50 border-blue-200">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800">Please Note</AlertTitle>
            <AlertDescription className="text-blue-700">This page only shows settled transfer details. To see pending transfers, please go to the Transfer Records page.</AlertDescription>
        </Alert>

        <div className="pt-4 border-t">
          <Button className="w-full h-12 mb-4" variant="outline" onClick={handleViewReport}><Sheet className="mr-2 h-4 w-4" /> View Report</Button>
          <div className="flex flex-col md:flex-row items-center gap-4 mb-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant={'outline'} className={cn('w-full md:w-[280px] justify-start text-left font-normal h-12 rounded-xl shadow-sm bg-white', !date && 'text-muted-foreground')}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP') : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={date} onSelect={setDate} initialFocus /></PopoverContent>
            </Popover>
            <Select value={filterMode} onValueChange={(value: FilterMode) => setFilterMode(value)}>
              <SelectTrigger className="w-full md:w-[180px] h-12 rounded-xl shadow-sm bg-white"><SelectValue placeholder="Filter by" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Day</SelectItem><SelectItem value="month">Month</SelectItem><SelectItem value="year">Year</SelectItem>
              </SelectContent>
            </Select>
             <Select value={historyFilter} onValueChange={(value: HistoryFilterType) => setHistoryFilter(value)}>
                <SelectTrigger className="w-full md:w-auto flex-1 h-12 rounded-xl shadow-sm bg-white"><SelectValue placeholder="Filter History" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Settled</SelectItem><SelectItem value="in">Transfer In Settled</SelectItem><SelectItem value="out">Transfer Out Settled</SelectItem>
                </SelectContent>
            </Select>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input placeholder="Search by product name or details..." className="pl-10 bg-white rounded-xl shadow-sm h-12" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
        </div>

        <div className="space-y-6">
          {!isMounted ? (
            <div className="space-y-4"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>
          ) : sortedBrands.length > 0 ? (
            sortedBrands.map(brand => (
              <Card key={brand} className="bg-white shadow-lg rounded-2xl">
                <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4 border-b">
                  <Building className="h-5 w-5 text-gray-500" /><CardTitle className="text-lg">{brand}</CardTitle>
                </CardHeader>
                <CardContent className="p-2 pt-2">
                  {Object.keys(groupedHistory[brand]).sort().map(type => (
                    <div key={type} className="mb-4 last:mb-0">
                      <h3 className="font-semibold text-md text-gray-600 px-2 py-1 bg-gray-100 rounded-md mb-2">{type}</h3>
                      {groupedHistory[brand][type].map(item => (
                        <div key={item.id} onClick={() => handleHistoryItemClick(item)} className="cursor-pointer">
                          <HistoryItemCard item={item} />
                        </div>
                      ))}
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center text-gray-500 py-16">
              <HistoryIcon className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">No History Found</h3>
              <p className="mt-1 text-sm text-gray-500">No records found for the selected period.</p>
            </div>
          )}
        </div>
        </div>
        </ScrollArea>
    </div>
  );
}

export default function TransferSummaryPage(props: TransferSummaryPageProps) {
    return (
        <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <TransferSummaryContent {...props} />
        </Suspense>
    )
}
