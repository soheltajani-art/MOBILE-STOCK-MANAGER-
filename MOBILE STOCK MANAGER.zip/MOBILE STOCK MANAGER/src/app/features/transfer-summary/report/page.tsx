
'use client';

import { Suspense, useMemo } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { HistoryItem } from '../../transfer-records/page';
import UnifiedSheetUI from '@/components/ui/unified-sheet';
import { isSameDay, isSameMonth, isSameYear, isValid, format, getMonth, getYear } from 'date-fns';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { type ShopInfo } from '@/app/shop-information/page';

interface DailySummary {
  date: string;
  totalIn: number;
  totalOut: number;
  profitOut: number;
  profitInSold: number;
}

interface MonthlySummary {
  month: string;
  totalIn: number;
  totalOut: number;
  profitOut: number;
  profitInSold: number;
}


function TransferSummaryReportContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const dateParam = searchParams.get('date');
  const filterMode = searchParams.get('filterMode') || 'day';

  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const [shopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);

  const myShopName = shopInfo?.shopName || 'My Shop';
  const targetDate = dateParam && isValid(new Date(dateParam)) ? new Date(dateParam) : new Date();

  const transfersHtml = useMemo(() => {
    const isDateInRange = (itemDate: Date): boolean => {
      if (!targetDate) return true;
      const validDate = new Date(itemDate);
      if (!isValid(validDate)) return false;
      if (filterMode === 'day') return isSameDay(validDate, targetDate);
      if (filterMode === 'month') return isSameMonth(validDate, targetDate);
      if (filterMode === 'year') return isSameYear(validDate, targetDate);
      return true;
    };
    
    const settlementsInDateRange = history.filter(item => 
      item.type === 'Settlement' && isDateInRange(new Date(item.date))
    );
    const settledViaEventIds = new Set(settlementsInDateRange.map(s => s.originalTransferId));

    const transfersSettledOnCreation = history.filter(item => {
        const isTransfer = item.type === 'Transfer In' || item.type === 'Transfer Out';
        const isSettled = item.status === 'Settled';
        const createdInRange = isDateInRange(new Date(item.date));
        const notAlreadyCounted = !settledViaEventIds.has(item.id); 
        return isTransfer && isSettled && createdInRange && notAlreadyCounted;
    });

    const allSettledTransfers = [
        ...history.filter(item => settledViaEventIds.has(item.id)),
        ...transfersSettledOnCreation
    ];

    if (filterMode === 'day') {
      let totalIn = 0;
      let totalOut = 0;
      let profitOut = 0;
      let profitInSold = 0;

      const salesInDay = history.filter(item => item.type === 'Sale' && isDateInRange(new Date(item.date)));
      
      salesInDay.forEach(sale => {
        const idMatch = sale.details.match(/ID1?:\s*([^\s,]+)/i);
        if (!idMatch) return;

        const productId = idMatch[1].toLowerCase();
        const transferInRecord = history.find(h => 
            h.type === 'Transfer In' && (h.details.toLowerCase().includes(`id1: ${productId}`) || h.details.toLowerCase().includes(`id: ${productId}`))
        );
        if (transferInRecord && transferInRecord.purchasePrice && sale.salePrice) {
            profitInSold += sale.salePrice - transferInRecord.purchasePrice;
        }
      });
      
      const tableRows = allSettledTransfers.map((item, index) => {
        let profit = 0;
        if(item.type === 'Transfer In') totalIn += item.purchasePrice || 0;
        if(item.type === 'Transfer Out') {
            totalOut += item.salePrice || 0;
            profit = (item.salePrice || 0) - (item.purchasePrice || 0);
            profitOut += profit;
        }

        const fromMatch = item.details.match(/From\s*([^-\s,]+)/);
        const toMatch = item.details.match(/To\s*([^-\s,]+)/);
        
        const fromShop = item.type === 'Transfer Out' ? myShopName : (fromMatch ? fromMatch[1] : 'N/A');
        const toShop = item.type === 'Transfer In' ? myShopName : (toMatch ? toMatch[1] : 'N/A');
        
        return `
            <tr>
                <th class="px-2 py-1 bg-gray-50" style="border: 1px solid #ccc; white-space: nowrap;">${index + 1}</th>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${item.productName}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${item.type}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${fromShop}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${toShop}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${(item.type === 'Transfer In' ? item.purchasePrice : item.salePrice)?.toLocaleString() || '0'}</td>
                <td class="px-3 py-1" style="border: 1px solid #ccc; white-space: nowrap;">${profit.toLocaleString()}</td>
            </tr>
        `;
      }).join('');
      
      const tfoot = `
        <tfoot>
            <tr><th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc;">Total Settled In:</th><th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${totalIn.toLocaleString()}</th></tr>
            <tr><th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc;">Total Settled Out:</th><th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${totalOut.toLocaleString()}</th></tr>
            <tr><th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc;">Total Transfer Out Profit:</th><th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${profitOut.toLocaleString()}</th></tr>
            <tr><th colspan="6" class="px-3 py-2 bg-gray-200 text-right font-bold" style="border: 1px solid #ccc;">Total Transfer In (Sold) Profit:</th><th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${profitInSold.toLocaleString()}</th></tr>
        </tfoot>
      `;

      return `
        <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%;">
          <thead>
            <tr>
              <th class="px-2 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">#</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Product Name</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Type</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">From</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">To</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">Amount</th>
              <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc; white-space: nowrap;">T.Out Profit</th>
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
          ${tfoot}
        </table>
      `;
    } else {
        const summaries: Record<string, DailySummary | MonthlySummary> = {};
        const isYearView = filterMode === 'year';

        // Initialize summaries
        if (isYearView) {
            for(let i = 0; i < 12; i++) {
                const monthName = format(new Date(getYear(targetDate), i), 'MMMM');
                summaries[i] = { month: monthName, totalIn: 0, totalOut: 0, profitOut: 0, profitInSold: 0 };
            }
        }

        allSettledTransfers.forEach(item => {
            const dateStr = isYearView ? getMonth(new Date(item.date)).toString() : format(new Date(item.date), 'dd/MM/yy');
            if (!summaries[dateStr]) {
                summaries[dateStr] = { date: dateStr, totalIn: 0, totalOut: 0, profitOut: 0, profitInSold: 0 };
            }
            if(item.type === 'Transfer In') summaries[dateStr].totalIn += item.purchasePrice || 0;
            if(item.type === 'Transfer Out') {
                summaries[dateStr].totalOut += item.salePrice || 0;
                summaries[dateStr].profitOut += (item.salePrice || 0) - (item.purchasePrice || 0);
            }
        });

        history.filter(item => item.type === 'Sale' && isDateInRange(new Date(item.date))).forEach(sale => {
            const dateStr = isYearView ? getMonth(new Date(sale.date)).toString() : format(new Date(sale.date), 'dd/MM/yy');
            const idMatch = sale.details.match(/ID1?:\s*([^\s,]+)/i);
            if (!idMatch) return;
            const productId = idMatch[1].toLowerCase();
            const transferInRecord = history.find(h => h.type === 'Transfer In' && (h.details.toLowerCase().includes(`id1: ${productId}`) || h.details.toLowerCase().includes(`id: ${productId}`)));
            if (transferInRecord && transferInRecord.purchasePrice && sale.salePrice) {
                if(!summaries[dateStr]) summaries[dateStr] = { [isYearView ? 'month' : 'date']: isYearView ? format(new Date(sale.date), 'MMMM') : dateStr, totalIn: 0, totalOut: 0, profitOut: 0, profitInSold: 0};
                (summaries[dateStr] as DailySummary | MonthlySummary).profitInSold += sale.salePrice - transferInRecord.purchasePrice;
            }
        });

        const sortedSummaries = Object.values(summaries);
        if(!isYearView) {
            sortedSummaries.sort((a,b) => (a as DailySummary).date.localeCompare((b as DailySummary).date));
        }

        let grandTotalIn = 0, grandTotalOut = 0, grandTotalProfitOut = 0, grandTotalProfitInSold = 0;
        const tableRows = sortedSummaries.map(summary => {
            grandTotalIn += summary.totalIn;
            grandTotalOut += summary.totalOut;
            grandTotalProfitOut += summary.profitOut;
            grandTotalProfitInSold += summary.profitInSold;
            return `
                <tr>
                    <td class="px-3 py-1" style="border: 1px solid #ccc;">${isYearView ? (summary as MonthlySummary).month : (summary as DailySummary).date}</td>
                    <td class="px-3 py-1" style="border: 1px solid #ccc;">${summary.totalIn.toLocaleString()}</td>
                    <td class="px-3 py-1" style="border: 1px solid #ccc;">${summary.totalOut.toLocaleString()}</td>
                    <td class="px-3 py-1" style="border: 1px solid #ccc;">${summary.profitOut.toLocaleString()}</td>
                    <td class="px-3 py-1" style="border: 1px solid #ccc;">${summary.profitInSold.toLocaleString()}</td>
                </tr>
            `
        }).join('');
        
        return `
            <table class="waffle min-w-full" cellspacing="0" cellpadding="0" style="border-collapse: collapse; table-layout: auto; width: 100%;">
              <thead>
                <tr>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc;">${isYearView ? 'MONTH' : 'DATE'}</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc;">SETTLED IN</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc;">SETTLED OUT</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc;">T.OUT PROFIT</th>
                  <th class="px-3 py-1 bg-gray-100 font-semibold" style="border: 1px solid #ccc;">T.IN(SOLD) PROFIT</th>
                </tr>
              </thead>
              <tbody>${tableRows}</tbody>
              <tfoot>
                <tr>
                    <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">Total</th>
                    <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${grandTotalIn.toLocaleString()}</th>
                    <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${grandTotalOut.toLocaleString()}</th>
                    <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${grandTotalProfitOut.toLocaleString()}</th>
                    <th class="px-3 py-2 bg-gray-200 font-bold" style="border: 1px solid #ccc;">${grandTotalProfitInSold.toLocaleString()}</th>
                </tr>
              </tfoot>
            </table>
        `;
    }
  }, [history, filterMode, targetDate, myShopName]);

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-20 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-6 w-6 text-gray-700" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900 truncate">
              Transfer Summary Report
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col overflow-auto">
        <UnifiedSheetUI initialHtml={transfersHtml} />
      </main>
    </div>
  );
}

export default function TransferSummaryReportPage() {
    return (
        <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <TransferSummaryReportContent />
        </Suspense>
    )
}
