
'use client';

import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Suspense } from 'react';
import { Loader2 } from 'lucide-react';

import LifetimeHistoryPage from '../lifetime-history/page';
import MainHistoryPage from '../main-history/page';
import ReverseTransfersPage from '../reverse-transfers/page';
import TransferRecordsPage from '../transfer-records/page';
import WhereIsMyProductPage from '../where-is-my-product/page';
import BasicStockPage from '@/app/basic-stock/page';
import ResetDataPage from '../reset-data/page';
import NotImplementedPage from '../not-implemented/page';
import TransferSummaryPage from '../transfer-summary/page';
import ShopInfoPage from '../shop-info/page';
import InventoryStockPage from '../inventory-stock/page';
import SalesReportPage from '../sales-report/page';
import MainSalesReportPage from '../sales-report/main/page';
import TransferSummaryReportPage from '../transfer-summary/report/page';
import HelpSupportPage from '../help-support/page';
import AppGuidePage from '../help-support/app-guide/page';
import BackupRestorePage from '../backup-restore/page';
import UserAgreementConfirmationPage from '@/app/user-agreement/page';
import TermsPage from '@/app/terms/page';
import PrivacyPolicyPage from '@/app/privacy/page';
import UserAgreementDetailsPage from '@/app/user-agreement/details/page';
import AcceptableUsePolicyPage from '@/app/acceptable-policy/page';
import DisclaimerPage from '@/app/disclaimer/page';
import TransferDetailsPage from '../transfer-records/transfer-details/page';
import ReversedTransferDetailsPage from '../reverse-transfers/reversed-transfer-details/page';


const featureComponents: { [key: string]: React.ElementType } = {
  'lifetime-history': LifetimeHistoryPage,
  'main-history': MainHistoryPage,
  'reverse-transfers': ReverseTransfersPage,
  'reverse-transfers/reversed-transfer-details': ReversedTransferDetailsPage,
  'transfer-records': TransferRecordsPage,
  'transfer-records/transfer-details': TransferDetailsPage,
  'where-is-my-product': WhereIsMyProductPage,
  'basic-stock': BasicStockPage,
  'reset-data': ResetDataPage,
  'not-implemented': NotImplementedPage,
  'transfer-summary': TransferSummaryPage,
  'shop-info': ShopInfoPage,
  'inventory-stock': InventoryStockPage,
  'sales-report': SalesReportPage,
  'sales-report/main': MainSalesReportPage,
  'transfer-summary/report': TransferSummaryReportPage,
  'help-support': HelpSupportPage,
  'help-support/app-guide': AppGuidePage,
  'backup-restore': BackupRestorePage,
  'user-agreement': UserAgreementConfirmationPage,
  'terms': TermsPage,
  'privacy': PrivacyPolicyPage,
  'user-agreement/details': UserAgreementDetailsPage,
  'acceptable-policy': AcceptableUsePolicyPage,
  'disclaimer': DisclaimerPage,
};

const featureTitles: { [key: string]: string } = {
    'lifetime-history': 'Lifetime History',
    'main-history': 'Main History',
    'reverse-transfers': 'Reverse Transfers',
    'reverse-transfers/reversed-transfer-details': 'Reversed Transfer Details',
    'transfer-records': 'Transfer Records',
    'transfer-records/transfer-details': 'Transfer Details',
    'where-is-my-product': 'Where Is My Product',
    'basic-stock': 'Basic Stock',
    'shop-info': 'Shop Information',
    'help-support': 'Help & Support',
    'help-support/app-guide': 'App Guide',
    'not-implemented': 'Feature Under Development',
    'reset-data': 'Reset All Data',
    'transfer-summary': 'Transfer Summary',
    'inventory-stock': 'Inventory Stock',
    'sales-report': 'Sales Report',
    'sales-report/main': 'Sales Report',
    'transfer-summary/report': 'Transfer Summary Report',
    'backup-restore': 'Backup & Restore',
    'user-agreement': 'My Agreements',
    'terms': 'Terms and Conditions',
    'privacy': 'Privacy Policy',
    'user-agreement/details': 'User Agreement',
    'acceptable-policy': 'Acceptable Use Policy',
    'disclaimer': 'Disclaimer',
}

// These features have their own full-page layout and should not be wrapped.
const fullScreenFeatures = new Set([
  'basic-stock',
  'reset-data',
  'sales-report',
  'sales-report/main',
  'transfer-summary/report',
  'help-support/app-guide',
  'help-support',
  'backup-restore',
  'user-agreement',
  'terms',
  'privacy',
  'user-agreement/details',
  'acceptable-policy',
  'disclaimer',
  'transfer-records/transfer-details',
  'reverse-transfers/reversed-transfer-details',
  'reverse-transfers',
  'main-history',
  'transfer-summary',
  'transfer-records',
  'lifetime-history',
  'inventory-stock',
  'where-is-my-product',
]);

export default function FeaturePageClient({ pageProps }: { pageProps?: any }) {
  const router = useRouter();
  const params = useParams();
  let slug = params.slug as string | string[];

  // Handle array slugs from catch-all routes
  if (Array.isArray(slug)) {
    slug = slug.join('/');
  }

  // Prevent rendering detail pages during build time as they need props
  if ((slug === 'transfer-records/transfer-details' || slug === 'reverse-transfers/reversed-transfer-details') && typeof window === 'undefined') {
    return null;
  }

  const FeatureComponent = featureComponents[slug];
  const title = featureTitles[slug] || 'Feature';
  
  const handleBackNavigation = () => {
    router.back();
  };


  if (!FeatureComponent) {
    return (
      <div className="flex flex-col min-h-screen items-center justify-center">
        <h1 className="text-2xl font-bold">404 - Page Not Found</h1>
        <p>The feature you are looking for does not exist.</p>
        <button onClick={() => router.push('/dashboard')} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md">Go to Dashboard</button>
      </div>
    )
  }

  // If the feature is a full-screen feature, render it directly.
  if (fullScreenFeatures.has(slug)) {
    return <FeatureComponent {...pageProps} />;
  }
  
  // Otherwise, render it within the standard page layout with a header.
  return (
    <div className="flex flex-col h-screen bg-background font-sans slide-in-from-right">
      <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={handleBackNavigation}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              {title}
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <div className="flex-1 overflow-y-auto">
        <Suspense fallback={<div className="flex h-full w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <FeatureComponent onBack={handleBackNavigation} {...pageProps} />
        </Suspense>
      </div>
    </div>
  );
}
