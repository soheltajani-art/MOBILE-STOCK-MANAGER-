
import { Suspense } from 'react';
import { Loader2 } from 'lucide-react';
import FeaturePageClient from './feature-page-client';
import * as fs from 'fs';
import * as path from 'path';

const featureComponents: { [key: string]: () => Promise<any> } = {
  'lifetime-history': () => import('../lifetime-history/page'),
  'main-history': () => import('../main-history/page'),
  'reverse-transfers': () => import('../reverse-transfers/page'),
  'reverse-transfers/reversed-transfer-details': () => import('../reverse-transfers/reversed-transfer-details/page'),
  'transfer-records': () => import('../transfer-records/page'),
  'transfer-records/transfer-details': () => import('../transfer-records/transfer-details/page'),
  'where-is-my-product': () => import('../where-is-my-product/page'),
  'basic-stock': () => import('@/app/basic-stock/page'),
  'reset-data': () => import('../reset-data/page'),
  'not-implemented': () => import('../not-implemented/page'),
  'transfer-summary': () => import('../transfer-summary/page'),
  'shop-info': () => import('../shop-info/page'),
  'inventory-stock': () => import('../inventory-stock/page'),
  'sales-report': () => import('../sales-report/page'),
  'sales-report/main': () => import('../sales-report/main/page'),
  'transfer-summary/report': () => import('../transfer-summary/report/page'),
  'help-support': () => import('../help-support/page'),
  'help-support/app-guide': () => import('../help-support/app-guide/page'),
  'backup-restore': () => import('../backup-restore/page'),
  'user-agreement': () => import('@/app/user-agreement/page'),
  'terms': () => import('@/app/terms/page'),
  'privacy': () => import('@/app/privacy/page'),
  'user-agreement/details': () => import('@/app/user-agreement/details/page'),
  'acceptable-policy': () => import('@/app/acceptable-policy/page'),
  'disclaimer': () => import('@/app/disclaimer/page'),
};

export async function generateStaticParams() {
  const slugs = Object.keys(featureComponents);
  return slugs.map(slug => ({
    slug: slug.split('/'),
  }));
}

export default async function FeaturePage({ params }: { params: { slug: string[] }}) {
  let props = {};
  
  return (
    <Suspense fallback={<div className="flex h-screen w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
      <FeaturePageClient pageProps={props} />
    </Suspense>
  );
}
