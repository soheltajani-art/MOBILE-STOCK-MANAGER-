
'use client';

import { Suspense, useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import {
  Search,
  Package,
  Loader2,
  Building,
  ArrowLeft,
} from 'lucide-react';

import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';
import { Skeleton } from '@/components/ui/skeleton';
import { ProductCard } from './product-card';
import ProductDetailsPage from './product-details/page';
import { type ReversedTransferItem } from '../reverse-transfers/page';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export type Product = {
  id: string;
  id2?: string;
  brand: string;
  name: string;
  stock: number;
  ram: string;
  storage: string;
  color: string;
  purchasePrice: number;
  mop?: number;
};

export type ProductStatus = 'In Stock' | 'Sold Out' | 'Pending In' | 'Pending Out';
export type ProductStatusInfo = {
  status: ProductStatus;
  transferShop?: string;
};

type GroupedProducts = {
  [brand: string]: Product[];
};

function WhereIsMyProductComponent({ onBack }: { onBack: () => void }) {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [products] = useLocalStorage<Product[]>('products', []);
  const [basicProducts] = useLocalStorage<Product[]>('basic-products', []);
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [isMounted, setIsMounted] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const router = useRouter();


  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  const getProductStatus = (product: Product): ProductStatusInfo => {
    if (product.stock === 0) {
      return { status: 'Sold Out' };
    }

    const findShopName = (details: string): string | undefined => {
      const match = details.match(/(?:From|To):\s*([^-\s]+)/);
      return match ? match[1] : undefined;
    };
    
    const pendingTransferOut = history.find(item => 
      item.type === 'Transfer Out' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferOut) {
      return {
        status: 'Pending Out',
        transferShop: findShopName(pendingTransferOut.details),
      };
    }

    const pendingTransferIn = history.find(item => 
      item.type === 'Transfer In' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferIn) {
      return {
        status: 'Pending In',
        transferShop: findShopName(pendingTransferIn.details),
      };
    }

    return { status: 'In Stock' };
  };

  const allProductsSource = useMemo(() => {
    if (!isMounted) return [];
    
    return [
      ...products,
      ...basicProducts.map(p => ({ ...p, brand: 'Basic Stock' }))
    ];

  }, [products, basicProducts, isMounted]);

  const { filteredProducts, groupedProducts, totalProducts } = useMemo(() => {
    let productList = allProductsSource;
    if (searchTerm) {
      const lowercasedSearchTerm = searchTerm.toLowerCase();
      productList = productList.filter(
        (product) =>
          (product.brand && product.brand.toLowerCase().includes(lowercasedSearchTerm)) ||
          product.name.toLowerCase().includes(lowercasedSearchTerm) ||
          product.id.toLowerCase().includes(lowercasedSearchTerm) ||
          (product.id2 && product.id2.toLowerCase().includes(lowercasedSearchTerm))
      );
      return { filteredProducts: productList, groupedProducts: null, totalProducts: productList.length };
    }

    const groups: GroupedProducts = {};
    productList.forEach(product => {
      const brand = product.brand || 'Unbranded';
      if (!groups[brand]) {
        groups[brand] = [];
      }
      groups[brand].push(product);
    });

    for (const brand in groups) {
      groups[brand].sort((a, b) => a.name.localeCompare(b.name));
    }

    return { filteredProducts: [], groupedProducts: groups, totalProducts: productList.length };
  }, [searchTerm, allProductsSource]);


  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };

  if (selectedProduct) {
      return (
          <ProductDetailsPage
              product={selectedProduct}
              onBack={() => setSelectedProduct(null)}
          />
      )
  }

  const sortedBrands = groupedProducts ? Object.keys(groupedProducts).sort() : [];


  return (
    <div className="flex flex-col flex-1 bg-background font-sans slide-in-from-right overflow-hidden">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
              <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Where Is My Product
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col p-4 md:p-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search all products by Brand, Name or ID..."
            className="pl-10 bg-card rounded-xl shadow-sm h-12"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <ScrollArea className="flex-1 -mr-4 pr-4">
          {!isMounted ? (
            <div className="space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : totalProducts === 0 ? (
            <div className="text-center text-muted-foreground py-16">
              <Package className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-medium text-foreground">
                No Products Found
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                You haven't added any products yet.
              </p>
            </div>
          ) : searchTerm ? (
            // Flat list for search results
            <div className="bg-card shadow-lg rounded-2xl p-2 md:p-4">
                <div className="space-y-0">
                  {filteredProducts.map((product) => (
                      <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer">
                          <ProductCard product={product} statusInfo={getProductStatus(product)} />
                      </div>
                  ))}
              </div>
            </div>
          ) : (
            // Grouped list for default view
            <div className="space-y-6">
              {sortedBrands.map(brand => (
                <Card key={brand} className="bg-card shadow-lg rounded-2xl">
                    <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4">
                        <Building className="h-5 w-5 text-muted-foreground" />
                        <CardTitle className="text-lg">{brand}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-2 pt-0">
                       {groupedProducts && groupedProducts[brand].map((product) => (
                          <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer">
                              <ProductCard product={product} statusInfo={getProductStatus(product)} />
                          </div>
                       ))}
                    </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </main>
    </div>
  );
}

export default function WhereIsMyProductPage({ onBack }: { onBack: () => void }) {
    return (
        <Suspense fallback={<div className="flex-1 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin"/></div>}>
            <WhereIsMyProductComponent onBack={onBack} />
        </Suspense>
    );
}
