'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, ChevronRight, CheckCircle2, XCircle, ArrowUp, ArrowDown, Cpu, Smartphone, Paintbrush } from 'lucide-react';
import { type Product, type ProductStatusInfo } from './page';

interface ProductCardProps {
    product: Product;
    statusInfo: ProductStatusInfo;
}

export const ProductCard = ({ product, statusInfo }: ProductCardProps) => {
  const getStatusBadge = () => {
    const { status, transferShop } = statusInfo;
    switch (status) {
      case 'Sold Out':
        return (
          <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200 text-xs whitespace-nowrap">
            <XCircle className="h-3 w-3 mr-1" />
            Sold Out
          </Badge>
        );
      case 'Pending Out':
        return (
          <Badge className="bg-purple-100 text-purple-800 border-purple-200 text-xs whitespace-nowrap">
            <ArrowUp className="h-3 w-3 mr-1" />
            Pending Out {transferShop && `to ${transferShop}`}
          </Badge>
        );
      case 'Pending In':
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs whitespace-nowrap">
            <ArrowDown className="h-3 w-3 mr-1" />
            Pending In {transferShop && `from ${transferShop}`}
          </Badge>
        );
      case 'In Stock':
      default:
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            In Stock
          </Badge>
        );
    }
  };

  return (
    <Card className="bg-card shadow-sm rounded-xl">
        <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center space-x-4 flex-1 min-w-0">
              <div className="p-3 rounded-xl bg-muted">
                  <Package className="h-6 w-6 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-left truncate">
                    {product.name}
                  </p>
                  <p className="text-sm text-muted-foreground text-left font-mono truncate">
                    {product.id}
                  </p>
                  <div className="text-xs text-muted-foreground text-left mt-1 flex items-center gap-2 flex-wrap">
                    {product.ram && <span className="flex items-center gap-1"><Cpu className="h-3 w-3"/>{product.ram}</span>}
                    {product.storage && <span className="flex items-center gap-1"><Smartphone className="h-3 w-3"/>{product.storage}</span>}
                    {product.color && <span className="flex items-center gap-1"><Paintbrush className="h-3 w-3"/>{product.color}</span>}
                  </div>
              </div>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 ml-2">
                <div className="hidden sm:block">
                  {getStatusBadge()}
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            </div>
        </CardContent>
    </Card>
  );
};
