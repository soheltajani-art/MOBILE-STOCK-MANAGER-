'use client';

import {
  Package,
  Cpu,
  Smartphone,
  Paintbrush,
  IndianRupee,
  Fingerprint,
  Copy,
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../../transfer-records/page';
import { HistoryItemCard } from '../../history-item-card';
import { type Product } from '../page';
import { type ReversedTransferItem } from '../../reverse-transfers/page';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

interface ProductDetailsPageProps {
  product: Product;
  onBack: () => void;
}

const DetailRow = ({
  icon: Icon,
  label,
  value,
  canCopy = false,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  canCopy?: boolean;
}) => {
  const handleCopy = () => {
    navigator.clipboard.writeText(String(value));
    toast.success('Copied to clipboard!', { description: String(value) });
  };

  return (
    <div className="flex items-center text-sm text-gray-700">
      <Icon className="h-4 w-4 mr-3 text-gray-500" />
      <span className="font-semibold w-28">{label}:</span>
      <span className="flex-1 text-right font-medium">{value}</span>
      {canCopy && (
        <Button variant="ghost" size="icon" className="h-6 w-6 ml-2" onClick={handleCopy}>
          <Copy className="h-4 w-4 text-gray-500" />
        </Button>
      )}
    </div>
  );
};


export default function ProductDetailsPage({
  product,
  onBack,
}: ProductDetailsPageProps) {
  const [allHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [basicHistory] = useLocalStorage<HistoryItem[]>('basic-history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>(
    'reversedTransfers',
    []
  );

  if (!product) {
    return null;
  }
  
  const historySource = product.brand === 'Basic Stock' ? basicHistory : allHistory;

  const getProductHistory = (product: Product): HistoryItem[] => {
    let relatedEvents = historySource.filter((event) => {
      if (event.type === 'Settlement') return false;
      const details = event.details?.toLowerCase() || '';

      const id1Match = details.match(/id1?:\s*([^\s,]+)/);
      const id2Match = details.match(/id2:\s*([^\s,]+)/);

      const eventId1 = id1Match ? id1Match[1] : null;
      const eventId2 = id2Match ? id2Match[1] : null;

      let isMatch = false;
      if (eventId1 && eventId1 === product.id.toLowerCase()) {
        isMatch = true;
      }
      if (eventId2 && eventId2 === product.id.toLowerCase()) {
        isMatch = true;
      }
      if (product.id2) {
        if (eventId1 && eventId1 === product.id2.toLowerCase()) {
          isMatch = true;
        }
        if (eventId2 && eventId2 === product.id2.toLowerCase()) {
          isMatch = true;
        }
      }
      
      return isMatch;
    });

    relatedEvents = relatedEvents.map((event) => {
      const reversal = reversedTransfers.find(
        (rt) => rt.originalTransferId === event.id
      );
      if (reversal && (event.type === 'Transfer In' || event.type === 'Transfer Out')) {
        return { ...event, isReversed: true, reversalReason: reversal.reason };
      }
      
      if ((event.type === 'Transfer In' || event.type === 'Transfer Out') && !event.isReversed) {
        const settlement = historySource.find(
          (h) => h.type === 'Settlement' && h.originalTransferId === event.id
        );
        if (settlement) {
          return { ...event, status: 'Settled', settledDate: settlement.date };
        }
      }
      return event;
    }).filter(item => !(item.isReversed && (item.type !== 'Transfer In' && item.type !== 'Transfer Out')));


    const saleEvent = relatedEvents.find((e) => e.type === 'Sale');
  
    if (saleEvent) {
      const purchaseEvent = relatedEvents.find((e) => e.type === 'Purchase');
      const transferInEvent = relatedEvents.find((e) => e.type === 'Transfer In');
      
      const costEvent = purchaseEvent || transferInEvent;
      
      if (costEvent) {
        const mergedItem: HistoryItem = {
          id: saleEvent.id,
          type: costEvent.type === 'Purchase' ? 'Purchase & Sale' : 'Transfer In & Sale',
          productName: product.name,
          date: saleEvent.date,
          quantity: saleEvent.quantity,
          totalAmount: saleEvent.totalAmount,
          purchasePrice: costEvent.type === 'Purchase' ? costEvent.purchasePrice : costEvent.totalAmount,
          salePrice: saleEvent.salePrice,
          details: '',
          purchaseDetails: costEvent.details,
          saleDetails: saleEvent.details,
        };
  
        return [
          mergedItem,
          ...relatedEvents.filter(
            (e) => e.id !== costEvent.id && e.id !== saleEvent.id
          ),
        ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
    }

    return relatedEvents
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const productHistory = getProductHistory(product);
  const isSold = product.stock === 0;

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right">
       <header className="bg-white shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-6 w-6 text-gray-700" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900">
              Product Details
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <ScrollArea className="flex-1">
        <main className="p-4 space-y-6">
          <Card className="bg-white shadow-md rounded-2xl overflow-hidden">
              <CardContent className="p-4">
              <div className="flex items-center space-x-4 mb-4">
                  <div className="p-3 rounded-xl bg-gray-100">
                  <Package className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                  <p className="font-semibold text-gray-900 text-left text-lg">
                      {product.name}
                  </p>
                  <p className="text-sm text-gray-500 text-left">
                      {product.id}
                  </p>
                  </div>
              </div>

              <Card className="bg-gray-50/80">
                  <CardContent className="p-4 space-y-2">
                  <div className="flex justify-between items-center mb-3">
                      <h4 className="font-semibold text-gray-800">
                      Product Details
                      </h4>
                      <Badge
                      className={
                          isSold
                          ? 'bg-red-100 text-red-800 border-red-200'
                          : 'bg-green-100 text-green-800 border-green-200'
                      }
                      >
                      {isSold ? 'Sold Out' : `In Stock: ${product.stock}`}
                      </Badge>
                  </div>
                  <DetailRow icon={Cpu} label="RAM" value={product.ram} />
                  <DetailRow icon={Smartphone} label="Storage" value={product.storage} />
                  <DetailRow icon={Paintbrush} label="Color" value={product.color} />
                  <DetailRow icon={Fingerprint} label="ID 1" value={product.id} canCopy />
                  {product.id2 && <DetailRow icon={Fingerprint} label="ID 2" value={product.id2} canCopy />}
                  <DetailRow icon={IndianRupee} label="Purchase Price" value={product.purchasePrice.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })} />
                   {product.mop && <DetailRow icon={IndianRupee} label="MOP" value={product.mop.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })} />}
                  </CardContent>
              </Card>
              
              {productHistory.length > 0 && (
                  <div>
                  <h4 className="font-semibold text-gray-800 my-4">Product History</h4>
                  <div className="space-y-0">
                      {productHistory.map((item) => (
                      <HistoryItemCard key={item.id} item={item} />
                      ))}
                  </div>
                  </div>
              )}

              {productHistory.length === 0 && (
                  <div className="text-center text-gray-500 py-10">
                  <Package className="mx-auto h-10 w-10 text-gray-400" />
                  <h3 className="mt-2 text-md font-medium text-gray-900">No History</h3>
                  <p className="mt-1 text-sm text-gray-500">No history found for this product.</p>
                  </div>
              )}
              </CardContent>
          </Card>
        </main>
      </ScrollArea>
    </div>
  );
}
