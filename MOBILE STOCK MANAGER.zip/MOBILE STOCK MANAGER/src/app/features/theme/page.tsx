
'use client';

import { ArrowLeft, CheckCircle, Sun, Moon, Monitor, Palette, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useRouter } from 'next/navigation';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

type ThemeOption = {
  name: string;
  label: string;
  icon: React.ElementType;
};

const themes: ThemeOption[] = [
  { name: 'light', label: 'Daylight', icon: Sun },
  { name: 'dark', label: 'Midnight', icon: Moon },
  { name: 'system', label: 'Automatic', icon: Monitor },
  { name: 'dynamic', label: 'Dynamic', icon: Sparkles },
];

export default function ThemePage() {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleThemeClick = (newTheme: string) => {
    if (newTheme === 'dynamic') {
      // For now, this is just a placeholder
    } else {
      setTheme(newTheme);
    }
  };

  if (!mounted) {
    return (
      <div className="flex flex-col h-screen bg-background font-sans">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Skeleton className="h-10 w-10 rounded-full" />
              <Skeleton className="h-6 w-32" />
              <div className="w-10"></div>
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 flex items-center justify-center">
            <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                    <Skeleton className="h-8 w-48 mx-auto" />
                    <Skeleton className="h-4 w-64 mx-auto mt-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                </CardContent>
            </Card>
        </main>
    </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-background">
        <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => router.back()}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
              </Button>
              <h1 className="text-xl font-bold text-foreground">
                Appearance
              </h1>
              <div className="w-10"></div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 flex items-center justify-center">
            <Card className="w-full max-w-md shadow-lg rounded-2xl">
                <CardHeader className="text-center">
                    <CardTitle>Select a Theme</CardTitle>
                    <CardDescription>
                        Choose your preferred application theme.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {themes.map((t) => (
                    <Button
                      key={t.name}
                      variant={theme === t.name ? 'default' : 'outline'}
                      className="w-full justify-between h-14 text-md"
                      onClick={() => handleThemeClick(t.name)}
                      disabled={t.name === 'dynamic'}
                    >
                      <div className="flex items-center gap-3">
                        <t.icon className="h-5 w-5" />
                        <span>{t.label}</span>
                      </div>
                      {theme === t.name && <CheckCircle className="h-5 w-5" />}
                    </Button>
                  ))}
                </CardContent>
            </Card>
        </main>
    </div>
  );
}
