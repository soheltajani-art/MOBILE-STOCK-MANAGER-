
'use client';

import { Suspense, useState, useMemo, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Search,
  Package,
  Loader2,
  ArrowDown,
  ArrowUp,
  ShoppingCart,
  Building,
  RefreshCw,
  ArrowLeft,
  XCircle,
  CheckCircle2,
  Hourglass,
  ChevronRight,
  Eye,
} from 'lucide-react';

import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';
import { Skeleton } from '@/components/ui/skeleton';
import { ProductCard } from '../where-is-my-product/product-card';
import ProductDetailsPage from '../where-is-my-product/product-details/page';
import { type ReversedTransferItem } from '../reverse-transfers/page';
import { ScrollArea } from '@/components/ui/scroll-area';
import { type Product, type ProductStatusInfo } from '../where-is-my-product/page';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';


type GroupedProducts = {
  [brand: string]: Product[];
};

type StockCategory = 'total' | 'transferIn' | 'transferOutPending' | 'reversed';
type TransferStatusFilter = 'all' | 'settled' | 'pending';

type ShopGroup = {
  [shopName: string]: Product[];
};

function InventoryStockComponent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialFilter = (searchParams.get('filter') as StockCategory) || 'total';
  const initialQuery = searchParams.get('q') || '';
  
  const [products] = useLocalStorage<Product[]>('products', []);
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [isMounted, setIsMounted] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState<StockCategory>(initialFilter);
  const [selectedShop, setSelectedShop] = useState<string | null>(null);
  const [transferInStatusFilter, setTransferInStatusFilter] = useState<TransferStatusFilter>('all');

  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  const getProductStatus = (product: Product): ProductStatusInfo => {
    if (product.stock === 0) {
      return { status: 'Sold Out' };
    }

    const findShopName = (details: string): string | undefined => {
      const match = details.match(/(?:From|To):\s*([^-\s]+)/);
      return match ? match[1] : undefined;
    };
    
    const pendingTransferOut = history.find(item => 
      item.type === 'Transfer Out' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferOut) {
      return {
        status: 'Pending Out',
        transferShop: findShopName(pendingTransferOut.details),
      };
    }

    const pendingTransferIn = history.find(item => 
      item.type === 'Transfer In' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferIn) {
      return {
        status: 'Pending In',
        transferShop: findShopName(pendingTransferIn.details),
      };
    }

    return { status: 'In Stock' };
  };

 const { stockSummary, categorizedProducts } = useMemo(() => {
    if (!isMounted) return { stockSummary: { total: 0, transferIn: 0, transferOutPending: 0, reversed: 0 }, categorizedProducts: {} };
    
    const summary = {
        total: products.filter(p => p.stock > 0).length,
        transferIn: 0,
        transferOutPending: 0,
        reversed: reversedTransfers.length,
    };

    const categorized: {[key in Exclude<StockCategory, 'total'>]: {
        all: ShopGroup,
        settled: ShopGroup,
        pending: ShopGroup,
    }} = {
        transferIn: { all: {}, settled: {}, pending: {} },
        transferOutPending: { all: {}, settled: {}, pending: {} }, // 'all' for consistency
        reversed: { all: {}, settled: {}, pending: {} }
    };

    const productMap = new Map(products.map(p => [p.id, p]));

    history.forEach(item => {
        const id1Match = item.details.match(/ID1:\s*([^\s,]+)/i);
        if (!id1Match) return;
        
        const product = productMap.get(id1Match[1]);
        if (!product || product.stock <= 0) return;

        const fromShopMatch = item.details.match(/From\s*([^-,\s]+)/);
        const toShopMatch = item.details.match(/To\s*([^-,\s]+)/);

        if (item.type === 'Transfer In') {
            const shopName = fromShopMatch ? fromShopMatch[1].trim() : 'Unknown';
            if (!categorized.transferIn.all[shopName]) categorized.transferIn.all[shopName] = [];
            categorized.transferIn.all[shopName].push(product);
            
            if (item.status === 'Settled') {
                if (!categorized.transferIn.settled[shopName]) categorized.transferIn.settled[shopName] = [];
                categorized.transferIn.settled[shopName].push(product);
            } else if (item.status === 'Pending') {
                if (!categorized.transferIn.pending[shopName]) categorized.transferIn.pending[shopName] = [];
                categorized.transferIn.pending[shopName].push(product);
            }
        } else if (item.type === 'Transfer Out' && item.status === 'Pending') {
            const shopName = toShopMatch ? toShopMatch[1].trim() : 'Unknown';
            if (!categorized.transferOutPending.all[shopName]) categorized.transferOutPending.all[shopName] = [];
            categorized.transferOutPending.all[shopName].push(product);
        }
    });

    reversedTransfers.forEach(item => {
        const id1Match = item.details.match(/ID1:\s*([^\s,]+)/i);
        if (!id1Match) return;
        const product = productMap.get(id1Match[1]);
        if (!product) return;

        const fromShopMatch = item.details.match(/From\s*([^-,\s]+)/);
        const toShopMatch = item.details.match(/To\s*([^-,\s]+)/);
        const shopName = fromShopMatch ? fromShopMatch[1].trim() : (toMatch ? toMatch[1].trim() : 'Unknown');

        if (!categorized.reversed.all[shopName]) categorized.reversed.all[shopName] = [];
        categorized.reversed.all[shopName].push(product);
    });
    
    summary.transferIn = Object.values(categorized.transferIn.all).flat().length;
    summary.transferOutPending = Object.values(categorized.transferOutPending.all).flat().length;
    summary.reversed = Object.values(categorized.reversed.all).flat().length;

    return { stockSummary: summary, categorizedProducts: categorized };
  }, [products, history, reversedTransfers, isMounted]);


  const { displayData, totalProducts, viewTitle } = useMemo(() => {
    if (!isMounted) return { displayData: {}, totalProducts: 0, viewTitle: 'Total Stock' };

    let currentShopGroups: ShopGroup = {};
    let title = "Category";

    if (activeCategory === 'transferIn') {
        currentShopGroups = categorizedProducts.transferIn[transferInStatusFilter];
        title = "Transfer In";
    } else if (activeCategory !== 'total') {
        currentShopGroups = categorizedProducts[activeCategory as Exclude<StockCategory, 'total'>].all;
        if (activeCategory === 'transferOutPending') title = 'Transfer Out (Pending)';
        if (activeCategory === 'reversed') title = 'Reversed Transfers';
    }

    if (selectedShop) {
      const productList = currentShopGroups[selectedShop] || [];
      const groups: GroupedProducts = {};
      productList.forEach(product => {
        const brand = product.brand || 'Unbranded';
        if (!groups[brand]) groups[brand] = [];
        groups[brand].push(product);
      });
      return { displayData: groups, totalProducts: productList.length, viewTitle: `${selectedShop}` };
    }
    
    if (activeCategory !== 'total') {
      const total = Object.values(currentShopGroups).flat().length;
      return { displayData: currentShopGroups, totalProducts: total, viewTitle: title };
    }

    // Default 'total' view
    let filtered = products.filter(p => p.stock > 0);
    if (searchTerm) {
        const lowercasedSearchTerm = searchTerm.toLowerCase();
        filtered = filtered.filter(
            (product) =>
                (product.brand && product.brand.toLowerCase().includes(lowercasedSearchTerm)) ||
                product.name.toLowerCase().includes(lowercasedSearchTerm) ||
                product.id.toLowerCase().includes(lowercasedSearchTerm) ||
                (product.id2 && product.id2.toLowerCase().includes(lowercasedSearchTerm))
        );
    }
    
    const groups: GroupedProducts = {};
    filtered.forEach(product => {
        const brand = product.brand || 'Unbranded';
        if (!groups[brand]) groups[brand] = [];
        groups[brand].push(product);
    });
    for (const brand in groups) {
      groups[brand].sort((a, b) => a.name.localeCompare(b.name));
    }
    
    return { displayData: groups, totalProducts: filtered.length, viewTitle: 'Total Stock' };
  }, [products, isMounted, searchTerm, activeCategory, selectedShop, categorizedProducts, transferInStatusFilter]);


  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };
  
  const handleCategoryClick = (category: StockCategory) => {
    setActiveCategory(category);
    setSelectedShop(null);
    setSearchTerm('');
  };
  
  const handleShopClick = (shopName: string) => {
    setSelectedShop(shopName);
  }

  const handleBack = () => {
    if (selectedShop) {
      setSelectedShop(null);
    } else if (activeCategory !== 'total') {
      handleCategoryClick('total');
    } else {
      router.push('/dashboard');
    }
  }

  if (selectedProduct) {
      return (
          <ProductDetailsPage
              product={selectedProduct}
              onBack={() => setSelectedProduct(null)}
          />
      )
  }

  const sortedGroupNames = Object.keys(displayData).sort();

  return (
    <div className="flex flex-col h-full bg-background font-sans">
      <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={handleBack}>
              <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Inventory Stock
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 flex flex-col p-4 md:p-6 space-y-4 overflow-hidden">
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <SummaryCard title="Total In-Stock" count={stockSummary.total} icon={Package} onClick={() => handleCategoryClick('total')} isActive={activeCategory === 'total'} />
            <SummaryCard title="Transfer In" count={stockSummary.transferIn} icon={ArrowDown} onClick={() => handleCategoryClick('transferIn')} isActive={activeCategory === 'transferIn'} />
            <SummaryCard title="T-Out Pending" count={stockSummary.transferOutPending} icon={ArrowUp} onClick={() => handleCategoryClick('transferOutPending')} isActive={activeCategory === 'transferOutPending'} />
            <SummaryCard title="Reversed" count={stockSummary.reversed} icon={RefreshCw} onClick={() => handleCategoryClick('reversed')} isActive={activeCategory === 'reversed'} />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between h-8">
            <div className='w-16'></div>
            <h2 className="text-lg font-bold text-foreground text-center truncate px-2">{viewTitle}</h2>
            <div className='w-16'></div>
          </div>

          {activeCategory === 'total' && !selectedShop && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search products by Brand, Name or ID..."
                className="pl-10 bg-card rounded-xl shadow-sm h-12"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          )}
          
          {activeCategory === 'transferIn' && !selectedShop && (
              <Select value={transferInStatusFilter} onValueChange={(value: TransferStatusFilter) => setTransferInStatusFilter(value)}>
                  <SelectTrigger className="w-full h-12 rounded-xl shadow-sm bg-card">
                      <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="settled">Settled</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
              </Select>
          )}

          <ScrollArea className="flex-1 -mr-4 pr-4">
            {!isMounted ? (
              <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : totalProducts > 0 ? (
              <div className="space-y-6">
                {sortedGroupNames.map(groupName => (
                  <div key={groupName}>
                      {(activeCategory === 'total' || selectedShop) ? (
                        <Card className="bg-card shadow-lg rounded-2xl">
                          <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4">
                              <Building className="h-5 w-5 text-muted-foreground" />
                              <CardTitle className="text-lg">{groupName}</CardTitle>
                          </CardHeader>
                          <CardContent className="p-2 pt-0">
                            {(displayData[groupName] as Product[]).map((product) => (
                                <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer m-2">
                                    <ProductCard product={product} statusInfo={getProductStatus(product)} />
                                </div>
                            ))}
                          </CardContent>
                        </Card>
                      ) : (
                        <Card
                          className="bg-card shadow-md rounded-2xl cursor-pointer hover:bg-accent transition-colors"
                          onClick={() => handleShopClick(groupName)}
                        >
                          <CardContent className="p-4 flex items-center justify-between">
                              <div className="flex items-center space-x-4 min-w-0">
                                  <div className="p-3 rounded-xl bg-muted">
                                      <Building className="h-6 w-6 text-muted-foreground" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                      <p className="font-semibold text-foreground text-left truncate">
                                          {groupName}
                                      </p>
                                      <p className="text-sm text-muted-foreground text-left">
                                          {(displayData[groupName] as Product[]).length} products
                                      </p>
                                  </div>
                              </div>
                              <Button variant="ghost" size="icon" className="h-auto p-1 text-muted-foreground hover:text-foreground">
                                  <Eye className="h-5 w-5" />
                              </Button>
                          </CardContent>
                        </Card>
                      )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-16">
                <Package className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-2 text-lg font-medium text-foreground">
                  No Products Found
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  No products match the selected criteria.
                </p>
              </div>
            )}
          </ScrollArea>
        </main>
      </div>
    </div>
  );
}

const SummaryCard = ({ title, count, icon: Icon, onClick, isActive }: { title: string, count: number, icon: React.ElementType, onClick: () => void, isActive: boolean }) => {
    return (
        <Card onClick={onClick} className={`cursor-pointer transition-all rounded-2xl ${isActive ? 'bg-primary text-primary-foreground shadow-lg' : 'bg-card hover:bg-muted'}`}>
            <CardContent className="p-3">
                <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${isActive ? 'bg-primary-foreground/20' : 'bg-muted'}`}>
                        <Icon className={`h-5 w-5 ${isActive ? 'text-primary-foreground' : 'text-muted-foreground'}`} />
                    </div>
                    <div>
                        <p className={`text-xs font-medium ${isActive ? 'text-primary-foreground/90' : 'text-muted-foreground'}`}>{title}</p>
                        <p className={`text-xl font-bold ${isActive ? 'text-primary-foreground' : 'text-foreground'}`}>{count}</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

export default function InventoryStockPage() {
    return (
        <Suspense fallback={<div className="flex-1 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin"/></div>}>
            <InventoryStockComponent />
        </Suspense>
    );
}
