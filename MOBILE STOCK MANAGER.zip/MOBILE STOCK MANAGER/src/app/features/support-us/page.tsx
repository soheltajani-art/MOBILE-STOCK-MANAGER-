
'use client';

import { ArrowLeft, Heart, Mail } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';

export default function SupportUsPage() {
    const router = useRouter();
    const supportEmail = "soheltajani@gmail.com";

    const handleEmailClick = () => {
        window.location.href = `mailto:${supportEmail}?subject=Support%20for%20MOBILE%20STOCK%20MANAGER`;
    };

    return (
        <div className="flex flex-col h-screen bg-background font-sans">
            <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <Button variant="ghost" size="icon" onClick={() => router.back()}>
                            <ArrowLeft className="h-6 w-6 text-foreground" />
                        </Button>
                        <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
                            <Heart className="h-5 w-5 text-pink-500" />
                            Support Us
                        </h1>
                        <div className="w-10"></div>
                    </div>
                </div>
            </header>

            <main className="flex-1 flex flex-col items-center justify-center p-4 space-y-6">
                <Card className="w-full max-w-sm shadow-2xl rounded-3xl bg-card text-center">
                    <CardHeader>
                        <div className="mx-auto bg-pink-100 p-4 rounded-full mb-4 inline-block">
                            <Heart className="h-10 w-10 text-pink-500" />
                        </div>
                        <CardTitle className="text-2xl font-bold">Thank You for Your Support!</CardTitle>
                        <CardDescription>
                            If you find this app helpful, your support for its continued development is greatly appreciated.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6 pt-0 flex flex-col items-center gap-4">
                        <p className="text-sm text-muted-foreground">
                           For ways to support the project, please get in touch with the developer.
                        </p>
                        <Button onClick={handleEmailClick} variant="outline" className="w-full">
                            <Mail className="mr-2 h-4 w-4" />
                            Contact for Support
                        </Button>
                    </CardContent>
                </Card>
            </main>
        </div>
    );
}
