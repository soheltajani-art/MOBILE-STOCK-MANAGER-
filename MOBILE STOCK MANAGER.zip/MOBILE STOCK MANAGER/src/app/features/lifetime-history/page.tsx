
'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import {
  Search,
  Loader2,
  Building,
  ArrowLeft,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';
import { type Product, type ProductStatusInfo } from '../where-is-my-product/page';
import { Skeleton } from '@/components/ui/skeleton';
import { type ReversedTransferItem } from '../reverse-transfers/page';
import ProductDetailsPage from '../where-is-my-product/product-details/page';
import { ProductCard } from '../where-is-my-product/product-card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

interface LifetimeHistoryPageProps {
  onBack: () => void;
}

type GroupedProducts = {
  [brand: string]: Product[];
};

export default function LifetimeHistoryPage({
  onBack,
}: LifetimeHistoryPageProps) {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [products] = useLocalStorage<Product[]>('products', []);
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
   const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>(
    'reversedTransfers',
    []
  );
  const [isMounted, setIsMounted] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const getProductStatus = (product: Product): ProductStatusInfo => {
    if (product.stock === 0) {
      return { status: 'Sold Out' };
    }

    const findShopName = (details: string): string | undefined => {
      const match = details.match(/(?:From|To):\s*([^-\s]+)/);
      return match ? match[1] : undefined;
    };
    
    const pendingTransferOut = history.find(item => 
      item.type === 'Transfer Out' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferOut) {
      return {
        status: 'Pending Out',
        transferShop: findShopName(pendingTransferOut.details),
      };
    }

    const pendingTransferIn = history.find(item => 
      item.type === 'Transfer In' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferIn) {
      return {
        status: 'Pending In',
        transferShop: findShopName(pendingTransferIn.details),
      };
    }

    return { status: 'In Stock' };
  };

  const { groupedProducts, totalProducts } = useMemo(() => {
    if (!isMounted || !products) return { groupedProducts: {}, totalProducts: 0 };

    let productList = products || [];

    if (searchTerm) {
      const lowercasedSearchTerm = searchTerm.toLowerCase();
      productList = productList.filter(
        (product) =>
          (product.brand && product.brand.toLowerCase().includes(lowercasedSearchTerm)) ||
          product.name.toLowerCase().includes(lowercasedSearchTerm) ||
          product.id.toLowerCase().includes(lowercasedSearchTerm) ||
          (product.id2 && product.id2.toLowerCase().includes(lowercasedSearchTerm))
      );
    }
    
    const groups: GroupedProducts = {};

    productList.forEach(product => {
        const brand = product.brand || 'Unbranded';
        if (!groups[brand]) {
            groups[brand] = [];
        }
        groups[brand].push(product);
    });

    // Sort products within each brand group alphabetically
    for (const brand in groups) {
      groups[brand].sort((a, b) => a.name.localeCompare(b.name));
    }
    
    return { groupedProducts: groups, totalProducts: productList.length };
  }, [searchTerm, products, isMounted]);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };

  if (selectedProduct) {
      return (
          <ProductDetailsPage
              product={selectedProduct}
              onBack={() => setSelectedProduct(null)}
          />
      )
  }
  
  const sortedBrands = Object.keys(groupedProducts).sort();

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Lifetime History
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col p-4 md:p-6 space-y-4 overflow-hidden">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="Search by Brand, Name or ID..."
            className="pl-10 bg-white rounded-xl shadow-sm h-12"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <ScrollArea className="flex-1 -mr-4 pr-4">
            {!isMounted ? (
            <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
            </div>
            ) : totalProducts > 0 ? (
            <div className="space-y-6">
               {sortedBrands.map(brand => (
                <Card key={brand} className="bg-white shadow-lg rounded-2xl">
                    <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4">
                        <Building className="h-5 w-5 text-gray-500" />
                        <CardTitle className="text-lg">{brand}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-2 pt-0">
                       {groupedProducts[brand].map((product) => (
                          <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer">
                              <ProductCard product={product} statusInfo={getProductStatus(product)} />
                          </div>
                       ))}
                    </CardContent>
                </Card>
              ))}
            </div>
            ) : (
            <div className="text-center text-gray-500 py-16">
                <Search className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">
                No Products Found
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                No products found matching your search.
                </p>
            </div>
            )}
        </ScrollArea>
      </main>
    </div>
  );
}
