
'use client';

import { useState, useMemo, useEffect } from 'react';
import {
  Search,
  RefreshCw,
  Loader2,
  Building,
  ArrowLeft,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Skeleton } from '@/components/ui/skeleton';
import { ReversedHistoryItemCard } from './reversed-history-item-card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';
import ReversedTransferDetailsPage from './reversed-transfer-details/page';
import { type Product } from '../where-is-my-product/page';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

interface ReverseTransfersPageProps {
  onBack: () => void;
}

export type ReversedTransferItem = {
  id: number;
  originalTransferId: number;
  date: Date;
  productName: string;
  quantity: number;
  details: string;
  reason: string;
};

export default function ReverseTransfersPage({
  onBack,
}: ReverseTransfersPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  const [products] = useLocalStorage<Product[]>('products', []);
  const [isMounted, setIsMounted] = useState(false);
  const [selectedReversal, setSelectedReversal] = useState<ReversedTransferItem | null>(null);
  const router = useRouter();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const groupedReversals = useMemo(() => {
    if (!isMounted) return {};
    
    let history = reversedTransfers;

    if (searchTerm) {
      history = history.filter((item) =>
        item.productName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    const groups: Record<string, ReversedTransferItem[]> = {};

    history.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .forEach(item => {
            const idMatch = item.details.match(/ID1?:\s*([^\s,]+)/i);
            const productId = idMatch ? idMatch[1] : null;
            // Ensure we only find products with a brand property
            const product = products.find(p => p.id === productId && p.brand);
            const brand = product?.brand || 'Unbranded';

            if (!groups[brand]) {
                groups[brand] = [];
            }
            groups[brand].push(item);
        });

    return groups;
  }, [searchTerm, reversedTransfers, isMounted, products]);


  const handleReversalClick = (item: ReversedTransferItem) => {
    setSelectedReversal(item);
  };
  
  if (selectedReversal) {
    return (
        <ReversedTransferDetailsPage
            reversal={selectedReversal}
            onBack={() => setSelectedReversal(null)}
        />
    )
  }

  const brandNames = Object.keys(groupedReversals).sort();

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans slide-in-from-right">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Reverse Transfers
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col p-4 md:p-6 space-y-4 overflow-hidden">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="Search by product name..."
            className="pl-10 bg-white rounded-xl shadow-sm h-12 w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <ScrollArea className="flex-1 -mr-4 pr-4">
          {!isMounted ? (
              <div className="space-y-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
              </div>
          ) : brandNames.length > 0 ? (
            <div className="space-y-6">
              {brandNames.map((brandName) => (
                <Card key={brandName} className="bg-white shadow-lg rounded-2xl">
                    <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4">
                        <Building className="h-5 w-5 text-gray-500" />
                        <CardTitle className="text-lg">{brandName}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-2 pt-0">
                        {groupedReversals[brandName].map((item) => (
                            <div key={item.id} onClick={() => handleReversalClick(item)} className="cursor-pointer">
                                <ReversedHistoryItemCard item={item} />
                            </div>
                        ))}
                    </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 py-16">
              <RefreshCw className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">
                No Reverse Transfers Found
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                There are no reversed transfers to display.
              </p>
            </div>
          )}
        </ScrollArea>
      </main>
    </div>
  );
}
