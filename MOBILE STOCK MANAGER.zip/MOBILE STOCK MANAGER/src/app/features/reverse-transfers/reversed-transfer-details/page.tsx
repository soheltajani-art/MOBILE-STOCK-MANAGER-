'use client';

import {
  ArrowLeft,
  Calendar as CalendarIcon,
  Info,
  RefreshCw,
  Share2,
  Cpu,
  Smartphone,
  Paintbrush,
  Fingerprint,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { type ReversedTransferItem } from '../page';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../../transfer-records/page';
import { type ShopInfo } from '@/app/shop-information/page';
import jsPDF from 'jspdf';
import { toast } from 'sonner';

interface ReversedTransferDetailsPageProps {
  reversal: ReversedTransferItem;
  onBack: () => void;
}

const DetailParser = ({ details }: { details: string }) => {
    if (!details) return null;

    const ramStorageMatch = details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = details.match(/ID:\s*([^\s,]+)/);
    const id2Match = details.match(/ID2:\s*([^\s,]+)/);
    const fromMatch = details.match(/From\s(.*?)\s-/);
    const toMatch = details.match(/To\s(.*?)\s-/);

    const fromTo = fromMatch ? `From: ${fromMatch[1]}` : (toMatch ? `To: ${toMatch[1]}` : '');

    let colorPart = details;
    if(ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
    if(id1Match) colorPart = colorPart.replace(id1Match[0], '');
    if(id2Match) colorPart = colorPart.replace(id2Match[0], '');
    if(fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if(toMatch) colorPart = colorPart.replace(toMatch[0], '');
    colorPart = colorPart.replace(/Reversed:/, '').replace(/- ID:/, '').replace(/ID2:/, '').replace(/,/g, '').trim();

    return (
        <div className="space-y-2 text-right">
            {ramStorageMatch && <div className='flex justify-between'><Cpu className="h-4 w-4 text-gray-400 mr-2" /> <span>{ramStorageMatch[1]} / {ramStorageMatch[2]}</span></div>}
            {colorPart && <div className='flex justify-between'><Paintbrush className="h-4 w-4 text-gray-400 mr-2" /> <span>{colorPart}</span></div>}
            {fromTo && <div className='flex justify-between'><Share2 className="h-4 w-4 text-gray-400 mr-2" /> <span>{fromTo}</span></div>}
            {id1Match && <div className='flex justify-between'><Fingerprint className="h-4 w-4 text-gray-400 mr-2" /> <span>ID1: {id1Match[1]}</span></div>}
            {id2Match && <div className='flex justify-between'><Fingerprint className="h-4 w-4 text-gray-400 mr-2" /> <span>ID2: {id2Match[1]}</span></div>}
        </div>
    );
};


export default function ReversedTransferDetailsPage({
  reversal,
  onBack,
}: ReversedTransferDetailsPageProps) {
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const [shopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const myShopName = shopInfo?.shopName || 'My Shop';

  if (!reversal) {
    // This guard clause prevents the component from crashing during build
    return null;
  }
  
  const originalTransfer = history.find(item => item.id === reversal.originalTransferId);

  const handleGenerateReversalInvoice = () => {
    if (!originalTransfer) {
        toast.error("Original transfer record not found.");
        return;
    }

    const doc = new jsPDF();
    const primaryColor = [220, 38, 38]; // Red
    const secondaryColor = [105, 105, 105];
    const lightGray = [254, 242, 242]; // Light Red
    
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(0, 0, 210, 45, 'F');
    doc.setFontSize(32);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text("REVERSED", 105, 25, { align: "center" });
    doc.setFontSize(12);
    doc.text("Transfer Reversal Document", 105, 35, { align: "center" });

    let yPos = 60;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text("Original Transfer Details", 15, yPos);
    
    yPos += 7;
    const ramStorageMatch = originalTransfer.details.match(/(\d+GB)\/(\d+GB|1TB)/);
    const id1Match = originalTransfer.details.match(/ID1?:\s*([^\s,]+)/i);
    const id2Match = originalTransfer.details.match(/ID2:\s*([^\s,]+)/i);
    const fromMatch = originalTransfer.details.match(/From\s*([^-]+)/i);
    const toMatch = originalTransfer.details.match(/To\s*([^-]+)/i);
    
    let colorPart = originalTransfer.details;
    if(ramStorageMatch) colorPart = colorPart.replace(ramStorageMatch[0], '');
    if(id1Match) colorPart = colorPart.replace(`- ID1: ${id1Match[1]}`, '');
    if(id2Match) colorPart = colorPart.replace(`ID2: ${id2Match[1]}`, '');
    if(fromMatch) colorPart = colorPart.replace(fromMatch[0], '');
    if(toMatch) colorPart = colorPart.replace(toMatch[0], '');
    colorPart = colorPart.replace(/,/g, '').trim();

    const transferData = {
        name: originalTransfer.productName,
        id: id1Match ? id1Match[1] : 'N/A',
        id2: id2Match ? id2Match[1] : '',
        ram: ramStorageMatch ? ramStorageMatch[1] : 'N/A',
        storage: ramStorageMatch ? ramStorageMatch[2] : 'N/A',
        color: colorPart,
        price: originalTransfer.type === 'Transfer Out' ? originalTransfer.salePrice || 0 : originalTransfer.purchasePrice || 0,
        transferType: originalTransfer.type,
        transferFrom: fromMatch ? fromMatch[1].trim() : myShopName,
        transferTo: toMatch ? toMatch[1].trim().replace('- ID1:', '').trim() : myShopName,
        paymentStatus: originalTransfer.status
    };

    const details = [
        { label: "Product:", value: transferData.name },
        { label: "Config:", value: `${transferData.ram}/${transferData.storage}` },
        { label: "Color:", value: transferData.color },
        { label: "ID1:", value: transferData.id },
        ...(transferData.id2 ? [{ label: "ID2:", value: transferData.id2 }] : []),
        { label: "From:", value: transferData.transferFrom },
        { label: "To:", value: transferData.transferTo },
        { label: "Original Status:", value: transferData.paymentStatus },
        { label: "Amount:", value: `Rs. ${transferData.price.toLocaleString()}` }
    ];

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
    doc.roundedRect(15, yPos, 180, (details.length * 8) + 8, 3, 3, 'F');
    
    yPos += 8;
    details.forEach(detail => {
        doc.setFont('helvetica', 'bold');
        doc.text(detail.label, 20, yPos);
        doc.setFont('helvetica', 'normal');
        doc.text(detail.value, 60, yPos);
        yPos += 8;
    });
    
    yPos += 10;
    
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(0,0,0);
    doc.text("Reversal Information", 15, yPos);

    yPos += 10;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    const reversalInfo = [
      { label: "Original Date:", value: format(new Date(originalTransfer.date), 'PPP p') },
      { label: "Reversed On:", value: format(new Date(reversal.date), 'PPP p') },
      { label: "Reversed From:", value: transferData.transferTo },
      { label: "Reversed To:", value: transferData.transferFrom },
      { label: "Reason:", value: reversal.reason }
    ];

    reversalInfo.forEach(info => {
      doc.setFont('helvetica', 'bold');
      doc.text(info.label, 20, yPos);
      doc.setFont('helvetica', 'normal');
      doc.text(info.value, 60, yPos);
      yPos += 7;
    });


    const pdfBlob = doc.output("blob");
    const pdfFile = new File([pdfBlob], "reversal_invoice.pdf", { type: "application/pdf" });
    
    if (navigator.share && navigator.canShare({ files: [pdfFile] })) {
        navigator.share({ files: [pdfFile], title: 'Reversal Invoice' })
          .then(() => toast.success('Reversal invoice shared!'))
          .catch((err) => toast.error('Error sharing: ' + err.message));
    } else {
        const pdfUrl = URL.createObjectURL(pdfBlob);
        const a = document.createElement('a');
        a.href = pdfUrl;
        a.download = 'reversal_invoice.pdf';
        a.click();
        URL.revokeObjectURL(pdfUrl);
        toast.info('Reversal invoice downloaded.');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 font-sans slide-in-from-right">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-6 w-6 text-gray-700" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900">
              Reversed Transfer Details
            </h1>
             <div className="w-10"></div>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 space-y-6">
        <Card className="shadow-lg rounded-2xl">
          <CardHeader className="flex flex-row items-center space-x-4 p-6">
            <div className="p-4 rounded-full bg-pink-100">
              <RefreshCw className="h-6 w-6 text-pink-600" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-gray-800">
                {reversal.productName}
              </CardTitle>
              <p className="font-semibold text-lg text-pink-600">
                Reversed Transfer
              </p>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-0 space-y-4 text-gray-700">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <CalendarIcon className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Reversed On</span>
              </div>
              <span>{format(new Date(reversal.date), 'PPP p')}</span>
            </div>
             <div className="flex justify-between items-start pt-4 border-t">
              <div className="flex items-center space-x-2">
                <Info className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Reason</span>
              </div>
              <span className="text-right flex-1 pl-4">{reversal.reason}</span>
            </div>
            <div className="flex justify-between items-start pt-4 border-t">
              <div className="flex items-center space-x-2">
                <Info className="h-5 w-5 text-gray-400" />
                <span className="font-semibold">Original Details</span>
              </div>
              <DetailParser details={reversal.details} />
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-lg rounded-2xl">
            <CardContent className="p-4">
                <Button onClick={handleGenerateReversalInvoice} variant="outline" className="w-full h-12 text-md" disabled={!originalTransfer}>
                    <Share2 className="mr-2 h-5 w-5" />
                    Generate Reversal Invoice
                </Button>
            </CardContent>
        </Card>
      </main>
    </div>
  );
}
