
'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Tag, Info, Calendar, ChevronRight, IndianRupee, Share2 } from 'lucide-react';
import { format } from 'date-fns';
import { type ReversedTransferItem } from './page';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../transfer-records/page';

const DetailParser = ({ details, history }: { details: string; history: HistoryItem[] }) => {
    if (!details) return null;

    const fromMatch = details.match(/From\s(.*?)\s-/);
    const toMatch = details.match(/To\s(.*?)\s-/);

    const fromToParts: string[] = [];
    if (fromMatch) fromToParts.push(`From: ${fromMatch[1]}`);
    if (toMatch) fromToParts.push(`To: ${toMatch[1]}`);
    const fromTo = fromToParts.join(' ');
    
    return fromTo ? (
        <div className="flex items-center text-xs text-gray-500">
            <Share2 className="h-3.5 w-3.5 mr-2 mt-0.5 flex-shrink-0" />
            <span>{fromTo}</span>
        </div>
    ) : null;
};


export const ReversedHistoryItemCard = ({ item }: { item: ReversedTransferItem }) => {
  const [history] = useLocalStorage<HistoryItem[]>('history', []);
  const originalTransfer = history.find(h => h.id === item.originalTransferId);
  const amount = originalTransfer?.totalAmount || 0;

  return (
     <Card
      key={item.id}
      className="bg-white shadow-md rounded-2xl cursor-pointer hover:bg-gray-50 transition-colors mb-3"
    >
      <CardContent className="p-4 flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1 min-w-0">
            <div className="p-3 rounded-xl bg-pink-100">
              <RefreshCw className="h-6 w-6 text-pink-600" />
            </div>
            <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                    <p className="font-semibold text-gray-900 text-left truncate pr-2">
                        {item.productName}
                    </p>
                    <p className="font-semibold text-lg text-pink-600 whitespace-nowrap">
                        {amount.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
                    </p>
                </div>
                 <div className="mt-2 space-y-1">
                    <DetailParser details={item.details} history={history} />
                    <div className="flex items-center text-xs text-gray-500">
                      <Calendar className="h-3.5 w-3.5 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Reversed on: {format(new Date(item.date), 'PP')}</span>
                    </div>
                    <div className="flex items-start text-xs text-gray-500">
                      <Info className="h-3.5 w-3.5 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="truncate">Reason: {item.reason}</span>
                    </div>
                </div>
            </div>
          </div>
          <div className="flex items-center space-x-2 pl-4">
              <ChevronRight className="h-4 w-4 text-gray-400" />
          </div>
      </CardContent>
    </Card>
  );
};
