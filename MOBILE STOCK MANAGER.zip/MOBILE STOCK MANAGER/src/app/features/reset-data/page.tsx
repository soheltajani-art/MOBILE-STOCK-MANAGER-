
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Trash2, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';

export default function ResetDataPage() {
  const router = useRouter();
  const [isResetting, setIsResetting] = useState(false);

  const handleResetData = () => {
    setIsResetting(true);
    toast.info('Resetting Data...', {
        description: 'Your application is being reset to its initial state.'
    });

    setTimeout(() => {
        try {
            // This will clear all keys from localStorage for this domain
            window.localStorage.clear();
            
            toast.success('Data Reset Successfully!', {
                description: 'The application has been reset. Reloading now...'
            });
            
            // Redirect to home page to see the fresh start
            router.push('/');

        } catch (error) {
            console.error("Failed to reset data:", error);
            toast.error('Reset Failed', {
                description: 'Could not reset application data. Please try again.'
            });
        } finally {
            setIsResetting(false);
        }
    }, 1500); // Simulate a short delay
  };

  return (
    <div className="flex flex-col h-screen bg-background font-sans slide-in-from-right">
      <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Reset All Data
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl rounded-3xl bg-card">
          <CardHeader className="text-center">
            <div className="mx-auto bg-red-100 p-4 rounded-full mb-4 inline-block">
                <AlertTriangle className="h-10 w-10 text-red-500" />
            </div>
            <CardTitle className="text-2xl font-bold text-red-600">
              Danger Zone
            </CardTitle>
            <CardDescription className="text-base text-muted-foreground">
              This action will permanently delete all application data from your browser.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground mb-6 text-center">
                This includes all products, sales history, transfer records, basic stock, and any other saved information. This action cannot be undone. Use this only if you want to start over from a completely fresh state.
            </p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  className="w-full h-14 text-lg rounded-xl"
                  disabled={isResetting}
                >
                  {isResetting ? (
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  ) : (
                    <Trash2 className="mr-2 h-5 w-5" />
                  )}
                  {isResetting ? 'Resetting...' : 'Reset All Application Data'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete all your data. This action cannot be undone. Are you sure you want to proceed?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleResetData}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Yes, Delete Everything
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
