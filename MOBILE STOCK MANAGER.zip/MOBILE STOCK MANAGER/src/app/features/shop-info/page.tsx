
'use client';

import { useEffect, useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, Building, User, Phone, Mail, MapPin, Save, Edit, Lock, ArrowLeft } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';


export type ShopInfo = {
  shopName: string;
  ownerName: string;
  mobileNumber: string;
  email: string;
  address: string;
};

const formSchema = z.object({
  shopName: z.string().min(1, 'Shop name is required.'),
  ownerName: z.string().min(1, 'Owner name is required.'),
  mobileNumber: z.string().regex(/^\d{10}$/, 'Mobile number must be 10 digits.'),
  email: z.string().email('Invalid email address.'),
  address: z.string().min(1, 'Address is required.'),
});


const DetailRow = ({ icon: Icon, label, value }: { 
  icon: React.ElementType, 
  label: string, 
  value?: string,
}) => (
  <div className="flex items-start py-3 border-b last:border-0">
    <Icon className="h-5 w-5 text-muted-foreground mt-1 mr-4" />
    <div className="flex-1">
      <p className="text-sm text-muted-foreground">{label}</p>
      {value ? (
         <div className="flex justify-between items-center">
            <p className="font-semibold text-foreground break-words">{value}</p>
        </div>
      ) : (
        <Skeleton className="h-5 w-3/4 mt-1" />
      )}
    </div>
  </div>
);


export default function ShopInfoPage() {
  const router = useRouter();
  const [shopInfo, setShopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const [isMounted, setIsMounted] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [hasChangedOnce, setHasChangedOnce] = useLocalStorage<boolean>('shopInfoChangedOnce', false);
  const [showUnlockDialog, setShowUnlockDialog] = useState(false);
  const [unlockCodeInput, setUnlockCodeInput] = useState('');

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      shopName: '',
      ownerName: '',
      mobileNumber: '',
      email: '',
      address: '',
    },
  });

  useEffect(() => {
    setIsMounted(true);
    if (!shopInfo) {
      setIsEditing(true); // If no info, automatically enter edit mode
    } else {
      form.reset(shopInfo);
    }
  }, [shopInfo, form]);

  const handleSave = (data: z.infer<typeof formSchema>) => {
    // Prevent saving if the details are identical
    if (isEditing && shopInfo && JSON.stringify(data) === JSON.stringify(shopInfo)) {
        toast.warning("No Changes Detected", {
            description: "Please modify the details before saving.",
        });
        return;
    }

    setShopInfo(data);
    if (!hasChangedOnce) {
        setHasChangedOnce(true);
    }
    setIsEditing(false);
    toast.success("Shop Details Saved", {
      description: "Your shop details have been successfully saved."
    });
  };

  const handleUnlockSubmit = () => {
    if (unlockCodeInput === 'MOBILE_SOTCK_MANAGER_@CHANGE_SHOP_DETAILS') {
        setIsEditing(true);
        setShowUnlockDialog(false);
        setUnlockCodeInput('');
        toast.success('Shop Details Unlocked', {
            description: 'You can now edit your shop details. Remember to save.'
        });
    } else {
        toast.error('Invalid Code', {
            description: 'The code you entered is incorrect. Please try again.'
        });
    }
  };


  return (
    <div className="flex flex-col min-h-screen bg-background">
       <header className="bg-card shadow-sm sticky top-0 z-10 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
             <Button variant="ghost" size="icon" onClick={() => router.push('/features')}>
                <ArrowLeft className="h-6 w-6 text-foreground" />
            </Button>
            <h1 className="text-xl font-bold text-foreground">
              Shop Information
            </h1>
            <div className="w-10"></div>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-start p-4 py-8">
        <Card className="w-full max-w-md shadow-2xl rounded-3xl bg-card">
          <CardHeader className="text-center p-6">
            <CardTitle className="text-2xl font-bold">
              {isEditing ? (shopInfo ? 'Edit Shop Details' : 'Set Up Shop Details') : 'Shop Information'}
            </CardTitle>
            <CardDescription>
              {isEditing ? 'Fill in or update your shop details.' : 'Your saved shop details.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6 pt-0 space-y-4">
             {!isEditing && shopInfo && (
                <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Notice: How to Change Details</AlertTitle>
                    {hasChangedOnce ? (
                      <AlertDescription>
                        Your shop information has been locked because it has been changed once already. It cannot be changed again.
                      </AlertDescription>
                    ) : (
                      <AlertDescription>
                        Shop information can be changed one time only. To receive a one-time unlock code, go to the <strong>Help &amp; Support</strong> page and send an email with your current shop details for verification. After verification, you will receive your unique code.
                      </AlertDescription>
                    )}
                </Alert>
            )}

            {isEditing ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSave)} className="space-y-4">
                    <FormField control={form.control} name="shopName" render={({ field }) => (
                        <FormItem><FormLabel>Shop Name</FormLabel><FormControl><Input placeholder="Enter shop name" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="ownerName" render={({ field }) => (
                        <FormItem><FormLabel>Owner Name</FormLabel><FormControl><Input placeholder="Enter owner's name" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="mobileNumber" render={({ field }) => (
                        <FormItem><FormLabel>Mobile Number</FormLabel><FormControl><Input type="tel" placeholder="Enter 10-digit mobile number" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="Enter email address" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="address" render={({ field }) => (
                        <FormItem><FormLabel>Address</FormLabel><FormControl><Input placeholder="Enter shop address" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                     <Button type="submit" className="w-full h-12 text-lg">
                        <Save className="mr-2 h-5 w-5" />
                        Save Details
                    </Button>
                    {!shopInfo && (
                        <Button type="button" variant="outline" onClick={() => router.push('/dashboard')} className="w-full h-12 text-lg">
                           Skip and Go to Dashboard
                        </Button>
                    )}
                </form>
              </Form>
            ) : (
              <>
                <Card className="bg-muted/50 p-4 space-y-2">
                  <DetailRow icon={Building} label="Shop Name" value={isMounted ? shopInfo?.shopName : undefined} />
                  <DetailRow icon={User} label="Owner Name" value={isMounted ? shopInfo?.ownerName : undefined} />
                  <DetailRow icon={Phone} label="Mobile" value={isMounted ? shopInfo?.mobileNumber : undefined} />
                  <DetailRow icon={Mail} label="Email" value={isMounted ? shopInfo?.email : undefined} />
                  <DetailRow icon={MapPin} label="Address" value={isMounted ? shopInfo?.address : undefined} />
                </Card>

                <AlertDialog open={showUnlockDialog} onOpenChange={setShowUnlockDialog}>
                    <AlertDialogTrigger asChild>
                        <Button variant="outline" className="w-full" disabled={hasChangedOnce}>
                            {hasChangedOnce ? <Lock className="mr-2 h-4 w-4"/> : <Edit className="mr-2 h-4 w-4"/>}
                            {hasChangedOnce ? 'Details Changed Once' : 'Change Shop Details'}
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Enter Unlock Code</AlertDialogTitle>
                        <AlertDialogDescription>
                            To change your shop details, please enter the special code provided by support.
                        </AlertDialogDescription>
                        <Input 
                            placeholder="Enter code here"
                            value={unlockCodeInput}
                            onChange={(e) => setUnlockCodeInput(e.target.value)}
                        />
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleUnlockSubmit}>Submit Code</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
