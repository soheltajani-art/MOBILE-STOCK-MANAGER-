
'use client';

import { Wrench } from 'lucide-react';

export default function NotImplementedPage() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-background p-4 text-center">
      <div className="bg-muted p-4 rounded-full mb-4">
        <Wrench className="h-12 w-12 text-muted-foreground" />
      </div>
      <h1 className="text-2xl font-bold text-foreground">
        This feature is under development.
      </h1>
      <p className="mt-2 text-muted-foreground">
        Please check back later!
      </p>
    </div>
  );
}
