
'use client';
import {
  ArrowDown,
  ArrowUp,
  CheckCircle,
  CircleDollarSign,
  LineChart,
  List,
  Package,
  PackageMinus,
  PackagePlus,
  RefreshCw,
  Search,
  Send,
  Loader2,
  Hourglass,
  LayoutDashboard,
  Info,
  Eye,
  AlertTriangle,
  Bell,
  X,
  Cpu,
  Smartphone,
  Paintbrush,
  CheckCircle2,
  XCircle,
  Building,
  IndianRupee,
  Users,
  UserPlus,
  Clock,
  ArrowRight,
  ArrowLeft as ArrowLeftIcon,
  Lock,
  ChevronDown,
} from 'lucide-react';
import { useState, useMemo, useEffect, useRef, FormEvent } from 'react';
import Link from 'next/link';
import type { LucideIcon } from 'lucide-react';
import { isToday, formatDistanceToNow, format } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type HistoryItem } from '../features/transfer-records/page';
import { type Product } from '../features/where-is-my-product/page';
import { type ReversedTransferItem } from '../features/reverse-transfers/page';
import { type ShopInfo } from '../shop-information/page';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';
import ProductDetailsModal from '../product-details-modal';
import { useInfiniteScroll } from '@/hooks/use-infinite-scroll';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ProductStatus, ProductStatusInfo } from '../features/where-is-my-product/page';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"


const getNavItems = () => [
  {
    label: 'Features',
    icon: List,
    href: '/features',
    enabled: true,
  },
  {
    label: 'Purchase',
    icon: PackagePlus,
    href: '/purchase-stock',
    enabled: true,
  },
  {
    label: 'Sold Out',
    icon: PackageMinus,
    href: '/stock-out',
    enabled: true,
  },
  {
    label: 'Transfer',
    icon: Send,
    href: '/transfer',
    enabled: true,
  },
];


const activityIconMap: Record<string, LucideIcon> = {
  Sale: PackageMinus,
  Purchase: PackagePlus,
  'Transfer In': ArrowDown,
  'Transfer Out': ArrowUp,
  'Purchase & Sale': PackageMinus,
  'Transfer In & Sale': PackageMinus,
  Settlement: CheckCircle,
  'Reversed Transfer': RefreshCw,
};

const getStatusBadge = (statusInfo: ProductStatusInfo) => {
    const { status, transferShop } = statusInfo;
    switch (status) {
        case 'Sold Out':
        return (
            <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Sold Out
            </Badge>
        );
        case 'Pending Out':
        return (
            <Badge className="bg-purple-100 text-purple-800 border-purple-200 text-xs whitespace-nowrap">
            <ArrowUp className="h-3 w-3 mr-1" />
            Pending Out {transferShop && `to ${transferShop}`}
            </Badge>
        );
        case 'Pending In':
        return (
            <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs whitespace-nowrap">
            <ArrowDown className="h-3 w-3 mr-1" />
            Pending In {transferShop && `from ${transferShop}`}
            </Badge>
        );
        case 'In Stock':
        default:
        return (
            <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            In Stock
            </Badge>
        );
    }
};

export default function DashboardPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products] = useLocalStorage<Product[]>('products', []);
  const [basicProducts] = useLocalStorage<Product[]>('basic-products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>(
    'reversedTransfers',
    []
  );
  const [shopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const [isMounted, setIsMounted] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showExitDialog, setShowExitDialog] = useState(false);
  const [backPressCount, setBackPressCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchWrapperRef = useRef<HTMLDivElement>(null);
  const navItems = getNavItems();


  useEffect(() => {
    setIsMounted(true);
  }, []);


  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      // Intercept back button press only when on the dashboard
      if (window.location.pathname === '/dashboard') {
        event.preventDefault(); 
        setBackPressCount((prev) => prev + 1);
      } else {
        // If not on the dashboard, let the default behavior happen
        router.back();
      }
    };
    
    // This pushes a new state to the history, allowing us to catch the first back press
    window.history.pushState(null, '', window.location.href);
    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [router]);

  useEffect(() => {
    if (backPressCount === 1) {
      toast('Press back again to exit.');
      // Reset the count if the user doesn't press back again within 2 seconds
      const timer = setTimeout(() => {
        setBackPressCount(0);
        // This is needed to allow the user to navigate back after the toast disappears
        window.history.pushState(null, '', window.location.href);
      }, 2000); 
      return () => clearTimeout(timer);
    } else if (backPressCount >= 2) {
      setShowExitDialog(true);
      setBackPressCount(0); // Reset count after showing dialog
    }
  }, [backPressCount]);


  useEffect(() => {
    if (typeof window !== 'undefined') {
      const transferSuccess = new URLSearchParams(window.location.search).get(
        'transferSuccess'
      );
      if (transferSuccess) {
        toast.success('Transfer Successful!', {
          description: 'Your transfer has been recorded.',
        });
        router.replace('/dashboard', undefined);
      }
    }
  }, [router]);

  const allProducts = useMemo(() => {
    if (!isMounted) return [];
    return [...products, ...basicProducts.map(p => ({...p, brand: 'Basic Stock'}))];
  }, [products, basicProducts, isMounted]);

  const searchResults = useMemo(() => {
    if (!searchQuery) return [];
    return allProducts.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.id2 && p.id2.toLowerCase().includes(searchQuery.toLowerCase()))
    ).slice(0, 10); // Limit to 10 results for performance
  }, [searchQuery, allProducts]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchWrapperRef.current && !searchWrapperRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [searchWrapperRef]);

  const getProductStatus = (product: Product): ProductStatusInfo => {
    if (product.stock === 0) {
      return { status: 'Sold Out' };
    }

    const findShopName = (details: string): string | undefined => {
      const match = details.match(/(?:From|To):\s*([^-\s]+)/);
      return match ? match[1] : undefined;
    };
    
    const pendingTransferOut = history.find(item => 
      item.type === 'Transfer Out' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferOut) {
      return {
        status: 'Pending Out',
        transferShop: findShopName(pendingTransferOut.details),
      };
    }

    const pendingTransferIn = history.find(item => 
      item.type === 'Transfer In' &&
      item.status === 'Pending' &&
      (item.details.includes(product.id) || (product.id2 && item.details.includes(product.id2))) &&
      !reversedTransfers.some(rt => rt.originalTransferId === item.id)
    );

    if (pendingTransferIn) {
      return {
        status: 'Pending In',
        transferShop: findShopName(pendingTransferIn.details),
      };
    }

    return { status: 'In Stock' };
  };

  const unsettledSales = useMemo(() => {
    if (!isMounted) return [];
    return history.filter(item => item.type === 'Sale' && item.saleStatus === 'unsettled_transfer');
  }, [history, isMounted]);

  const totalNotifications = unsettledSales.length;

  const {
    totalStock,
    todaysSaleQuantity,
    todaysPurchasesQuantity,
    todaysSoldOut,
    todaysTransferIn,
    todaysTransferOut,
    todaysSalesRupees,
    todaysProfit,
    allRecentActivity,
  } = useMemo(() => {
    if (!isMounted) {
      return {
        totalStock: 0,
        todaysSaleQuantity: 0,
        todaysPurchasesQuantity: 0,
        todaysSoldOut: 0,
        todaysTransferIn: 0,
        todaysTransferOut: 0,
        todaysSalesRupees: 0,
        todaysProfit: 0,
        allRecentActivity: [],
      };
    }
    
    const todayHistory = history.filter((item) => isToday(new Date(item.date)));
    const todaysSales = todayHistory.filter((item) => item.type === 'Sale');
    const todaysPurchases = todayHistory.filter(
      (item) => item.type === 'Purchase'
    );

    const todaysPurchasesQuantity = todaysPurchases.reduce(
      (sum, item) => sum + item.quantity,
      0
    );

    const todaysTransferIn = todayHistory
      .filter((item) => item.type === 'Transfer In')
      .reduce((sum, item) => sum + item.quantity, 0);

    const todaysTransferOut = todayHistory
      .filter((item) => item.type === 'Transfer Out')
      .reduce((sum, item) => sum + item.quantity, 0);

    const todaysSaleQuantity = todaysSales.reduce(
      (sum, item) => sum + item.quantity,
      0
    );

    const todaysSoldOut = todaysSales.reduce(
      (sum, item) => sum + item.quantity,
      0
    );

    const todaysSalesRupees = todaysSales.reduce(
      (sum, item) => sum + item.totalAmount,
      0
    );

    const todaysProfit = todaysSales.reduce((profit, sale) => {
      // Find the product ID from the sale details
      const idMatch = sale.details.match(/ID1?:\s*([^\s,]+)/i);
      if (!idMatch) return profit;

      const productId = idMatch[1].toLowerCase();
      
      // Check if the product's origin is a 'Transfer In'
      const originIsTransferIn = history.some(h => 
        (h.type === 'Transfer In') &&
        (h.details.toLowerCase().includes(`id1: ${productId}`) || h.details.toLowerCase().includes(`id: ${productId}`))
      );

      // If origin is a transfer, exclude it from dashboard profit calculation
      if (originIsTransferIn) {
        return profit;
      }
      
      // Otherwise, calculate profit as usual
      if (sale.salePrice && sale.purchasePrice) {
        return profit + (sale.salePrice - sale.purchasePrice) * sale.quantity;
      }
      return profit;
    }, 0);

    const totalStock = products.reduce(
      (sum, product) => sum + product.stock,
      0
    );
    
    // --- MERGE LOGIC ---
    const mergedActivity: HistoryItem[] = [];
    const processedIds = new Set<number>();
    
    const todaysFullHistory = history.filter((activity) => isToday(new Date(activity.date)))
    const costEventsForMerge = todaysFullHistory.filter(h => h.type === 'Purchase' || h.type === 'Transfer In');
    const salesForMerge = todaysFullHistory.filter(h => h.type === 'Sale');

    salesForMerge.forEach(sale => {
        if (processedIds.has(sale.id)) return;

        const saleIdMatch = sale.details.match(/ID1:\s*([^\s,]+)/);
        if (!saleIdMatch) return;
        const productId = saleIdMatch[1];
        
        const correspondingCostEvent = costEventsForMerge.find(costEvent =>
            !processedIds.has(costEvent.id) && costEvent.details.includes(productId)
        );

        if (correspondingCostEvent) {
            const isTransfer = correspondingCostEvent.type === 'Transfer In';
            const cost = isTransfer ? correspondingCostEvent.totalAmount : correspondingCostEvent.purchasePrice;
            
            mergedActivity.push({
                id: sale.id,
                type: isTransfer ? 'Transfer In & Sale' : 'Purchase & Sale',
                productName: sale.productName,
                date: sale.date,
                quantity: sale.quantity,
                totalAmount: sale.totalAmount, // This is sale price
                purchasePrice: cost,
                salePrice: sale.salePrice,
                details: `Profit: ${(sale.salePrice || 0) - (cost || 0)}`,
                purchaseDetails: correspondingCostEvent.details,
                saleDetails: sale.details,
            });
            processedIds.add(sale.id);
            processedIds.add(correspondingCostEvent.id);
        }
    });

    const otherActivities = todaysFullHistory.filter(activity => !processedIds.has(activity.id) && activity.type !== 'Settlement');
    const combined = [...mergedActivity, ...otherActivities, ...salesForMerge.filter(s => !processedIds.has(s.id))];

    // Attach reversal and settlement info
    let historyWithReversals = combined.map((item) => {
      const originalItemId = item.originalTransferId || item.id;
      const reversal = reversedTransfers.find(rt => rt.originalTransferId === originalItemId);

      if (reversal && (item.type === 'Transfer In' || item.type === 'Transfer Out')) {
          return { ...item, isReversed: true, reversalReason: reversal.reason };
      }

      if ((item.type === 'Transfer In' || item.type === 'Transfer Out') && !item.isReversed) {
        const settlement = history.find(h => h.type === 'Settlement' && h.originalTransferId === item.id);
        if (settlement) {
          return { ...item, status: 'Settled', settledDate: settlement.date };
        }
      }
      return item;
    }).filter(item => !(item.isReversed && (item.type !== 'Transfer In' && item.type !== 'Transfer Out')));


    const sortedHistory = historyWithReversals.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const allRecentActivity = sortedHistory.map((activity) => ({
      ...activity,
      icon: activityIconMap[activity.type] || Package,
      title: `${activity.type}: ${activity.productName}`,
      description: (activity.type === 'Purchase & Sale' || activity.type === 'Transfer In & Sale')
        ? `Profit: ${(activity.salePrice! - activity.purchasePrice!).toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}`
        : `Qty: ${activity.quantity} - ${activity.details}`,
      time: formatDistanceToNow(new Date(activity.date), { addSuffix: true }),
    }));
    

    return {
      totalStock,
      todaysSaleQuantity,
      todaysPurchasesQuantity,
      todaysSoldOut,
      todaysTransferIn,
      todaysTransferOut,
      todaysSalesRupees,
      todaysProfit,
      allRecentActivity,
    };
  }, [products, history, reversedTransfers, isMounted]);

  const {
    items: recentActivity,
    isLoadingMore,
    sentryRef,
  } = useInfiniteScroll({
    items: allRecentActivity,
    itemsPerPage: 5,
  });

  const handleSearchResultClick = (product: Product) => {
    setSelectedProduct(product);
    setSearchQuery('');
    setIsSearchFocused(false);
  }

  const stats = [
    {
      title: 'Total Stock',
      value: totalStock,
      icon: Package,
      color: 'text-white bg-gradient-to-br from-purple-500 to-indigo-600',
    },
    {
      title: "Today's Sale Quantity",
      value: todaysSaleQuantity,
      icon: LineChart,
      color: 'text-white bg-gradient-to-br from-green-500 to-teal-500',
    },
  ];

  const secondaryStats = [
    {
      title: 'Today’s Purchases',
      value: todaysPurchasesQuantity.toLocaleString(),
      icon: PackagePlus,
      href: '/features/main-history?filter=purchase',
      tag: 'purchase',
    },
    {
      title: 'Today’s Sold Out',
      value: todaysSoldOut.toLocaleString(),
      icon: PackageMinus,
      href: '/features/main-history?filter=sale',
      tag: 'sale',
    },
    {
      title: 'Today’s Transfer In',
      value: todaysTransferIn.toLocaleString(),
      icon: ArrowDown,
      href: '/features/transfer-records?type=in',
      tag: 'transfer-in',
    },
    {
      title: 'Today’s Transfer Out',
      value: todaysTransferOut.toLocaleString(),
      icon: ArrowUp,
      href: '/features/transfer-records?type=out',
      tag: 'transfer-out',
    },
  ];

  const tertiaryStats = [
    {
      title: 'Today’s Sales (Rupees)',
      value: todaysSalesRupees.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: CircleDollarSign,
      color: 'text-white bg-gradient-to-br from-pink-500 to-red-600',
    },
    {
      title: "Today's Profit",
      value: todaysProfit.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
      }),
      icon: CircleDollarSign,
      color: 'text-white bg-gradient-to-br from-cyan-500 to-blue-600',
    },
  ];

  const handleActivityClick = (activity: HistoryItem) => {
    const idRegex = /ID1?:\s*([^\s,]+)/i;
    let detailsString = '';
  
    if (activity.purchaseDetails) {
      detailsString = activity.purchaseDetails; 
    } else if (activity.details) {
      detailsString = activity.details;
    }
  
    if (!detailsString) {
      toast.error('Cannot find product', { description: 'Activity details are missing.' });
      return;
    }
  
    const match = detailsString.match(idRegex);
    const lookupId = match ? match[1].toLowerCase() : null;
  
    if (!lookupId) {
      toast.error('Product ID not found', {
        description: 'Cannot determine product from activity details.',
      });
      return;
    }
  
    let product = allProducts.find(p => p.id.toLowerCase() === lookupId || (p.id2 && p.id2.toLowerCase() === lookupId));
  
    if (product) {
      setSelectedProduct(product);
    } else {
      const purchaseRecord = history.find(h =>
        (h.type === 'Purchase' || h.type === 'Transfer In') &&
        h.details.toLowerCase().includes(`id1: ${lookupId}`)
      );
  
      if (purchaseRecord) {
        const id1Match = purchaseRecord.details.match(/ID1:\s*([^\s,]+)/i);
        const id2Match = purchaseRecord.details.match(/ID2:\s*([^\s,]+)/i);
        const ramStorageMatch = purchaseRecord.details.match(/(\d+GB)\/(\d+GB|1TB)/);
        const colorMatch = purchaseRecord.details.match(/, ([^,]+) - ID1:/);
  
        const reconstructedProduct: Product = {
          id: id1Match ? id1Match[1] : lookupId.toUpperCase(),
          id2: id2Match ? id2Match[1] : undefined,
          name: purchaseRecord.productName,
          stock: 0,
          ram: ramStorageMatch ? ramStorageMatch[1] : 'N/A',
          storage: ramStorageMatch ? ramStorageMatch[2] : 'N.A',
          color: colorMatch ? colorMatch[1] : 'N/A',
          purchasePrice: purchaseRecord.purchasePrice || 0,
          brand: 'Unknown',
        };
        setSelectedProduct(reconstructedProduct);
      } else {
        toast.error('Product not found', {
          description: `Could not find product with ID ${lookupId.toUpperCase()} in inventory or purchase history.`,
        });
      }
    }
  };

  const getProductHistory = (product: Product | null): HistoryItem[] => {
    if (!product) return [];
  
    const relatedEvents = history.filter((event) => {
      if (event.type === 'Settlement') return false;
      const details = event.details?.toLowerCase() || '';
  
      const id1Match = details.match(/id1?:\s*([^\s,]+)/);
      const id2Match = details.match(/id2:\s*([^\s,]+)/);
  
      const eventId1 = id1Match ? id1Match[1] : null;
      const eventId2 = id2Match ? id2Match[1] : null;
  
      let isMatch = false;
      if (eventId1 && eventId1 === product.id.toLowerCase()) {
        isMatch = true;
      }
      if (eventId2 && eventId2 === product.id.toLowerCase()) {
        isMatch = true;
      }
      if (product.id2) {
        if (eventId1 && eventId1 === product.id2.toLowerCase()) {
          isMatch = true;
        }
        if (eventId2 && eventId2 === product.id2.toLowerCase()) {
          isMatch = true;
        }
      }
  
      return isMatch;
    });
  
    let augmentedEvents = relatedEvents.map((event) => {
      const reversal = reversedTransfers.find(
        (rt) => rt.originalTransferId === event.id
      );
      if (reversal) {
        event.isReversed = true;
      }
  
      if (event.type === 'Transfer In' || event.type === 'Transfer Out') {
        const settlement = history.find(
          (h) => h.type === 'Settlement' && h.originalTransferId === event.id
        );
        if (settlement) {
          event.status = 'Settled';
          event.settledDate = settlement.date;
        }
      }
      return event;
    });
  
    const saleEvent = augmentedEvents.find((e) => e.type === 'Sale');
  
    if (saleEvent) {
      const purchaseEvent = augmentedEvents.find((e) => e.type === 'Purchase');
      const transferInEvent = augmentedEvents.find((e) => e.type === 'Transfer In');
      
      const costEvent = purchaseEvent || transferInEvent;
      
      if (costEvent) {
        const mergedItem: HistoryItem = {
          id: saleEvent.id,
          type: costEvent.type === 'Purchase' ? 'Purchase & Sale' : 'Transfer In & Sale',
          productName: product.name,
          date: saleEvent.date,
          quantity: saleEvent.quantity,
          totalAmount: saleEvent.totalAmount,
          purchasePrice: costEvent.type === 'Purchase' ? costEvent.purchasePrice : costEvent.totalAmount, // This is the key change
          salePrice: saleEvent.salePrice,
          details: '',
          purchaseDetails: costEvent.details,
          saleDetails: saleEvent.details,
        };
  
        return [
          mergedItem,
          ...augmentedEvents.filter(
            (e) => e.id !== costEvent.id && e.id !== saleEvent.id
          ),
        ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
    }
  
    return augmentedEvents.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const handleExit = () => {
    // A simple way to "close" a PWA or web page, though behavior can vary by browser.
    window.close();
    // As a fallback for browsers that don't allow window.close()
    window.location.href = 'about:blank';
  };

  const SecondaryStatCard = ({ stat }: { stat: (typeof secondaryStats)[0] }) => {
    return (
       <Card className="bg-card shadow rounded-2xl flex flex-col justify-between">
          <CardContent className="p-4 flex-grow">
            <Link href={stat.href}>
                <div className="flex items-center space-x-3">
                <div className="bg-muted p-2 rounded-lg">
                    <stat.icon className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    {isMounted ? (
                    <p className="text-2xl font-bold text-foreground">
                        {stat.value}
                    </p>
                    ) : (
                    <Skeleton className="h-8 w-16 mt-1" />
                    )}
                </div>
                </div>
            </Link>
          </CardContent>
        </Card>
    );
  };
  
  return (
    <>
      <AlertDialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-center">YOU WANT TO EXIT?</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter className="!grid grid-cols-2 !justify-center !gap-4">
              <AlertDialogCancel>NO</AlertDialogCancel>
              <AlertDialogAction onClick={handleExit}>YES</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          history={getProductHistory(selectedProduct)}
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}

      <div className="flex flex-col h-screen bg-background font-sans">
        <header className="bg-card shadow-sm flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
               <div className="flex-1 min-w-0">
                  {isMounted && shopInfo?.shopName ? (
                    <div className="relative w-full overflow-hidden whitespace-nowrap">
                      <div className="marquee text-lg font-bold text-foreground">
                        <span>{shopInfo.shopName}</span>
                      </div>
                    </div>
                  ) : null}
              </div>
              <div className="flex items-center gap-2 ml-4 flex-shrink-0">

                <Link href="/features/transfer-summary">
                    <Button variant="outline" size="sm">
                    Transfer Calcs
                    </Button>
                </Link>

                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="relative">
                            <Bell />
                            {totalNotifications > 0 && <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-red-500 border-2 border-white"></span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80 mr-4">
                        <div className="grid gap-4">
                            <div className="space-y-2">
                                <h4 className="font-medium leading-none">Notifications</h4>
                                <p className="text-sm text-muted-foreground">
                                You have {totalNotifications} new notification(s).
                                </p>
                            </div>
                            
                            {unsettledSales.length > 0 && (
                                <>
                                 <Separator />
                                 <div className="grid gap-2">
                                    <h5 className="font-medium text-sm text-foreground">Unsettled Sales</h5>
                                    {unsettledSales.slice(0, 3).map(sale => (
                                        <div key={sale.id} className="flex items-start gap-2 text-sm">
                                            <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                                            <div className="flex-1">
                                                <p className="font-medium">{sale.productName}</p>
                                                <p className="text-muted-foreground">Sold on {format(new Date(sale.date), 'PP')}. Settle original transfer.</p>
                                            </div>
                                        </div>
                                    ))}
                                    <Button variant="outline" size="sm" className="mt-2" asChild>
                                        <Link href="/features/transfer-records">View All & Settle</Link>
                                    </Button>
                                </div>
                               </>
                            )}
                            
                            {totalNotifications === 0 && (
                                <p className="text-sm text-center text-muted-foreground py-4">No new notifications.</p>
                            )}
                        </div>
                    </PopoverContent>
                </Popover>

              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
            <div className="p-4 md:p-6 space-y-6 pb-20">
              
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat) => (
                  <Card
                    key={stat.title}
                    className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}
                  >
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">
                        {stat.title}
                      </CardTitle>
                      <stat.icon className="h-6 w-6" />
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-col">
                        {isMounted ? (
                          <div className="text-4xl font-bold">{stat.value}</div>
                        ) : (
                          <Skeleton className="h-10 w-1/2" />
                        )}
                        {stat.title === 'Total Stock' && (
                           <div className="flex justify-start mt-2">
                            <Link href="/features/inventory-stock">
                                <Button
                                  variant="ghost"
                                  className="h-auto p-1 text-white/80 hover:text-white hover:bg-white/10"
                                >
                                  <Eye className="mr-1 h-4 w-4" /> View
                                </Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="relative" ref={searchWrapperRef}>
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground z-10" />
                <Input
                  placeholder="Search all products by Name or ID..."
                  className="pl-10 bg-card rounded-xl shadow-sm h-12"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                />
                {isSearchFocused && searchResults.length > 0 && (
                  <Card className="absolute z-50 w-full mt-2 max-h-80 overflow-y-auto shadow-2xl rounded-2xl">
                    <CardContent className="p-2">
                      {searchResults.map((product) => (
                        <div
                          key={product.id}
                          className="p-3 hover:bg-accent rounded-lg cursor-pointer"
                          onClick={() => handleSearchResultClick(product)}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                               <p className="font-semibold text-foreground">{product.name}</p>
                                <p className="text-sm text-muted-foreground font-mono">{product.id}</p>
                            </div>
                            <div className="ml-2 flex-shrink-0">
                                {getStatusBadge(getProductStatus(product))}
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2 pt-2 border-t border-border">
                            {product.ram && <span className="flex items-center gap-1"><Cpu className="h-3 w-3" />{product.ram}</span>}
                            {product.storage && <span className="flex items-center gap-1"><Smartphone className="h-3 w-3" />{product.storage}</span>}
                            {product.color && <span className="flex items-center gap-1"><Paintbrush className="h-3 w-3" />{product.color}</span>}
                          </div>
                           <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2 pt-2 border-t border-border">
                            {product.purchasePrice > 0 && <span className="flex items-center gap-1"><IndianRupee className="h-3 w-3" />Purchase: {product.purchasePrice.toLocaleString()}</span>}
                            {product.mop && product.mop > 0 && <span className="flex items-center gap-1"><IndianRupee className="h-3 w-3" />MOP: {product.mop.toLocaleString()}</span>}
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-2 gap-4">
                {secondaryStats.map((stat) => (
                  <SecondaryStatCard key={stat.title} stat={stat} />
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tertiaryStats.map((stat) => (
                  <Card
                    key={stat.title}
                    className={`overflow-hidden shadow-lg ${stat.color} rounded-2xl`}
                  >
                    <CardContent className="p-6 relative">
                      <p className="text-sm">{stat.title}</p>
                      {isMounted ? (
                        <p className="text-3xl font-bold">{stat.value}</p>
                      ) : (
                        <Skeleton className="h-9 w-3/4 mt-1" />
                      )}
                      {(stat.title === 'Today’s Sales (Rupees)' || stat.title === "Today's Profit") && (
                        <div className="absolute bottom-4 right-4">
                          <Link href="/features/sales-report">
                            <Button
                              variant="ghost"
                              className="h-auto p-1 text-white/80 hover:text-white hover:bg-white/10"
                            >
                              <Eye className="mr-1 h-4 w-4" /> View
                            </Button>
                          </Link>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Please Note</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Dashboard profit is for direct purchases and sales only. For profit on transferred items, please see 'Transfer Calcs'.
                </AlertDescription>
              </Alert>

              <div>
                <h2 className="text-xl font-semibold mb-4 text-foreground">
                  Recent Activity
                </h2>
                <Card className="bg-card shadow rounded-2xl">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      {isMounted && recentActivity.length > 0 ? (
                        <>
                          {recentActivity.map((activity) => (
                            <div
                              key={activity.id}
                              className="flex items-center space-x-4 cursor-pointer hover:bg-accent p-2 rounded-lg"
                              onClick={() => handleActivityClick(activity)}
                            >
                              <div className="bg-muted p-3 rounded-full">
                                <activity.icon className="h-5 w-5 text-muted-foreground" />
                              </div>
                              <div className="flex-1">
                                <p className="font-semibold text-foreground">
                                  {activity.title}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {activity.description}
                                </p>
                              </div>
                              <p className="text-sm text-muted-foreground">{activity.time}</p>
                            </div>
                          ))}
                          <div ref={sentryRef} className="h-4">
                            {isLoadingMore && (
                              <div className="flex justify-center items-center">
                                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                              </div>
                            )}
                          </div>
                        </>
                      ) : isMounted && allRecentActivity.length === 0 ? (
                        <div className="text-center text-muted-foreground py-10">
                          <p>No recent activity to display.</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {[...Array(3)].map((_, i) => (
                            <div key={i} className="flex items-center space-x-4">
                              <Skeleton className="h-12 w-12 rounded-full" />
                              <div className="flex-1 space-y-2">
                                <Skeleton className="h-4 w-3/4" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-4 w-1/4" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
        </div>

        <footer className="fixed bottom-0 left-0 right-0 bg-card border-t border-border flex-shrink-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-around items-center h-16">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.enabled ? item.href : '#'}
                  onClick={(e) => {
                    if (!item.enabled) {
                      e.preventDefault();
                      toast.error('Permission Denied', { description: `You do not have permission to access ${item.label}.` });
                    } else {
                      setActiveTab(item.href.replace('/', ''))
                    }
                  }}
                  className={`flex flex-col items-center justify-center h-full text-xs space-y-1 ${
                    activeTab === item.href.replace('/', '')
                      ? 'text-primary'
                      : 'text-muted-foreground'
                  } ${!item.enabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                   { !item.enabled && <Lock className="absolute h-3 w-3 -mt-1 -mr-2" /> }
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
