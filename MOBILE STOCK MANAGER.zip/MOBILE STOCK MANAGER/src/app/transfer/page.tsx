'use client';
import { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Loader2, Search, X, Share2, ScanLine, CheckCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { type Product } from '../features/where-is-my-product/page';
import { type HistoryItem } from '../features/transfer-records/page';
import BarcodeScanner from '@/components/barcode-scanner';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { format } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { type ShopInfo } from '../shop-information/page';
import { type ReversedTransferItem } from '../features/reverse-transfers/page';
import jsPDF from 'jspdf';

const brandOptions = [
    'SAMSUNG',
    'VIVO',
    'OPPO',
    'REDMI',
    'REALME',
    'POCO',
    'ONEPLUS',
    'NOTHING',
    'IPHONE',
    'MOTOROLLA',
    'INFINIX',
    'ITEL',
    'LAVA',
    'TECNO',
    'OTHER',
];

const formSchema = z.object({
  brand: z.string().optional(),
  name: z.string().min(1, 'Product name is required.'),
  id: z.string().length(15, 'Product ID must be exactly 15 digits.'),
  id2: z.string().length(15, 'Product ID must be exactly 15 digits.').optional().or(z.literal('')),
  ram: z.string().min(1, 'RAM is required.'),
  storage: z.string().min(1, 'Storage is required.'),
  color: z.string().min(1, 'Color is required.'),
  price: z.coerce.number().min(1, 'Price is required.'),
  transferType: z.enum(['Transfer In', 'Transfer Out'], {
    required_error: 'Transfer type is required.',
  }),
  transferFrom: z.string().min(1, 'Transfer From is required.'),
  transferTo: z.string().min(1, 'Transfer To is required.'),
  paymentStatus: z.enum(['Paid', 'Unpaid'], {
    required_error: 'Payment status is required.',
  }),
}).refine(data => {
    if (data.transferType === 'Transfer In') {
        return !!data.brand && data.brand.length > 0;
    }
    return true;
}, {
    message: 'Brand is required for Transfer In.',
    path: ['brand'],
});

type TransferFormValues = z.infer<typeof formSchema>;

const ramToStorageMap: Record<string, string[]> = {
  '2GB': ['32GB'],
  '3GB': ['32GB', '64GB'],
  '4GB': ['64GB', '128GB'],
  '6GB': ['128GB', '256GB'],
  '8GB': ['128GB', '256GB', '512GB'],
  '12GB': ['256GB', '512GB', '1TB'],
  '16GB': ['512GB', '1TB'],
};
const allRamOptions = Object.keys(ramToStorageMap);
const allStorageOptions = [...new Set(Object.values(ramToStorageMap).flat())];

const TransferSuccessScreen = ({ data, onDone }: { data: TransferFormValues, onDone: () => void }) => {
    const handleShareReceipt = () => {
      const doc = new jsPDF();

      // Set up colors and fonts for professional look
      const primaryColor = [70, 130, 180]; // Steel Blue
      const secondaryColor = [105, 105, 105]; // Dim Gray
      const lightGray = [240, 248, 255]; // Alice Blue
      const accentColor = [255, 99, 71]; // Tomato (for accents, not primary)
      const lightAccentColor = [173, 216, 230]; // Light Blue
      const successColor = [60, 179, 113]; // Medium Sea Green

      // Add subtle background gradient effect
      doc.setFillColor(255, 255, 255);
      doc.rect(0, 0, 210, 297, 'F');

      // Professional header background
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(0, 0, 210, 45, 'F');

      // Header with enhanced styling
      doc.setFontSize(32);
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.text("TRANSFER", 105, 25, null, null, "center");

      // Add professional subtitle
      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      doc.text("Professional Stock Transfer Document", 105, 35, null, null, "center");

      // Add decorative elements
      doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
      doc.rect(15, 38, 180, 2, 'F');

      // Reset text color for content
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont("helvetica", "normal");

      let yPos = 65;

      // Left Column - Transfer Details with enhanced styling
      doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
      doc.roundedRect(15, yPos - 5, 90, 90, 3, 3, 'F');

      // Add border to left column
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setLineWidth(1);
      doc.roundedRect(15, yPos - 5, 90, 90, 3, 3);

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text("TRANSFER FROM", 20, yPos);

      yPos += 12;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.text("SHOP NAME:", 20, yPos);
      doc.setFont("helvetica", "bold");
      doc.text(data.transferFrom || "N/A", 50, yPos);

      yPos += 12;
      doc.setFont("helvetica", "normal");
      doc.text("PAYMENT STATUS:", 20, yPos);
      doc.setFont("helvetica", "bold");
      // Color code payment status
      if (data.paymentStatus === 'Paid') {
        doc.setTextColor(successColor[0], successColor[1], successColor[2]); // Green for paid
      } else {
        doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]); // Red for unpaid
      }
      doc.text(data.paymentStatus || "N/A", 65, yPos);
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

      yPos += 12;
      doc.setFont("helvetica", "normal");
      doc.text("TRANSFER TYPE:", 20, yPos);
      doc.setFont("helvetica", "bold");
      doc.text(data.transferType || "N/A", 60, yPos);

      yPos += 12;
      doc.setFont("helvetica", "normal");
      doc.text("TRANSFER TIME:", 20, yPos);
      doc.setFont("helvetica", "bold");
      doc.text(new Date().toLocaleTimeString(), 60, yPos);

      yPos += 12;
      doc.setFont("helvetica", "normal");
      doc.text("TRANSFER STATUS:", 20, yPos);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(successColor[0], successColor[1], successColor[2]); // Green for permanent
      doc.text("PERMANENT", 70, yPos);
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

      // Right Column - Date and Product Details with enhanced styling
      let rightYPos = 65;

      // Transfer Date with styled background
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.roundedRect(115, rightYPos - 8, 80, 25, 3, 3, 'F');

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 255, 255);
      doc.text("TRANSFER DATE", 155, rightYPos - 2, null, null, "center");
      rightYPos += 8;
      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      const currentDate = new Date();
      const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')} / ${(currentDate.getMonth() + 1).toString().padStart(2, '0')} / ${currentDate.getFullYear()}`;
      doc.text(formattedDate, 155, rightYPos, null, null, "center");

      rightYPos += 25;

      // Product Details Section with enhanced styling
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text("PRODUCT DETAILS", 155, rightYPos, null, null, "center");

      // Add styled background rectangle for product details
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(115, rightYPos + 2, 80, 75, 3, 3, 'F');
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setLineWidth(1);
      doc.roundedRect(115, rightYPos + 2, 80, 75, 3, 3);

      rightYPos += 15;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

      const productDetails = [
        { label: "PRODUCT NAME:", value: data.name || "N/A" },
        { label: "IMEI 1:", value: data.id || "N/A" },
        { label: "IMEI 2:", value: data.id2 || "N/A" },
        { label: "RAM:", value: data.ram || "N/A" },
        { label: "STORAGE:", value: data.storage || "N/A" },
        { label: "COLOR:", value: data.color || "N/A" }
      ];

      productDetails.forEach((detail, index) => {
        // Alternate row background
        if (index % 2 === 0) {
          doc.setFillColor(248, 249, 250);
          doc.rect(117, rightYPos - 3, 76, 9, 'F');
        }

        doc.text(detail.label, 120, rightYPos);
        doc.setFont("helvetica", "bold");
        // Truncate long values to fit
        const maxLength = 15;
        const displayValue = detail.value.length > maxLength ?
          detail.value.substring(0, maxLength) + "..." : detail.value;
        doc.text(displayValue, 165, rightYPos);
        doc.setFont("helvetica", "normal");
        rightYPos += 10;
      });

      // Bottom Section - Transfer To with enhanced styling
      yPos += 60;
      doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
      doc.roundedRect(15, yPos - 5, 90, 30, 3, 3, 'F');

      // Add border to transfer to section
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setLineWidth(1);
      doc.roundedRect(15, yPos - 5, 90, 30, 3, 3);

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text("TRANSFER TO", 20, yPos);

      yPos += 15;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.text("SHOP NAME:", 20, yPos);
      doc.setFont("helvetica", "bold");
      doc.text(data.transferTo || "N/A", 50, yPos);

      // Amount Section with enhanced styling
      yPos += 35;
      doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
      doc.roundedRect(15, yPos - 8, 180, 30, 3, 3, 'F');

      // Add shadow effect
      doc.setFillColor(0, 0, 0, 0.1);
      doc.roundedRect(17, yPos - 6, 180, 30, 3, 3, 'F');
      doc.setFillColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
      doc.roundedRect(15, yPos - 8, 180, 30, 3, 3, 'F');

      doc.setFontSize(16);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 255, 255);
      doc.text("AMOUNT [RUPEES]:", 20, yPos + 5);

      doc.setFontSize(20);
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.text(`${data.price}`, 185, yPos + 5, null, null, "right");

      // Footer with enhanced styling
      yPos += 45;
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.setFont("helvetica", "italic");
      doc.text("MOBILE STOCK MANAGER GENERATED INVOICE", 105, yPos, null, null, "center");

      // Add professional border around the entire document
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setLineWidth(3);
      doc.roundedRect(10, 10, 190, 277, 5, 5);

      // Add inner decorative border
      doc.setDrawColor(lightAccentColor[0], lightAccentColor[1], lightAccentColor[2]);
      doc.setLineWidth(1);
      doc.roundedRect(14, 14, 182, 269, 3, 3);

      // Add diagonal watermark (back print) - behind invoice details, centered, and size-adjusted
      // Save current graphics state
      doc.saveGraphicsState();

      // Set very light opacity for background watermark
      const GState = (doc as any).GState;
      doc.setGState(new GState({ opacity: 0.08 }));
      doc.setFontSize(28);
      doc.setTextColor(150, 150, 150);
      doc.setFont("helvetica", "bold");

      const watermarkY = 148; // Center of the main content area
      const watermarkX = 105; // Center horizontally

      doc.text("MOHAMMED SOHEL TAJANI", watermarkX, watermarkY, null, 45, "center");

      doc.restoreGraphicsState();

      // Add text at bottom right (corrected orientation)
      doc.setFontSize(8);
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont("helvetica", "normal");
      doc.text("MOHAMMED SOHEL TAJANI", 190, 280, null, null, "right");

      const pdfBlob = doc.output("blob");
      const pdfFile = new File([pdfBlob], "transfer_invoice.pdf", { type: "application/pdf" });

      if (navigator.share && navigator.canShare({ files: [pdfFile] })) {
        navigator.share({
          files: [pdfFile],
          title: 'Transfer Invoice',
          text: 'Here is your professional transfer invoice.',
        })
          .then(() => toast.success('Transfer invoice shared successfully!'))
          .catch((error) => toast.error('Error sharing invoice: ' + error.message));
      } else {
        const pdfUrl = URL.createObjectURL(pdfBlob);
        const a = document.createElement('a');
        a.href = pdfUrl;
        a.download = 'transfer_invoice.pdf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(pdfUrl);
        toast.info('Professional transfer invoice downloaded. Web Share API not supported or cannot share files.');
      }
    };
  
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8 slide-in-from-right">
        <Card className="w-full max-w-sm shadow-2xl rounded-3xl bg-card">
          <CardContent className="p-8">
              <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
              <h2 className="text-2xl font-bold text-foreground mb-2">Transfer Done!</h2>
              <p className="text-muted-foreground mb-8">
                  The transfer for {data.name} has been successfully recorded.
              </p>
              <div className="space-y-3">
                   <Button onClick={handleShareReceipt} variant="outline" className="w-full h-12 text-lg">
                      <Share2 className="mr-2 h-5 w-5" /> Share Transfer Invoice
                   </Button>
                  <Button onClick={onDone} className="w-full h-12 text-lg">
                      Done
                  </Button>
              </div>
          </CardContent>
        </Card>
      </div>
    );
};


export default function TransferPage() {
  const router = useRouter();
  const [inventory, setInventory] = useLocalStorage<Product[]>('products', []);
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('history', []);
  const [reversedTransfers] = useLocalStorage<ReversedTransferItem[]>('reversedTransfers', []);
  const [shopInfo] = useLocalStorage<ShopInfo | null>('shopInfo', null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const [isCheckingId, setIsCheckingId] = useState(false);
  const [submittedTransfer, setSubmittedTransfer] = useState<HistoryItem | null>(null);
  const [showSoldOutDialog, setShowSoldOutDialog] = useState(false);

  const myShopName = shopInfo?.shopName || 'My Shop';

  const form = useForm<TransferFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      brand: '',
      name: '',
      id: '',
      id2: '',
      ram: '',
      storage: '',
      color: '',
      price: '' as any,
      transferType: 'Transfer In',
      transferFrom: '',
      transferTo: myShopName,
      paymentStatus: 'Unpaid',
    },
  });

  const transferType = form.watch('transferType');
  const watchedRam = form.watch('ram');

  useEffect(() => {
    if (transferType === 'Transfer In') {
      form.setValue('transferTo', myShopName);
      form.setValue('transferFrom', '');
    } else if (transferType === 'Transfer Out') {
      form.setValue('transferFrom', myShopName);
      form.setValue('transferTo', '');
    }
  }, [transferType, myShopName, form]);

  useEffect(() => {
    if (watchedRam) {
      const storageOptions = ramToStorageMap[watchedRam] || [];
      const currentStorage = form.getValues('storage');
      if (!storageOptions.includes(currentStorage)) {
        form.setValue('storage', storageOptions[0] || '');
      }
    }
  }, [watchedRam, form]);

  const searchResults = useMemo(() => {
    if (!searchQuery) return [];
    return inventory.filter(
      (item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.id.includes(searchQuery) ||
        (item.id2 && item.id2.includes(searchQuery))
    );
  }, [searchQuery, inventory]);

  const findAndHandleProduct = (productId: string) => {
    if (!productId || productId.length < 15) {
      if (productId) form.setValue('id', productId);
      return;
    }
    setIsCheckingId(true);
    
    setTimeout(() => {
      const product = inventory.find(
        (p) => p.id === productId || (p.id2 && p.id2 === productId)
      );

      if (product) {
        // Product FOUND in inventory
        if (product.stock <= 0) {
          setShowSoldOutDialog(true);
          setSearchQuery('');
          setIsCheckingId(false);
          return;
        }

        form.reset({
          name: product.name,
          brand: product.brand,
          id: product.id,
          id2: product.id2 || '',
          ram: product.ram,
          storage: product.storage,
          color: product.color,
          price: '' as any,
          transferType: 'Transfer Out',
          transferFrom: myShopName,
          transferTo: '',
          paymentStatus: 'Unpaid',
        });
        setSearchQuery('');
        toast.success('Product found', { description: 'Details filled for Transfer Out.' });
      } else {
        // Product NOT found in inventory
        form.setValue('id', productId);
        form.setValue('transferType', 'Transfer In');
        toast.info('New Product', { description: 'IMEI filled. Please complete details for transfer.' });
      }
      setIsCheckingId(false);
    }, 500);
  };
  
  const handleScan = (barcodes: string[]) => {
    setShowScanner(false);
    const [firstId, secondId] = barcodes;

    if (firstId) {
      findAndHandleProduct(firstId);
    }
    
    if (secondId) {
      form.setValue('id2', secondId);
    } else {
      form.setValue('id2', '');
    }
  };

  const onSubmit = (data: TransferFormValues) => {
    setIsSubmitting(true);

    try {
        const existingPendingTransfer = history.find(item => {
            const isTransfer = item.type === 'Transfer In' || item.type === 'Transfer Out';
            const isPending = item.status === 'Pending';
            const hasBeenReversed = reversedTransfers.some(rt => rt.originalTransferId === item.id);
            const matchesId = item.details.includes(data.id) || (data.id2 && item.details.includes(data.id2));

            return isTransfer && isPending && !hasBeenReversed && matchesId;
        });

        if (existingPendingTransfer) {
            toast.error('Duplicate Transfer', {
                description: 'This product is already in a pending transfer.',
            });
            return;
        }

        const productInInventory = inventory.find(p => p.id === data.id || (data.id2 && data.id2 && p.id2 === data.id2));

        if (data.transferType === 'Transfer Out') {
          if (!productInInventory) {
             toast.error('Product Not Found', { description: 'This product is not in your inventory.' });
             return;
          }
          if (productInInventory.stock <= 0) {
            setShowSoldOutDialog(true);
            return;
          }
        }
        
        if(data.transferType === 'Transfer In' && productInInventory) {
            toast.error('Duplicate Product', { description: 'A product with this ID already exists in your inventory.' });
            return;
        }

        const transferStatus = data.paymentStatus === 'Paid' ? 'Settled' : 'Pending';

        const detailsParts = [
          `${data.ram}/${data.storage},`,
          `${data.color}`,
          `- From ${data.transferFrom}`,
          `- To ${data.transferTo}`,
          `- ID1: ${data.id}`
        ];
        if (data.id2) {
          detailsParts.push(`ID2: ${data.id2}`);
        }

        const newHistoryItem: HistoryItem = {
          id: Date.now(),
          date: new Date(),
          type: data.transferType,
          status: transferStatus,
          productName: data.name,
          quantity: 1,
          totalAmount: data.price,
          purchasePrice: data.transferType === 'Transfer In' ? data.price : productInInventory?.purchasePrice,
          salePrice: data.transferType === 'Transfer Out' ? data.price : undefined,
          details: detailsParts.join(' '),
        };

        setHistory((prev) => [newHistoryItem, ...prev]);

        if (data.transferType === 'Transfer In') {
          const newProduct: Product = {
            id: data.id,
            id2: data.id2,
            name: data.name,
            brand: data.brand || 'Unbranded',
            stock: 1,
            ram: data.ram,
            storage: data.storage,
            color: data.color,
            purchasePrice: data.price,
          };
          setInventory((prev) => [...prev, newProduct]);
        } else if (data.transferType === 'Transfer Out' && data.paymentStatus === 'Paid') {
            const productIndex = inventory.findIndex(p => p.id === data.id || (data.id2 && data.id2 === p.id2));
            if (productIndex !== -1) {
                const updatedInventory = [...inventory];
                updatedInventory[productIndex].stock = updatedInventory[productIndex].stock - 1;
                setInventory(updatedInventory);
            }
        }
        
        setSubmittedTransfer(newHistoryItem);

    } finally {
        setIsSubmitting(false);
    }
  };

  const isTransferOut = transferType === 'Transfer Out';

  return (
    <>
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
          scanLimit={2}
        />
      )}
      <AlertDialog open={showSoldOutDialog} onOpenChange={setShowSoldOutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center text-center">
            <div className="bg-red-100 p-3 rounded-full mb-3">
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
            <AlertDialogTitle className="text-2xl font-bold">Product Sold Out</AlertDialogTitle>
            <AlertDialogDescription>
              This product is sold out and cannot be transferred.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowSoldOutDialog(false)}>
              OK
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <div className="flex flex-col h-screen bg-background font-sans slide-in-from-right">
        <header className="flex items-center justify-between p-4 bg-card border-b flex-shrink-0 sticky top-0 z-20">
          <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-xl font-bold">TRANSFER</h1>
          <div className="w-10"></div>
        </header>

        {submittedTransfer ? (
            <TransferSuccessScreen data={form.getValues()} onDone={() => router.push('/dashboard?transferSuccess=true')}/>
        ) : (
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="flex flex-col flex-1"
            >
              <ScrollArea className="flex-1">
                <main className="p-4 md:p-6">
                  <Card className="w-full max-w-md mx-auto shadow-lg border-0 bg-card rounded-2xl">
                    <CardHeader>
                      <CardTitle className="text-2xl font-bold text-center tracking-wide">
                        Product Transfer
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pb-6 space-y-6">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input
                          placeholder="Search by Model or ID to autofill..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                        {searchQuery && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6"
                            onClick={() => setSearchQuery('')}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                        {searchResults.length > 0 && (
                          <Card className="absolute z-10 w-full mt-1 max-h-60 overflow-y-auto">
                            <CardContent className="p-2">
                              {searchResults.map((product) => (
                                <div
                                  key={product.id}
                                  onClick={() => findAndHandleProduct(product.id)}
                                  className="p-2 hover:bg-accent rounded-md cursor-pointer"
                                >
                                  <p className="font-semibold">{product.name}</p>
                                  <p className="text-sm text-muted-foreground">
                                    {product.id}
                                  </p>
                                </div>
                              ))}
                            </CardContent>
                          </Card>
                        )}
                      </div>
                       <Button
                          type="button"
                          onClick={() => setShowScanner(true)}
                          variant="outline"
                          className="w-full"
                        >
                          <ScanLine className="mr-2 h-4 w-4" />
                          Scan IMEI
                        </Button>

                        {transferType === 'Transfer In' && (
                            <FormField
                            control={form.control}
                            name="brand"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Brand</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a brand" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    {brandOptions.map(brand => (
                                        <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                                    ))}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        )}

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter product name"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 1</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input
                                  type="text"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  placeholder="Enter 15-digit PRODUCT ID"
                                  {...field}
                                  maxLength={15}
                                  onBlur={(e) => findAndHandleProduct(e.target.value)}
                                />
                                {isCheckingId && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground animate-spin" />}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="id2"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PRODUCT ID 2 (Optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                placeholder="Enter 15-digit PRODUCT ID"
                                {...field}
                                maxLength={15}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="space-y-4 bg-muted/50 p-4 rounded-lg border">
                        <FormLabel className="block font-semibold text-md">
                          Configuration
                        </FormLabel>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="ram"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>RAM</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  value={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {allRamOptions.map((ram) => (
                                      <SelectItem key={ram} value={ram}>
                                        {ram}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Storage</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  value={field.value}
                                  disabled={!watchedRam}
                                >
                                  <FormControl>
                                    <SelectTrigger
                                      className={cn(!watchedRam && 'bg-muted')}
                                    >
                                      <SelectValue placeholder="Select" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {(
                                      ramToStorageMap[watchedRam] || allStorageOptions
                                    ).map((storage) => (
                                      <SelectItem key={storage} value={storage}>
                                        {storage}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name="color"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Color</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Enter color"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                placeholder="Enter price"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="transferType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Transfer Type</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select transfer type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Transfer In">
                                  TRANSFER IN
                                </SelectItem>
                                <SelectItem value="Transfer Out">
                                  TRANSFER OUT
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                       <FormField
                        control={form.control}
                        name="paymentStatus"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Status</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select payment status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Paid">Paid</SelectItem>
                                <SelectItem value="Unpaid">Unpaid</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="transferFrom"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>FROM [SHOP NAME]</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter sender shop name"
                                {...field}
                                disabled={transferType === 'Transfer Out'}
                                className={cn(transferType === 'Transfer Out' && 'bg-muted')}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="transferTo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>TO [SHOP NAME]</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter recipient shop name"
                                {...field}
                                disabled={transferType === 'Transfer In'}
                                className={cn(transferType === 'Transfer In' && 'bg-muted')}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                    </CardContent>
                  </Card>
                </main>
              </ScrollArea>
              <div className="sticky bottom-0 p-4 bg-card border-t space-y-2">
                <Button
                  type="submit"
                  className="w-full h-12 text-lg"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  {isSubmitting ? 'Submitting...' : 'Submit Transfer'}
                </Button>
              </div>
            </form>
          </Form>
        )}
      </div>
    </>
  );
}
