
'use server';
/**
 * @fileoverview This file initializes the Genkit AI singleton. It is NOT
 * a public interface, and should not be used directly by any other component
 * other than to define flows, prompts, and other Genkit constructs.
 *
 * It is not guaranteed that any other file can safely use the `ai` object
 * without causing conflicts with the Genkit framework.
 */
import {genkit, type Genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';

/**
 * The Genkit AI singleton.
 */
export const ai: Genkit = genkit({
  plugins: [googleAI()],
});
