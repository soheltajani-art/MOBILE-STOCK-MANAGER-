
'use client';

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';

interface UseInfiniteScrollProps<T> {
  items: T[];
  itemsPerPage?: number;
}

export function useInfiniteScroll<T>({
  items,
  itemsPerPage = 20,
}: UseInfiniteScrollProps<T>) {
  const [page, setPage] = useState(1);
  const sentryRef = useRef<HTMLDivElement>(null);

  const displayedItems = useMemo(() => {
    return items.slice(0, page * itemsPerPage);
  }, [items, page, itemsPerPage]);

  const isLoadingMore = page * itemsPerPage < items.length;
  const isReachingEnd = page * itemsPerPage >= items.length;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && isLoadingMore) {
          // Add a small delay to simulate network latency and prevent rapid firing
          setTimeout(() => {
            setPage((prevPage) => prevPage + 1);
          }, 300);
        }
      },
      { threshold: 1.0 }
    );

    if (sentryRef.current) {
      observer.observe(sentryRef.current);
    }

    return () => {
      if (sentryRef.current) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        observer.unobserve(sentryRef.current);
      }
    };
  }, [sentryRef, isLoadingMore]);

  // Reset page when the underlying items array changes (e.g., due to filtering)
  useEffect(() => {
    setPage(1);
  }, [items]);

  return {
    items: displayedItems,
    isLoadingMore,
    isReachingEnd,
    sentryRef,
  };
}
