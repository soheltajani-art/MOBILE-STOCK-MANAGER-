
'use client';
import { useLocalStorage } from './use-local-storage';
import { useEffect, useState, useCallback } from 'react';

export type EmployeePermissions = {
    canPurchase: boolean;
    canSell: boolean;
    canTransfer: boolean;
    canReverse: boolean;
    canSettleTransfers: boolean;
    canGenerateInvoice: boolean;
};

export const defaultPermissions: EmployeePermissions = {
    canPurchase: true,
    canSell: true,
    canTransfer: true,
    canReverse: true,
    canSettleTransfers: true,
    canGenerateInvoice: true,
};

// Map of peer IDs to their permissions
export type PermissionsMap = Record<string, EmployeePermissions>;

export function usePermissions(peerId?: string) {
    const [permissionsMap, setPermissionsMap] = useLocalStorage<PermissionsMap>('employee-permissions-map', {});
    const [isPermissionsReady, setIsPermissionsReady] = useState(false);

    useEffect(() => {
        setIsPermissionsReady(true);
    }, []);
    
    // For admin to set a specific employee's permissions
    const setEmployeePermissions = useCallback((employeePeerId: string, value: React.SetStateAction<EmployeePermissions>) => {
        const newPermissionsMap = { ...permissionsMap };
        const oldPermissions = newPermissionsMap[employeePeerId] || defaultPermissions;
        const newPermissions = value instanceof Function ? value(oldPermissions) : value;
        newPermissionsMap[employeePeerId] = newPermissions;

        setPermissionsMap(newPermissionsMap);
    }, [permissionsMap, setPermissionsMap]);
    
    // For the current user to get their own permissions
    const myPermissions = defaultPermissions;

    return { 
        myPermissions, 
        permissionsMap, 
        setEmployeePermissions, 
        isPermissionsReady 
    };
}
