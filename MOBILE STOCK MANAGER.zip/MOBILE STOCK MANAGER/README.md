zip -r my-project-backup.zip . -x "node_modules/*"# MOBILE STOCK MANAGER

**Copyright (c) 2024 MOHAMMED SOHEL TAJANI. All Rights Reserved.
```